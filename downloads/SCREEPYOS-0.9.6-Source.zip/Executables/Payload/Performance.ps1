﻿#requires -Version 5.1
. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'PerformanceEngine.ps1')
. (Join-Path $PSScriptRoot 'CaptureEngine.ps1')
$form=New-DashForm 'SCREEPYOS / Performance Lab'
$flow=New-Object Windows.Forms.FlowLayoutPanel;$flow.Dock='Fill';$flow.FlowDirection='TopDown';$flow.WrapContents=$false;$flow.AutoScroll=$true;$flow.Padding=New-Object Windows.Forms.Padding(22);$form.Controls.Add($flow)
function PText($Text,$Height=42,$Size=10) {$c=New-Object Windows.Forms.Label;$c.Text=$Text;$c.Size=New-Object Drawing.Size(850,$Height);$c.Font=New-Object Drawing.Font('Segoe UI',$Size);$flow.Controls.Add($c);return $c}
function PButton($Text,$Action) {$c=New-Object Windows.Forms.Button;$c.Text=$Text;$c.Size=New-Object Drawing.Size(850,36);$c.Margin=New-Object Windows.Forms.Padding(3,4,3,4);$c.Add_Click($Action);$flow.Controls.Add($c);return $c}
function PMessage($Text) {[Windows.Forms.MessageBox]::Show($form,[string]$Text,'Performance Lab')|Out-Null}
function PGame {if ($games.SelectedIndex -lt 0 -or -not $script:PerfGames.Count) {throw 'Add a game in Game library, then select it here.'};return $script:PerfGames[$games.SelectedIndex]}
$null=PText 'PERFORMANCE LAB' 48 24
$null=PText 'For low-, mid- and high-end PCs. Choose one experiment, measure it, then keep or restore.' 38
$games=New-Object Windows.Forms.ComboBox;$games.DropDownStyle='DropDownList';$games.Size=New-Object Drawing.Size(850,30);$flow.Controls.Add($games)
function PRefreshGames {$games.Items.Clear();$script:PerfGames=@(Get-CProfiles);foreach ($game in $script:PerfGames) {[void]$games.Items.Add($game.Name)};$games.Enabled=[bool]$script:PerfGames.Count;if (-not $games.Items.Count) {[void]$games.Items.Add('No saved games. Add a game in Game library first.')};$games.SelectedIndex=0}
$null=PButton 'Refresh saved games' {try {PRefreshGames} catch {PMessage $_.Exception.Message}}
$header=$flow
$frame=New-Object Windows.Forms.TableLayoutPanel;$frame.Dock='Fill';$frame.ColumnCount=1;$frame.RowCount=2
[void]$frame.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',205)))
[void]$frame.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
$form.Controls.Remove($header);$form.Controls.Add($frame);$frame.Controls.Add($header,0,0)
$tabs=New-Object Scrp.DarkTabs;$tabs.Dock='Fill';$frame.Controls.Add($tabs,0,1)
function PSection($Name) {
 $page=New-Object Windows.Forms.TabPage;$page.Text=$Name
 $script:flow=New-Object Windows.Forms.FlowLayoutPanel;$script:flow.Dock='Fill';$script:flow.AutoScroll=$true;$script:flow.FlowDirection='TopDown';$script:flow.WrapContents=$false;$script:flow.Padding=New-Object Windows.Forms.Padding(18)
 $page.Controls.Add($script:flow);$tabs.TabPages.Add($page)
 $script:flow.Add_SizeChanged({param($sender,$event) $width=[math]::Max(450,$sender.ClientSize.Width-55);foreach ($child in $sender.Controls) {$child.Width=$width}})
}
PSection 'Background apps'
$null=PText 'BACKGROUND APPS / saved per game' 35 14
$null=PText 'Select windows to request closed before a session. Save prompts are respected. Nothing is force-killed or reopened automatically.' 45
$background=New-Object Windows.Forms.CheckedListBox;$background.DisplayMember='Label';$background.CheckOnClick=$true;$background.Size=New-Object Drawing.Size(850,120);$flow.Controls.Add($background)
$null=PButton 'Refresh open windows' {try {
 $g=PGame;$settings=Read-Tuning $g;$background.Items.Clear();$script:BackgroundLoadedId=$g.Id
 foreach ($item in @(Get-BackgroundCandidates $g)) {[void]$background.Items.Add($item,($settings.Background -contains $item.Path))}
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Save background choices for this game' {try {
 $g=PGame;if ($script:BackgroundLoadedId -ne $g.Id) {throw 'Refresh open windows before saving background choices.'};$settings=Read-Tuning $g;$settings.Background=@($background.CheckedItems|ForEach-Object {$_.Path}|Select-Object -Unique);Save-Tuning $g $settings
 PMessage 'Saved. Start a Game library session to review and confirm the close requests. Only the listed currently open apps are saved; refresh first to edit an existing list.'
} catch {PMessage $_.Exception.Message}}
PSection 'Game settings'
$null=PText 'GAME CONFIGURATION / named snapshots' 38 14
$null=PText 'Set graphics inside your game, exit it, then save its text settings file in a slot. Low/Mid/High are your own snapshots, not universal FPS presets. Never select saves, account files or executable scripts.' 60
$tier=New-Object Windows.Forms.ComboBox;$tier.DropDownStyle='DropDownList';$tier.Items.AddRange(@('Low','Mid','High','Custom'));$tier.SelectedIndex=1;$tier.Size=New-Object Drawing.Size(850,30);$flow.Controls.Add($tier)
$guidance=PText '' 72
function PShowGuidance {
 $guidance.Text=switch ($tier.SelectedItem) {
 'Low' {'Starting point in-game: reduce shadows/effects and render distance. Lower render scale only if needed and acceptable. Save your chosen file below.'}
 'Mid' {'Starting point in-game: medium shadows/effects and a moderate render distance. Compare smoothness with native resolution before changing render scale.'}
 'High' {'Starting point in-game: keep desired image quality and lower the most expensive effects first. High-end hardware can still be limited by the game or frame cap.'}
 default {'Custom: choose your own graphics settings in-game, exit, and save the resulting settings file. No Windows changes are tied to this slot.'}
 }
};$tier.Add_SelectedIndexChanged({PShowGuidance});PShowGuidance
$config=PText 'No settings file selected.' 40
$null=PButton 'Choose game settings file' {try {
 $g=PGame;Assert-GameClosed $g;$d=New-Object Windows.Forms.OpenFileDialog
 try {$d.Filter='Text game settings|*.ini;*.cfg;*.json;*.xml;*.txt';if ($d.ShowDialog() -eq 'OK') {$settings=Read-Tuning $g;$settings.Config=Assert-ConfigPath $d.FileName;Save-Tuning $g $settings;$config.Text=$settings.Config}} finally {$d.Dispose()}
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Save current file to selected slot' {try {
 $g=PGame;$settings=Read-Tuning $g
 if ([Windows.Forms.MessageBox]::Show('Save the current file to '+$tier.SelectedItem+'? An existing slot will be replaced.','Save snapshot','OKCancel') -ne 'OK') {return}
 Save-GameSnapshot $g $settings.Config ([string]$tier.SelectedItem);PMessage 'Snapshot saved byte-for-byte. Original encoding is preserved.'
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Apply selected snapshot / begin experiment' {try {
 $g=PGame;$metadata=Join-Path (Get-TuningFolder $g) ([string]$tier.SelectedItem+'.json');$snapshot=Get-Content $metadata -Raw|ConvertFrom-Json
 if ([Windows.Forms.MessageBox]::Show('Replace this game settings file with the saved '+$tier.SelectedItem+" snapshot?`r`n"+$snapshot.Target+"`r`nThe current file is backed up first. Close the game and any settings editor.",'Apply configuration','OKCancel','Warning') -ne 'OK') {return}
 Apply-GameSnapshot $g ([string]$tier.SelectedItem);PMessage 'Applied. Run the same benchmark scene. Afterwards close the game and choose Restore or Keep.'
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Restore configuration before experiment' {try {
 $g=PGame;$preview=Get-ConfigExperimentPreview $g;$expected=''
 if ($preview.CurrentHash -ne $preview.BeforeHash -and $preview.CurrentHash -ne $preview.AppliedHash) {
  if ([Windows.Forms.MessageBox]::Show("This file changed after applying the snapshot. Restoring will replace those later changes. Keep a copy of the current file and restore the original anyway?`r`n"+$preview.Target,'Review changed configuration','YesNo','Warning') -ne 'Yes') {return}
  $expected=$preview.CurrentHash
 }
 Finish-ConfigExperiment $g -ExpectedCurrentHash $expected;PMessage 'Original configuration restored.'
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Keep current configuration / finish experiment' {try {
 if ([Windows.Forms.MessageBox]::Show('Keep the current file and finish this experiment? The original backup remains on disk.','Keep configuration','OKCancel') -eq 'OK') {Finish-ConfigExperiment (PGame) -Keep;PMessage 'Experiment finished.'}
} catch {PMessage $_.Exception.Message}}
PSection 'Latency guide'
$null=PText 'LATENCY GUIDE / manual, game-dependent' 38 14
$null=PText 'NVIDIA: try the game''s Reflex option when supported. AMD: check the official Anti-Lag guide for your game. Compare one option at a time. These reduce latency in supported scenarios; they are not guaranteed FPS boosts. No GPU selection or forced driver settings.' 74
$null=PButton 'Open NVIDIA Reflex guide' {Start-Process 'https://www.nvidia.com/en-us/geforce/technologies/reflex/'}
$null=PButton 'Open AMD Anti-Lag guide' {Start-Process 'https://www.amd.com/en/products/software/adrenalin/radeon-software-anti-lag.html'}
PSection 'Measurements'
$null=PText 'SESSION CAPTURE / optional measurement overhead' 38 14
$null=PText 'CPU and RAM sampling every ~2 seconds. Optional GPU counters and temperature sensors add overhead. Use identical measurement options for BEFORE and AFTER. Missing values stay blank, not zero.' 60
$duration=New-Object Windows.Forms.NumericUpDown;$duration.Minimum=15;$duration.Maximum=600;$duration.Value=60;$duration.Size=New-Object Drawing.Size(850,30);$flow.Controls.Add($duration)
$null=PText 'Capture duration in seconds (15-600). Start your game first.' 30
$gpu=New-Object Windows.Forms.CheckBox;$gpu.Text='Read busiest GPU engine for this game (measurement only; no GPU selection)';$gpu.Size=New-Object Drawing.Size(850,30);$flow.Controls.Add($gpu)
$temps=New-Object Windows.Forms.CheckBox;$temps.Text='Read temperatures from an already running LibreHardwareMonitor WMI provider';$temps.Size=New-Object Drawing.Size(850,30);$flow.Controls.Add($temps)
$pm=PText 'PresentMon: not selected. CPU/RAM capture is available without it.' 42;$script:BackgroundLoadedId='';$script:PresentMonPath='';$script:Capture=$null
$null=PButton 'Open official PresentMon downloads (console application)' {Start-Process 'https://github.com/GameTechDev/PresentMon/releases'}
$null=PButton 'Choose installed PresentMon console EXE' {
 $d=New-Object Windows.Forms.OpenFileDialog;try {$d.Filter='PresentMon console|PresentMon*.exe';if ($d.ShowDialog() -eq 'OK') {$script:PresentMonPath=$d.FileName;$pm.Text=$d.FileName}} finally {$d.Dispose()}
}
$captureStatus=PText 'No capture started.' 80
$null=PButton 'Start timed capture' {try {
 if ($script:Capture -and ((-not $script:Capture.Worker.HasExited) -or ($script:Capture.PresentMon -and -not $script:Capture.PresentMon.HasExited))) {throw 'Wait for the current timed capture to finish.'}
 if ($script:PresentMonPath -and [Windows.Forms.MessageBox]::Show("Run the selected PresentMon console executable? Use only a verified official download.`r`n"+$script:PresentMonPath,'Start capture','OKCancel') -ne 'OK') {return}
 $script:Capture=Start-PerformanceCapture (PGame) ([int]$duration.Value) $script:PresentMonPath $gpu.Checked $temps.Checked
 $captureStatus.Text='Recording to '+$script:Capture.Folder
} catch {PMessage $_.Exception.Message}}
$null=PButton 'Open last capture folder' {try {if (-not $script:Capture) {throw 'No capture this app session.'};Start-Process explorer.exe -ArgumentList ('"'+$script:Capture.Folder+'"')} catch {PMessage $_.Exception.Message}}
$null=PButton 'Compare captures / Benchmarks' {& $script:Navigate 'Metrics'}
$null=PText 'PresentMon frames.csv can be imported in Benchmarks. If recording fails, inspect presentmon-error.log (permissions/version may differ). Telemetry CSV is separate; CPU is normalized across all logical cores, GPU is the busiest engine, temperatures keep sensor IDs. No automatic bottleneck diagnosis.' 85
$games.Add_SelectedIndexChanged({try {$g=PGame;$settings=Read-Tuning $g;$config.Text=$settings.Config;$background.Items.Clear();$script:BackgroundLoadedId=''} catch {}})
$header.Add_SizeChanged({param($sender,$event) $width=[math]::Max(450,$sender.ClientSize.Width-55);foreach ($child in $sender.Controls) {$child.Width=$width}})
$timer=New-Object Windows.Forms.Timer;$timer.Interval=2000
$timer.Add_Tick({if ($script:Capture) {
 $done=$script:Capture.Worker.HasExited -and (-not $script:Capture.PresentMon -or $script:Capture.PresentMon.HasExited)
 $captureStatus.Text=$(if ($done) {'Capture ended. '} else {'Recording. '})+$script:Capture.Folder
 try {
  $sample=Import-Csv -LiteralPath (Join-Path $script:Capture.Folder 'telemetry.csv') -ErrorAction Stop|Select-Object -Last 1
  if ($sample) {$captureStatus.Text+="`r`nLatest sample: CPU "+$sample.CpuPercentAllLogicalCores+'% (all cores), RAM '+$sample.WorkingSetMB+' MB';if ($sample.BusiestGameGpuEnginePercent -ne '') {$captureStatus.Text+=', busiest GPU engine '+$sample.BusiestGameGpuEnginePercent+'%'}}
 } catch {}
 if ($done -and ($script:Capture.Worker.ExitCode -ne 0 -or ($script:Capture.PresentMon -and $script:Capture.PresentMon.ExitCode -ne 0))) {$captureStatus.Text='Capture reported an error; inspect logs in '+$script:Capture.Folder}
}});$timer.Start()
PRefreshGames
Mount-ScrpPage $form {$timer.Stop();$timer.Dispose();if ($script:Capture -and -not $script:Capture.Worker.HasExited) {'stop'|Set-Content -LiteralPath $script:Capture.StopFile};$null=$script:Capture}
