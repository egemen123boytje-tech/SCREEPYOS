﻿#requires -Version 5.1
param([string]$ProfileId='', [switch]$AutoStart)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'PerformanceEngine.ps1')
$script:CMutex=New-Object Threading.Mutex($false,('Local\SCREEPYOS-Competitive-'+$script:Sid));$script:COwn=$false
try {$script:COwn=$script:CMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$script:COwn=$true}
if (-not $script:COwn) {[Windows.Forms.MessageBox]::Show('Competitive Mode is already open. Use the existing window.','SCREEPYOS')|Out-Null;throw 'Competitive Mode is already open.'}
$script:CActive=$false;$script:CSeen=$false;$script:CLastSeen=Get-Date;$script:CStarted=Get-Date;$script:CPrevious=@{};$script:CAttempts=@{}
$script:CForm=New-DashForm 'SCREEPYOS 0.9.6 / Competitive Mode'
$script:CCanvas=New-DashCanvas $script:CForm 825
$tip=New-Object Windows.Forms.ToolTip;$tip.AutoPopDelay=20000
$null=Add-DashLabel $script:CCanvas 'S C R P   /   C O M P E T I T I V E' 24 20 900 44 23
$null=Add-DashLabel $script:CCanvas 'ONE PROFILE. YOUR GAME. RESTORE AFTER THE SESSION.' 26 70 880 26
$script:CStatus=Add-DashLabel $script:CCanvas 'READY  /  Competitive Mode: Disabled' 26 105 890 36 15
$script:CList=New-Object Windows.Forms.ListBox;$script:CList.SetBounds(26,154,290,210);$script:CList.BackColor=[Drawing.Color]::FromArgb(28,28,31);$script:CList.ForeColor=[Drawing.Color]::Gainsboro;$script:CCanvas.Controls.Add($script:CList)
$script:CName=New-Object Windows.Forms.TextBox;$script:CName.SetBounds(340,155,565,28);$script:CCanvas.Controls.Add($script:CName)
$script:CPathLabel=Add-DashLabel $script:CCanvas 'Select the actual game executable.' 340 195 565 50
$script:CLaunchLabel=Add-DashLabel $script:CCanvas 'Launch file: start manually through your launcher' 340 260 565 50
$null=Add-DashButton $script:CCanvas 'Add game' 26 375 290 {try {
 $d=New-Object Windows.Forms.OpenFileDialog;$d.Filter='Game executable|*.exe'
 if ($d.ShowDialog() -ne 'OK') {return}
 $p=[pscustomobject]@{Version=1;Id=[guid]::NewGuid().ToString('N');Name=[IO.Path]::GetFileNameWithoutExtension($d.FileName);Path=$d.FileName;Launch='';Priority='Normal';Power=$false;CaptureOff=$false;Hud=$true}
 Save-CProfile $p;Refresh-CList $p.Id
} catch {CMessage $_.Exception.Message}}
$null=Add-DashButton $script:CCanvas 'Choose launch file' 340 315 265 {try {
 $p=Selected-CProfile
 $d=New-Object Windows.Forms.OpenFileDialog;$d.Filter='Game / launcher shortcut|*.exe;*.lnk;*.url';$d.DereferenceLinks=$false
 if ($d.ShowDialog() -ne 'OK') {return}
 $p.Launch=$d.FileName;Save-CProfile $p;Refresh-CList $p.Id
} catch {CMessage $_.Exception.Message}}
$null=Add-DashButton $script:CCanvas 'Use manual launch' 620 315 285 {try {$p=Selected-CProfile;$p.Launch='';Save-CProfile $p;Refresh-CList $p.Id} catch {CMessage $_.Exception.Message}}
$script:CPriority=New-Object Windows.Forms.ComboBox;$script:CPriority.SetBounds(340,375,265,30);$script:CPriority.DropDownStyle='DropDownList';$script:CPriority.Items.AddRange(@('Normal','AboveNormal','High'));$script:CPriority.SelectedIndex=0;$script:CCanvas.Controls.Add($script:CPriority)
$tip.SetToolTip($script:CPriority,'Normal is the default. AboveNormal/High changes CPU scheduling without guaranteed FPS gains. High may starve audio or other apps. Anti-cheat may block changes; no bypass is used.')
$null=Add-DashLabel $script:CCanvas 'CPU priority / this game path only' 620 377 290 30
$script:CPower=Add-DashCheck $script:CCanvas 'Temporary High performance' 340 420 560 $false $tip 'Uses an existing High performance plan on AC power only. Restores the previous plan. May increase heat and power use without improving performance.'
$script:CCapture=Add-DashCheck $script:CCanvas 'Temporarily disable Windows game recording' 340 457 560 $false $tip 'Disables Windows Game DVR/capture for the session. Xbox/Game Pass stays installed. Do not select if you want Windows game recording. May require restarting the game.'
$script:CHud=Add-DashCheck $script:CCanvas 'Session statistics on this page: Enabled' 340 494 560 $true $tip 'Shows process CPU usage, working set and priority at the bottom of this page. No extra window, FPS measurement or game injection.'
$null=Add-DashLabel $script:CCanvas 'Normal is the default. Enable optional tweaks deliberately and compare frame times.' 26 540 880 28
$null=Add-DashButton $script:CCanvas 'Save profile' 26 578 205 {try {Save-CEditor;CMessage 'Profile saved.'} catch {CMessage $_.Exception.Message}}
$null=Add-DashButton $script:CCanvas 'Desktop shortcut' 246 578 205 {try {Save-CEditor;CMessage (New-CShortcut (Selected-CProfile))} catch {CMessage $_.Exception.Message}}
$script:CStartButton=Add-DashButton $script:CCanvas 'START COMPETITIVE' 466 578 220 {Start-CMode}
$script:CStopButton=Add-DashButton $script:CCanvas 'STOP / RESTORE' 701 578 205 {Stop-CMode}
$script:CLogBox=New-Object Windows.Forms.TextBox;$script:CLogBox.SetBounds(26,632,880,110);$script:CLogBox.Multiline=$true;$script:CLogBox.ReadOnly=$true;$script:CLogBox.ScrollBars='Vertical';$script:CCanvas.Controls.Add($script:CLogBox)
$script:CRecoveryButton=Add-DashButton $script:CCanvas 'Recover previous session' 26 758 265 {if ($script:CActive) {CMessage 'Stop the active session first.';return};try {$fail=@(Restore-CSession);if ($fail.Count) {CMessage ($fail -join "`r`n")} else {CMessage 'No pending session settings.'}} catch {CMessage $_.Exception.Message}}
$null=Add-DashButton $script:CCanvas 'Compare frame times' 310 758 265 {& $script:Navigate 'Metrics'}
function CMessage($message) {[Windows.Forms.MessageBox]::Show($script:CForm,[string]$message,'SCREEPYOS Competitive')|Out-Null}
function CLog($message) {$script:CLogBox.AppendText(([DateTime]::Now.ToString('HH:mm:ss')+'  '+$message+"`r`n"))}
function Selected-CProfile {if ($script:CList.SelectedIndex -lt 0) {throw 'Select a game first.'};return $script:CProfiles[$script:CList.SelectedIndex]}
function Refresh-CList($selected='') {
 $script:CProfiles=@(Get-CProfiles);$script:CList.Items.Clear()
 foreach ($p in $script:CProfiles) {[void]$script:CList.Items.Add($p.Name)}
 for ($i=0;$i -lt $script:CProfiles.Count;$i++) {if ($script:CProfiles[$i].Id -eq $selected) {$script:CList.SelectedIndex=$i}}
}
$script:CList.Add_SelectedIndexChanged({if ($script:CList.SelectedIndex -ge 0) {
 $p=Selected-CProfile;$script:CName.Text=$p.Name;$script:CPathLabel.Text=$p.Path
 $script:CLaunchLabel.Text='Launch file: '+$(if ($p.Launch) {$p.Launch} else {'manually through your launcher'})
 $script:CPriority.SelectedItem=$p.Priority;$script:CPower.Checked=$p.Power;$script:CCapture.Checked=$p.CaptureOff;$script:CHud.Checked=$p.Hud
}})
function Save-CEditor {
 if ($script:CActive) {throw 'Stop Competitive Mode before editing the profile.'}
 $p=Selected-CProfile;$p.Name=$script:CName.Text.Trim();if (-not $p.Name) {throw 'Enter a game name.'}
 $p.Priority=[string]$script:CPriority.SelectedItem;$p.Power=$script:CPower.Checked;$p.CaptureOff=$script:CCapture.Checked;$p.Hud=$script:CHud.Checked
 Save-CProfile $p
}
$script:CHudForm=New-DashForm 'SCRP / Session HUD';$script:CHudForm.MinimumSize=New-Object Drawing.Size(380,210);$script:CHudForm.ClientSize=New-Object Drawing.Size(440,190);$script:CHudForm.TopMost=$true;$script:CHudForm.ShowInTaskbar=$false
$script:CHudLabel=Add-DashLabel $script:CHudForm 'READY' 18 18 405 110 12
$null=Add-DashButton $script:CHudForm 'Stop and restore' 18 140 400 {Stop-CMode}
$script:CHudForm.Add_FormClosing({param($sender,$event);$event.Cancel=$true;$script:CHudLabel.Visible=$false})
$script:CTimer=New-Object Windows.Forms.Timer;$script:CTimer.Interval=2000
function Set-CEditorLocked($locked) {
 foreach ($control in $script:CCanvas.Controls) {
  if ($control.Top -ge 154 -and $control.Top -le 615 -and $control -ne $script:CStopButton) {$control.Enabled=(-not $locked)}
 }
}
function Start-CMode {
 try {
  if ($script:CActive) {return}
  if (Test-Path $script:CJournal) {CLog 'Use the recovery button to restore the previous session first.';return}
  Save-CEditor;$script:CGame=Read-CProfile (Selected-CProfile).Id
  if ($script:CGame.Priority -eq 'High' -and [Windows.Forms.MessageBox]::Show('High priority may starve other tasks. Start this profile anyway?','SCREEPYOS','YesNo','Warning') -ne 'Yes') {return}
  if (-not (Request-GameBackgroundClose $script:CGame)) {CLog 'Session cancelled before any tweaks.';return}
  New-CSession $script:CGame
  $script:CActive=$true;$script:CSeen=$false;$script:CStarted=Get-Date;$script:CLastSeen=Get-Date;$script:CPrevious=@{};$script:CAttempts=@{}
  Set-CEditorLocked $true
  CLog 'Competitive Mode: Enabled. Waiting for the exact game path (up to 5 minutes).'
  if ($script:CGame.Launch -and @(Get-CProcesses $script:CGame).Count -eq 0) {Start-Process -FilePath $script:CGame.Launch | Out-Null}
  $script:CHudLabel.Visible=$script:CGame.Hud
  $script:CTimer.Start()
 } catch {CLog $_.Exception.Message;if (Test-Path $script:CJournal) {Stop-CMode}}
}
function Stop-CMode {
 $script:CTimer.Stop();$script:CActive=$false;$script:CHudLabel.Visible=$false;Set-CEditorLocked $false
 try {
  $fail=@(Restore-CSession)
  if ($fail.Count) {$script:CStatus.Text='STOPPED / recovery needs attention';CLog ($fail -join '; ')}
  else {$script:CStatus.Text='READY / Competitive Mode: Disabled';CLog 'Session stopped. Original session settings restored.'}
 } catch {CLog $_.Exception.Message;$script:CStatus.Text='STOPPED / recovery needs attention'}
}
$script:CTimer.Add_Tick({
 if (-not $script:CActive) {return}
 try {
  $targets=@(Get-CProcesses $script:CGame);$now=Get-Date;$cpu=0.0;$ram=0L;$levels=@()
  if ($targets.Count) {
   $script:CSeen=$true;$script:CLastSeen=$now
   foreach ($proc in $targets) {
    $key=$proc.Id.ToString()+'-'+$proc.StartTime.ToUniversalTime().Ticks.ToString()
    if (-not $script:CAttempts.ContainsKey($key)) {
     $script:CAttempts[$key]=$true
     try {Set-CPriority $proc $script:CGame.Priority;CLog ('Process '+$proc.Id+': '+$script:CGame.Priority)} catch {CLog ('Priority skipped: '+$_.Exception.Message)}
    }
    $proc.Refresh();$ms=$proc.TotalProcessorTime.TotalMilliseconds;$ram+=$proc.WorkingSet64;$levels+=$proc.PriorityClass.ToString()
    if ($script:CPrevious.ContainsKey($key)) {$old=$script:CPrevious[$key];$elapsed=($now-$old.Time).TotalMilliseconds;if ($elapsed -gt 0) {$cpu+=[math]::Max(0,100*($ms-$old.Cpu)/$elapsed/[Environment]::ProcessorCount)}}
    $script:CPrevious[$key]=@{Time=$now;Cpu=$ms}
   }
   $script:CStatus.Text='ACTIVE / '+$script:CGame.Name
   $script:CHudLabel.Text=('{0}`nCPU {1:N1}%  |  RAM {2:N0} MB`nPriority: {3}`nFPS: measure using frame-time CSV' -f $script:CGame.Name,$cpu,($ram/1048576),(($levels|Select-Object -Unique)-join ', ')).Replace('`n',"`n")
  } else {
   $script:CStatus.Text='WAITING / start '+$script:CGame.Name;$script:CHudLabel.Text=$script:CStatus.Text
   if (($script:CSeen -and ($now-$script:CLastSeen).TotalSeconds -ge 10) -or (-not $script:CSeen -and ($now-$script:CStarted).TotalMinutes -ge 5)) {CLog 'Game closed or wait time expired.';Stop-CMode}
  }
 } catch {CLog ('Monitoring stopped: '+$_.Exception.Message);Stop-CMode}
})
$script:CForm.Add_FormClosing({if ($script:CActive) {Stop-CMode}})
$script:CHudForm.Controls.Remove($script:CHudLabel)
$script:CCanvas.Controls.Add($script:CHudLabel)
$script:CHudLabel.SetBounds(26,818,880,115)
$script:CCanvas.AutoScrollMinSize=New-Object Drawing.Size(960,955)
$script:CHudLabel.Visible=$false
Refresh-CList $ProfileId
if (Test-Path $script:CJournal) {CLog 'Pending session backup found: select Recover previous session.'}
Mount-ScrpPage $script:CForm {
 $script:CTimer.Stop();if ($script:CActive) {Stop-CMode};$script:CTimer.Dispose();$script:CHudForm.Dispose();$tip.Dispose()
 if ($script:COwn) {$script:CMutex.ReleaseMutex()};$script:CMutex.Dispose()
}
