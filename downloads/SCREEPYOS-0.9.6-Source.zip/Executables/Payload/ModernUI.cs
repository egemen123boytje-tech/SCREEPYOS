using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace Scrp {
 public class DarkTabs : TabControl {
  public DarkTabs(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);BackColor=Color.FromArgb(14,14,16);}
  protected override void OnPaint(PaintEventArgs e){
   e.Graphics.Clear(Color.FromArgb(14,14,16));
   for(int i=0;i<TabCount;i++){Rectangle r=GetTabRect(i);bool active=i==SelectedIndex;
    using(Brush b=new SolidBrush(active?Color.FromArgb(48,48,54):Color.FromArgb(24,24,27))) e.Graphics.FillRectangle(b,r);
    TextRenderer.DrawText(e.Graphics,TabPages[i].Text,Font,r,active?Color.WhiteSmoke:Color.Silver,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);
    if(active)using(Pen p=new Pen(Color.Silver,2))e.Graphics.DrawLine(p,r.Left+12,r.Bottom-2,r.Right-12,r.Bottom-2);
   }
  }
 }
 public class Card : Button {
  public string Heading {get;set;}
  public string Description {get;set;}
  bool hover;
  public Card() { SetStyle(ControlStyles.OptimizedDoubleBuffer|ControlStyles.AllPaintingInWmPaint|ControlStyles.UserPaint,true); Cursor=Cursors.Hand; FlatStyle=FlatStyle.Flat; }
  protected override void OnMouseEnter(EventArgs e) {hover=true;Invalidate();base.OnMouseEnter(e);}
  protected override void OnMouseLeave(EventArgs e) {hover=false;Invalidate();base.OnMouseLeave(e);}
  protected override void OnPaint(PaintEventArgs e) {
   e.Graphics.Clear(Parent==null ? Color.FromArgb(14,14,16):Parent.BackColor);
   e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
   Rectangle r=new Rectangle(1,1,Width-3,Height-3);
   using(GraphicsPath p=new GraphicsPath()) {
    int d=20;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();
    using(Brush b=new SolidBrush(hover?Color.FromArgb(37,37,41):Color.FromArgb(24,24,27))) e.Graphics.FillPath(b,p);
    using(Pen pen=new Pen(Focused?Color.Silver:Color.FromArgb(48,48,53)))e.Graphics.DrawPath(pen,p);
   }
   using(Font h=new Font("Segoe UI",13,FontStyle.Bold))
    TextRenderer.DrawText(e.Graphics,Heading,h,new Rectangle(22,20,Width-64,28),Color.WhiteSmoke,TextFormatFlags.EndEllipsis);
   using(Font b=new Font("Segoe UI",10))
    TextRenderer.DrawText(e.Graphics,Description,b,new Rectangle(22,56,Width-44,Height-64),Color.FromArgb(168,168,178),TextFormatFlags.WordBreak);
   TextRenderer.DrawText(e.Graphics,"›",Font,new Rectangle(Width-38,20,24,28),Color.Silver);
  }
 }
 public sealed class SmoothScroll : IMessageFilter, IDisposable {
  readonly Form root; readonly Timer timer=new Timer(); ScrollableControl active; double target; bool disposed;
  public SmoothScroll(Form form) {root=form;timer.Interval=15;timer.Tick+=Tick;Application.AddMessageFilter(this);root.FormClosed+=(s,e)=>Dispose();}
  public static int Clamp(int value,int max) {return Math.Max(0,Math.Min(Math.Max(0,max),value));}
  public bool PreFilterMessage(ref Message m) {
   if(disposed || m.Msg!=0x20A || !root.Visible || !root.Enabled || !root.ContainsFocus)return false;
   Control c=root;Point screen=Control.MousePosition;
   if(!root.RectangleToScreen(root.ClientRectangle).Contains(screen))return false;
   while(true) {Control child=c.GetChildAtPoint(c.PointToClient(screen));if(child==null)break;c=child;}
   if(c is TextBoxBase || c is ListControl || c is DataGridView || c is NumericUpDown || c is TrackBar)return false;
   ScrollableControl panel=null;
   for(Control p=c;p!=null;p=p.Parent) {var scroll=p as ScrollableControl;if(scroll!=null && scroll.AutoScroll && scroll.VerticalScroll.Visible){panel=scroll;break;}}
   if(panel==null)return false;
   int lines=SystemInformation.MouseWheelScrollLines;if(lines==0)return false;
   int delta=(short)((m.WParam.ToInt64()>>16)&0xffff);
   if(active!=panel || !timer.Enabled){active=panel;target=-panel.AutoScrollPosition.Y;}
   int distance=lines<0?panel.ClientSize.Height:Math.Max(20,lines*24);
   target=Clamp((int)Math.Round(target-delta/120.0*distance),panel.DisplayRectangle.Height-panel.ClientSize.Height);
   timer.Start();return true;
  }
  void Tick(object sender,EventArgs e) {
   if(active==null || active.IsDisposed || !active.Visible){timer.Stop();return;}
   target=Clamp((int)target,active.DisplayRectangle.Height-active.ClientSize.Height);
   int current=-active.AutoScrollPosition.Y;double remaining=target-current;
   int next=Math.Abs(remaining)<2?(int)target:current+(int)(Math.Sign(remaining)*Math.Max(1,Math.Ceiling(Math.Abs(remaining)*0.28)));
   active.AutoScrollPosition=new Point(-active.AutoScrollPosition.X,next);
   if(next==(int)target)timer.Stop();
  }
  public void Dispose(){if(disposed)return;disposed=true;timer.Stop();timer.Dispose();Application.RemoveMessageFilter(this);active=null;}
 }
 public static class PaintTools {
  [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr handle,int attribute,ref int value,int size);
  public static void DarkTitle(Form form){int enabled=1;DwmSetWindowAttribute(form.Handle,20,ref enabled,4);}
  public static void Tabs(TabControl tabs) {
   if(tabs.DrawMode==TabDrawMode.OwnerDrawFixed)return;
   tabs.Appearance=TabAppearance.FlatButtons;tabs.DrawMode=TabDrawMode.OwnerDrawFixed;tabs.ItemSize=new Size(130,36);tabs.SizeMode=TabSizeMode.Fixed;
   tabs.DrawItem+=(s,e)=>{bool selected=e.Index==tabs.SelectedIndex;using(Brush b=new SolidBrush(selected?Color.FromArgb(54,54,60):Color.FromArgb(24,24,27)))e.Graphics.FillRectangle(b,e.Bounds);TextRenderer.DrawText(e.Graphics,tabs.TabPages[e.Index].Text,tabs.Font,e.Bounds,selected?Color.WhiteSmoke:Color.Silver,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);};
  }
  public static void Buffer(Control c){if(c is Panel || c is Form || c is TabControl)typeof(Control).GetProperty("DoubleBuffered",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(c,true,null);foreach(Control child in c.Controls)Buffer(child);}
 }
}
