﻿function Set-ScrpTheme($Root) {
 $Root.BackColor=[Drawing.Color]::FromArgb(14,14,16)
 if ('Scrp.PaintTools' -as [type]) {[Scrp.PaintTools]::Buffer($Root)}
 $Root.ForeColor=[Drawing.Color]::FromArgb(235,235,235)
 foreach ($c in $Root.Controls) {
  Set-ScrpTheme $c
  if ($c -is [Windows.Forms.TabControl]) {[Scrp.PaintTools]::Tabs($c)}
  if ($c -is [Windows.Forms.ComboBox]) {$c.FlatStyle='Flat'}
  if ($c -is [Windows.Forms.ListBox]) {$c.BorderStyle='None'}
  if ($c -is [Windows.Forms.TextBox]) {$c.BorderStyle='FixedSingle'}
  if ($c -is [Windows.Forms.Button]) {
   $c.FlatStyle='Flat';$c.FlatAppearance.BorderSize=0
   $c.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(65,65,65)
   $c.FlatAppearance.MouseOverBackColor=[Drawing.Color]::FromArgb(52,52,52)
   $c.BackColor=[Drawing.Color]::FromArgb(33,33,37)
   $c.UseMnemonic=$false;$c.Cursor=[Windows.Forms.Cursors]::Hand
  } elseif ($c -is [Windows.Forms.TextBox] -or $c -is [Windows.Forms.ListBox] -or $c -is [Windows.Forms.ComboBox]) {
   $c.BackColor=[Drawing.Color]::FromArgb(24,24,27)
  }
 }
}
