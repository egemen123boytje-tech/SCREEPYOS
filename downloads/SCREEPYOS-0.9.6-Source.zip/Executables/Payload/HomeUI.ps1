﻿# Overview has no timers, hardware polling or system mutations.
function New-ScrpHome($Panel,$Navigate) {
 $script:HomeNavigate=$Navigate
 $Panel.AutoScroll=$true;$Panel.BackColor=[Drawing.Color]::FromArgb(14,14,16)
 $flow=New-Object Windows.Forms.FlowLayoutPanel
 $flow.Dock='Top';$flow.AutoSize=$true;$flow.FlowDirection='TopDown';$flow.WrapContents=$false
 $flow.Padding=New-Object Windows.Forms.Padding(28,24,20,28);$Panel.Controls.Add($flow)
 $script:HomeFlow=$flow
 $script:HomeArtwork=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'assets\SCRP-OS.png'))
 $hero=New-Object Windows.Forms.Panel;$hero.Size=New-Object Drawing.Size(690,190);$hero.BackColor=[Drawing.Color]::Black
 $hero.Add_Paint({param($sender,$event)
  $g=$event.Graphics;$g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  if ($sender.Width -ge 760) {
  $artWidth=[math]::Min(460,[int]($sender.Width*0.55))
  $g.DrawImage($script:HomeArtwork,(New-Object Drawing.Rectangle(($sender.Width-$artWidth),0,$artWidth,$sender.Height)))
  $fade=New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Point(($sender.Width-$artWidth),0)),(New-Object Drawing.Point(($sender.Width-$artWidth+140),0)),[Drawing.Color]::Black,[Drawing.Color]::Transparent)
  try {$g.FillRectangle($fade,($sender.Width-$artWidth),0,140,$sender.Height)} finally {$fade.Dispose()}
  }
  foreach ($spec in @(@('SCREEPYOS / GAMING PC',10,14),@('Your gaming workspace.',23,51),@('Set up. Play. Compare.',10,121))) {
   $font=New-Object Drawing.Font('Segoe UI',[single]$spec[1])
   $brush=if ($spec[1] -eq 23) {[Drawing.Brushes]::WhiteSmoke} else {[Drawing.Brushes]::DarkGray}
   try {$g.DrawString([string]$spec[0],$font,$brush,[single]8,[single]$spec[2])} finally {$font.Dispose()}
  }
 })
 $hero.AccessibleName='SCREEPYOS Gaming PC. Ready for your next game. Your games, your settings, measured results.'
 $flow.Controls.Add($hero)
 $script:HomeStatus=New-Object Windows.Forms.Label
 $script:HomeStatus.Size=New-Object Drawing.Size(690,66);$script:HomeStatus.Padding=New-Object Windows.Forms.Padding(18,14,12,10)
 $script:HomeStatus.BackColor=[Drawing.Color]::FromArgb(24,24,24);$script:HomeStatus.ForeColor=[Drawing.Color]::FromArgb(225,225,225)
 $flow.Controls.Add($script:HomeStatus)
 $script:HomeGrid=New-Object Windows.Forms.TableLayoutPanel;$script:HomeGrid.Size=New-Object Drawing.Size(690,304);$script:HomeGrid.Margin=New-Object Windows.Forms.Padding(0,14,0,0);$flow.Controls.Add($script:HomeGrid)
 $script:HomeCards=@()
 foreach ($card in @(
  @('01  GAME LIBRARY','Save per-game options, then start or recover a session.','Competitive'),
  @('02  BENCHMARKS','Compare repeated runs: average FPS, 1% lows and P99.','Metrics'),
  @('03  PERFORMANCE LAB','Per-game app choices, graphics snapshots and timed measurements.','Performance'),
  @('04  OPTIONAL CLEANUP','Choose each removal yourself. Keep the apps you use.','Gaming'))) {
  $button=New-Object Scrp.Card;$button.Heading=$card[0].Substring(4);$button.Description=$card[1];$button.Tag=$card[2]
  $button.Text=$button.Heading;$button.AccessibleName=$button.Heading+'. '+$button.Description
  $button.Dock='Fill';$button.Margin=New-Object Windows.Forms.Padding(0,0,12,12)
  $button.Add_Click({param($sender,$event) & $script:HomeNavigate ([string]$sender.Tag)})
  $script:HomeCards+=,$button;$script:HomeGrid.Controls.Add($button)
 }
 $note=New-Object Windows.Forms.Label;$note.Size=New-Object Drawing.Size(690,55);$note.Margin=New-Object Windows.Forms.Padding(3,22,3,0)
 $note.Text='Measured results, no invented boost scores. Changes depend on your PC and game. Removed apps require reinstallation; settings recovery is available in each relevant page.'
 $note.ForeColor=[Drawing.Color]::FromArgb(155,155,155);$flow.Controls.Add($note)
 $flow.Add_SizeChanged({Resize-ScrpHome})
 $Panel.Add_SizeChanged({Resize-ScrpHome})
 Resize-ScrpHome
 Update-ScrpHome
}
function Update-ScrpHome {
 $root=Join-Path $env:LOCALAPPDATA 'SCREEPYOS'
 $count=@(Get-ChildItem (Join-Path $root 'CompetitiveProfiles') -Filter '*.json' -ErrorAction SilentlyContinue).Count
 $state='READY TO PLAY'
 if (Test-Path (Join-Path $root 'competitive-session.json')) {$state='SESSION SETTINGS SAVED / open Game library to view or recover'}
 $script:HomeStatus.Text=$state+"`r`n"+$count+' saved game profile(s)  /  FPS: measure in Benchmarks'
}



function Resize-ScrpHome {
 if (-not $script:HomeFlow) {return}
 $width=[math]::Max(320,$script:HomeFlow.Parent.ClientSize.Width-68)
 foreach ($child in $script:HomeFlow.Controls) {$child.Width=$width}
 $grid=$script:HomeGrid;$cols=if($width -ge 650){2}else{1}
 $grid.SuspendLayout();$grid.ColumnCount=$cols;$grid.RowCount=4/$cols
 $grid.ColumnStyles.Clear();$grid.RowStyles.Clear()
 for($i=0;$i -lt $cols;$i++){[void]$grid.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',(100/$cols))))}
 for($i=0;$i -lt $grid.RowCount;$i++){[void]$grid.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',146)))}
 for($i=0;$i -lt $script:HomeCards.Count;$i++){$grid.SetCellPosition($script:HomeCards[$i],(New-Object Windows.Forms.TableLayoutPanelCellPosition(($i % $cols),([math]::Floor($i/$cols)))))}
 $grid.Height=146*$grid.RowCount;$grid.ResumeLayout()
}
