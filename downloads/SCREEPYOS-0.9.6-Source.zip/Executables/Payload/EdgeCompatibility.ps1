﻿# Mechanism reference: ChrisTitusTech/winutil, config/tweaks.json, WPFTweaksRemoveEdge.
# Independent implementation: never overwrite a legacy binary or delete profiles.
function Assert-ScrpPlainPath([string]$Path) {
 $current=[IO.Path]::GetFullPath($Path)
 while ($current) {
  if (Test-Path -LiteralPath $current) {
   if ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Edge path contains a link; stopped.'}
  }
  $parent=Split-Path -Path $current -Parent
  if ($parent -eq $current) {break};$current=$parent
 }
}
function New-ScrpEdgePlaceholder {
 $systemApps=Join-Path $env:SystemRoot 'SystemApps'
 $folder=Join-Path $systemApps 'Microsoft.MicrosoftEdge_8wekyb3d8bbwe'
 $path=Join-Path $folder 'MicrosoftEdge.exe'
 Assert-ScrpPlainPath $path
 if (-not (Test-Path -LiteralPath $systemApps -PathType Container)) {throw 'Windows SystemApps directory not found.'}
 if (Test-Path -LiteralPath $path) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {throw 'Legacy Edge path is not a file.'}
  return [pscustomobject]@{Status='Existing legacy file preserved';Path=$path;Created=$false}
 }
 if (-not (Test-Path -LiteralPath $folder)) {New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null}
 Assert-ScrpPlainPath $path
 # CreateNew atomically refuses to replace a file created in the meantime.
 $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 $stream.Dispose()
 [pscustomobject]@{Status='Empty legacy placeholder created';Path=$path;Created=$true;CreatedUtc=(Get-Item -LiteralPath $path).CreationTimeUtc.ToString('o')}
}
