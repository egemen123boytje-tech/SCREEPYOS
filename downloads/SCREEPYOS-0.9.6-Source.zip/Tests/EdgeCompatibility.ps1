﻿param([Parameter(Mandatory=$true)][string]$TestRoot)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Executables/Payload/EdgeCompatibility.ps1')
$savedRoot=$env:SystemRoot
try {
 $env:SystemRoot=$TestRoot
 New-Item -ItemType Directory -Path (Join-Path $TestRoot 'SystemApps') -Force | Out-Null
 $first=New-ScrpEdgePlaceholder
 if (-not $first.Created -or (Get-Item -LiteralPath $first.Path).Length -ne 0) {throw 'Placeholder not created'}
 $second=New-ScrpEdgePlaceholder
 if ($second.Created) {throw 'Existing placeholder replaced'}
 [IO.File]::WriteAllText($first.Path,'existing legacy executable fixture')
 $hash=[IO.File]::ReadAllText($first.Path)
 $third=New-ScrpEdgePlaceholder
 if ($third.Created -or [IO.File]::ReadAllText($first.Path) -ne $hash) {throw 'Existing binary overwritten'}
 # A linked legacy directory must never be followed.
 $linkedRoot=Join-Path $TestRoot 'linked-case'
 New-Item -ItemType Directory -Path (Join-Path $linkedRoot 'SystemApps') -Force | Out-Null
 New-Item -ItemType Junction -Path (Join-Path $linkedRoot 'SystemApps/Microsoft.MicrosoftEdge_8wekyb3d8bbwe') -Target (Split-Path $first.Path) | Out-Null
 $env:SystemRoot=$linkedRoot;$blocked=$false
 try {New-ScrpEdgePlaceholder | Out-Null} catch {$blocked=$true}
 if (-not $blocked) {throw 'Linked path accepted'}
 $source=Get-Content (Join-Path $PSScriptRoot '../Executables/Payload/Gaming-Machine.ps1') -Raw
 if ($source.Contains('--delete-profile') -or -not $source.Contains("`$edgeArguments+=' --force-uninstall'")) {throw 'Bad uninstaller flags'}
 if ($source.IndexOf('Invalid Microsoft signature.') -gt $source.IndexOf('$placeholder=New-ScrpEdgePlaceholder')) {throw 'Signature check must precede mutation'}
 [xml]$config=Get-Content (Join-Path $PSScriptRoot '../playbook.conf') -Raw
 $option=@($config.Playbook.FeaturePages.CheckboxPage.Options.CheckboxOption | Where-Object Name -eq 'edge-compatibility')
 if ($option.Count -ne 1 -or $option[0].IsChecked -ne 'false') {throw 'Advanced removal must be optional'}
 $actions=Get-Content (Join-Path $PSScriptRoot '../Configuration/main.yml') -Raw
 if ([regex]::Matches($actions,'-Stage RemoveEdge -EdgeCompatibility').Count -ne 2) {throw 'Missing install/upgrade wiring'}
 Write-Output 'PASS: creation, repeat, existing file preservation, junction rejection, flags, signature ordering, opt-in and install/upgrade wiring.'
} finally {$env:SystemRoot=$savedRoot}
