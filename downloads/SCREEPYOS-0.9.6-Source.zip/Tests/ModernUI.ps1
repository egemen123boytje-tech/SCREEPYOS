$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
Add-Type -Path (Join-Path $PSScriptRoot '../Executables/Payload/ModernUI.cs') -ReferencedAssemblies System.Windows.Forms,System.Drawing
$f=New-Object Windows.Forms.Form;$f.ShowInTaskbar=$false;$f.StartPosition='Manual';$f.Location=New-Object Drawing.Point(-32000,-32000)
$p=New-Object Windows.Forms.Panel;$p.Dock='Fill';$p.AutoScroll=$true;$p.AutoScrollMinSize=New-Object Drawing.Size(100,2000);$f.Controls.Add($p)
$f.Show();[Windows.Forms.Application]::DoEvents()
$smooth=New-Object Scrp.SmoothScroll($f)
try {
 $type=$smooth.GetType();$flags=[Reflection.BindingFlags]'NonPublic,Instance'
 $type.GetField('active',$flags).SetValue($smooth,$p)
 $type.GetField('target',$flags).SetValue($smooth,[double]500)
 $tick=$type.GetMethod('Tick',$flags)
 $tick.Invoke($smooth,@($null,[EventArgs]::Empty)) | Out-Null
 if (-$p.AutoScrollPosition.Y -le 0 -or -$p.AutoScrollPosition.Y -ge 500) {throw 'Scroll did not ease toward target'}
 for($i=0;$i -lt 50;$i++) {$tick.Invoke($smooth,@($null,[EventArgs]::Empty))|Out-Null}
 if (-$p.AutoScrollPosition.Y -ne 500) {throw 'Scroll did not settle'}
 if ([Scrp.SmoothScroll]::Clamp(-10,100) -ne 0 -or [Scrp.SmoothScroll]::Clamp(200,100) -ne 100) {throw 'Scroll clamp failed'}
 $timer=$type.GetField('timer',$flags).GetValue($smooth)
 if ($timer.Enabled) {throw 'Scroll timer running when idle'}
 $smooth.Dispose();$smooth.Dispose()
 $image=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot '../Executables/Payload/assets/SCRP-OS.png'))
 try {if ($image.Width -ne 3840 -or $image.Height -ne 2160) {throw 'Wallpaper is not 4K'}} finally {$image.Dispose()}
 Write-Output 'PASS: native scroll easing, settling, bounds, idle timer, repeated disposal and exact 4K dimensions.'
} finally {$smooth.Dispose();$f.Dispose()}
