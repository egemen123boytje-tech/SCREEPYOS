﻿#requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'ProfilesEngine.ps1')
[Windows.Forms.Application]::EnableVisualStyles()
$form=New-Object Windows.Forms.Form
$form.Text='SCREEPYOS 0.9.0 - Gaming-only';$form.Size=New-Object Drawing.Size(1000,730);$form.MinimumSize=New-Object Drawing.Size(640,460)
$form.BackColor=[Drawing.Color]::FromArgb(28,28,28);$form.ForeColor=[Drawing.Color]::White
$panel=New-Object Windows.Forms.Panel;$panel.Dock='Fill';$panel.AutoScroll=$true;$panel.AutoScrollMinSize=New-Object Drawing.Size(900,885);$form.Controls.Add($panel)
function Label($text,$x,$y,$w,$h) {$c=New-Object Windows.Forms.Label;$c.Text=$text;$c.SetBounds($x,$y,$w,$h);$panel.Controls.Add($c)}
function Button($text,$x,$y,$w,$action) {$b=New-Object Windows.Forms.Button;$b.Text=$text;$b.SetBounds($x,$y,$w,34);$b.BackColor=[Drawing.Color]::FromArgb(60,60,60);$b.Add_Click($action);$panel.Controls.Add($b)}
Label 'OPTIONAL CLEANUP: select what to remove. Apps are removed for this Windows account.' 15 15 865 25
Label 'Xbox, Store, WebView2, drivers, networking, audio and security are kept. App data may be lost.' 15 43 865 35
$apps=New-Object Windows.Forms.CheckedListBox;$apps.SetBounds(15,83,420,245);$apps.CheckOnClick=$true;$apps.DisplayMember='Label';$panel.Controls.Add($apps)
$catalog=Get-Content (Join-Path $PSScriptRoot 'gaming-apps.json') -Raw|ConvertFrom-Json
$installed=@(Get-AppxPackage)
foreach ($a in $catalog) {
 foreach ($pkg in @($installed|Where-Object {$_.Name -eq $a.package -and -not $_.IsFramework -and -not $_.NonRemovable})) {
  [void]$apps.Items.Add([pscustomobject]@{Label=$pkg.Name;Package=$pkg},$false)
 }
}
$features=New-Object Windows.Forms.CheckedListBox;$features.SetBounds(450,83,430,245);$features.CheckOnClick=$true;$features.HorizontalScrollbar=$true;$features.DisplayMember='Label';$panel.Controls.Add($features)
foreach ($entry in @(
 @('DeliveryPeers','Update uploads to other PCs: Disabled',$false),
 @('FastStartup','Fast Startup: Disabled (slower startup)',$false),
 @('RecallSnapshots','Recall snapshots: Disabled (existing snapshots deleted)',$false),
 @('WebSearch','Bing web results: Disabled (Enterprise/Education)',$false),
 @('OneDrive','Block OneDrive sync; keep files',$false),
 @('Widgets','Disable Widgets (Pro/Enterprise/Education)',$false),
 @('Fax','Disable Fax service', $false),@('MapsBroker','Disable downloaded offline maps service',$false),
 @('RetailDemo','Disable retail demo',$false),@('RemoteRegistry','Disable Remote Registry',$false),
 @('WMPNetworkSvc','Disable Media Player network sharing',$false),@('DiagTrack','Disable diagnostic tracking service',$false),
 @('Bluetooth','Disable Bluetooth (headsets, controllers, mouse/keyboard)',$false),
 @('Spooler','Disable all printing (including Print to PDF)',$false),
 @('WSearch','Disable search indexing (search may be slower)',$false))) {
 [void]$features.Items.Add([pscustomobject]@{Id=$entry[0];Label=$entry[1]},[bool]$entry[2])
}
Label 'Apply enables Game Mode and reduces suggestions. Other changes require your selection. Download OneDrive online-only files first if needed offline. Services stop after a restart.' 15 337 865 45
$office=New-Object Windows.Forms.CheckBox;$office.Text='Also remove the entire Office Click-to-Run suite: Word, Excel, PowerPoint, Outlook, Visio/Project';$office.Checked=$false;$office.SetBounds(15,390,865,30);$panel.Controls.Add($office)
Label 'Office: internet and UAC required; the Microsoft tool is verified. Close Office first. Documents are kept; reinstalling needs an installer/license. Remove older MSI Office through Settings > Apps.' 15 425 865 40
$script:ScrpLogTextBox=New-Object Windows.Forms.TextBox;$script:ScrpLogTextBox.Multiline=$true;$script:ScrpLogTextBox.ReadOnly=$true;$script:ScrpLogTextBox.ScrollBars='Vertical';$script:ScrpLogTextBox.SetBounds(15,605,865,260);$panel.Controls.Add($script:ScrpLogTextBox)
function Log($s) {$script:ScrpLogTextBox.AppendText($s+[Environment]::NewLine);$script:ScrpLogTextBox.Refresh()}
function Machine($mode,$names) {
 Invoke-ScrpMachine $mode $names {param($message) Log $message}
}
$energy=New-Object Windows.Forms.CheckBox;$energy.Text='High performance on AC power (only if this power plan is available)';$energy.Checked=$false;$energy.SetBounds(15,550,865,35);$panel.Controls.Add($energy)
Button 'Apply selection' 15 480 220 {
 $answer=[Windows.Forms.MessageBox]::Show('Remove the selected apps and, if selected, the entire Office suite? App data may be lost. System changes require UAC. Make a full backup first.','Apply Gaming-only','YesNo','Warning')
 if ($answer -ne 'Yes') {return}
 $panel.Enabled=$false
 try {
  $names=@($features.CheckedItems|ForEach-Object {$_.Id})
  $opts=[pscustomobject]@{Theme=$false;GameMode=$true;Capture=$false;Quiet=$true;Animations=$false;EdgeBackground=$false;OneDriveStartup=($names -contains 'OneDrive')}
  $packages=@($apps.CheckedItems|ForEach-Object {$_.Package})
  $result=Invoke-ScrpApply $opts $packages '' {param($s) Log $s}
  Log 'User settings processed. Restart after all actions are complete.'
  if ($energy.Checked) {
   try {
    if ([Windows.Forms.SystemInformation]::PowerStatus.PowerLineStatus -ne 'Online') {throw 'Power plan skipped: connect the AC adapter.'}
    Log (Set-ScrpPower '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c')
   } catch {Log $_.Exception.Message}
  }
  if ($names.Count) {try {Machine 'Apply' $names} catch {Log $_.Exception.Message}}
  if ($office.Checked) {try {Machine 'Office' @()} catch {Log $_.Exception.Message}}
 } catch {Log $_.Exception.Message} finally {$panel.Enabled=$true}
}
Button 'Restore user settings' 250 480 250 {try {Invoke-ScrpRestore {param($s) Log $s}|Out-Null} catch {Log $_.Exception.Message}}
Button 'Restore system settings' 515 480 235 {try {Machine 'Restore' @()} catch {Log $_.Exception.Message}}
Button 'Power' 765 480 115 {& $script:Navigate 'Hardware'}
Label 'Restore reverses the latest step. Removed apps/Office are not reinstalled. No guaranteed FPS gains.' 15 520 865 25
Mount-ScrpPage $form {}
