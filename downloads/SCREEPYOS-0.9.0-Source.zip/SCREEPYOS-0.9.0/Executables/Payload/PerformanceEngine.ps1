﻿# Standard-user engine. No driver, GPU selection or security changes.
. (Join-Path $PSScriptRoot 'CompetitiveEngine.ps1')
$script:TuningRoot=Join-Path $script:DataRoot 'PerformanceProfiles'
function Get-TuningFolder($Game) {
 Test-CProfile $Game
 return (Join-Path $script:TuningRoot $Game.Id)
}
function Read-Tuning($Game) {
 $file=Join-Path (Get-TuningFolder $Game) 'settings.json'
 if (Test-Path -LiteralPath $file) {return (Get-Content -LiteralPath $file -Raw|ConvertFrom-Json)}
 return [pscustomobject]@{Version=1;Background=@();Tier='Mid';Config=''}
}
function Save-Tuning($Game,$Settings) {
 $folder=Get-TuningFolder $Game;New-Item -ItemType Directory -Path $folder -Force|Out-Null
 Write-JsonFile (Join-Path $folder 'settings.json') $Settings
}
function Test-BackgroundTarget($Path,$GamePath) {
 if (-not $Path -or -not [IO.Path]::IsPathRooted($Path)) {return $false}
 if ($Path -eq $GamePath -or $Path.StartsWith($env:SystemRoot+'\',[StringComparison]::OrdinalIgnoreCase)) {return $false}
 $name=[IO.Path]::GetFileNameWithoutExtension($Path)
 return $name -notin @('steam','EpicGamesLauncher','Battle.net','XboxPcApp','RiotClientServices','EADesktop','UbisoftConnect','SCREEPYOS','powershell','pwsh','cmd','explorer','Taskmgr','SecurityHealthSystray','MsMpEng','ApplicationFrameHost')
}
function Get-BackgroundCandidates($Game) {
 foreach ($proc in @(Get-Process)) {
  try {
   if ($proc.Id -eq $PID -or $proc.SessionId -ne [Diagnostics.Process]::GetCurrentProcess().SessionId -or $proc.MainWindowHandle -eq [IntPtr]::Zero) {continue}
   if (-not (Test-BackgroundTarget $proc.Path $Game.Path)) {continue}
   [pscustomobject]@{Id=$proc.Id;Stamp=$proc.StartTime.ToUniversalTime().Ticks.ToString();Path=$proc.Path;Label=($proc.ProcessName+' / '+$proc.MainWindowTitle)}
  } catch {}
 }
}
function Close-BackgroundCandidate($Candidate,$Game) {
 $proc=Get-Process -Id $Candidate.Id -ErrorAction SilentlyContinue
 if (-not $proc) {return 'Already closed.'}
 if ($proc.StartTime.ToUniversalTime().Ticks.ToString() -ne $Candidate.Stamp -or $proc.Path -ne $Candidate.Path -or $proc.SessionId -ne [Diagnostics.Process]::GetCurrentProcess().SessionId -or -not (Test-BackgroundTarget $proc.Path $Game.Path)) {throw 'Process identity changed; skipped.'}
 if ($proc.CloseMainWindow()) {return ('Close requested: '+$Candidate.Label+'. Save prompts may remain open.')}
 return ('No close request accepted: '+$Candidate.Label)
}
function Request-GameBackgroundClose($Game) {
 $settings=Read-Tuning $Game
 $targets=@(Get-BackgroundCandidates $Game|Where-Object {$settings.Background -contains $_.Path})
 if (-not $targets.Count) {return $true}
 $message="Request these windows to close? Save your work first. Apps may show save prompts and are never forcibly killed. They are not reopened automatically.`r`n`r`n"+($targets.Label -join "`r`n")
 if ([Windows.Forms.MessageBox]::Show($message,'Before your game','OKCancel','Warning') -ne 'OK') {return $false}
 foreach ($target in $targets) {try {$null=Close-BackgroundCandidate $target $Game} catch {[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Window skipped')|Out-Null}}
 return $true
}
function Get-ConfigHash($Path) {return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
function Assert-ConfigPath($Path) {
 if (-not [IO.Path]::IsPathRooted($Path) -or [IO.Path]::GetExtension($Path) -notin @('.ini','.cfg','.json','.xml','.txt')) {throw 'Choose an existing text game-settings file: ini, cfg, json, xml or txt.'}
 $item=Get-Item -LiteralPath $Path -ErrorAction Stop
 if ($item.PSIsContainer -or $item.Length -gt 5MB) {throw 'Config must be a file no larger than 5 MB.'}
 $full=$item.FullName
 foreach ($blocked in @($env:SystemRoot,$script:DataRoot)) {if ($full.StartsWith($blocked.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'System and SCREEPYOS files are not game configuration targets.'}}
 $node=$item
 while ($node) {if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Linked config files/folders are not supported.'};$node=if ($node -is [IO.FileInfo]) {$node.Directory} else {$node.Parent}}
 return $full
}
function Assert-GameClosed($Game) {if (@(Get-CProcesses $Game).Count) {throw 'Close this game before changing or saving its configuration.'}}
function Save-GameSnapshot($Game,$Path,$Tier) {
 Invoke-ScrpLocked {
  if ($Tier -notin @('Low','Mid','High','Custom')) {throw 'Unknown preset slot.'}
  Assert-GameClosed $Game;$target=Assert-ConfigPath $Path
  $folder=Get-TuningFolder $Game;New-Item -ItemType Directory $folder -Force|Out-Null
  if (Test-Path (Join-Path $folder 'config-journal.json')) {throw 'Restore or keep the active config experiment before saving another snapshot.'}
  $bytes=[IO.File]::ReadAllBytes($target);$sourceHash=Get-ConfigHash $target
  $blob=Join-Path $folder ([guid]::NewGuid().ToString('N')+'.snapshot')
  [IO.File]::WriteAllBytes($blob,$bytes)
  if ((Get-ConfigHash $blob) -ne $sourceHash) {throw 'Config changed while reading; snapshot was not saved.'}
  Write-JsonFile (Join-Path $folder ($Tier+'.json')) ([pscustomobject]@{Version=1;Target=$target;Blob=[IO.Path]::GetFileName($blob);Hash=$sourceHash;Tier=$Tier;Created=(Get-Date).ToString('o')})
 }
}
function Get-SnapshotBlob($Folder,$Name) {
 if ($Name -notmatch '^[0-9a-f]{32}\.snapshot$') {throw 'Invalid snapshot name.'}
 $file=Join-Path $Folder $Name
 if ((Get-Item -LiteralPath $file).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Linked snapshot rejected.'}
 return $file
}
function Write-ConfigAtomically($Target,$Bytes) {
 $temp=$Target+'.scrp-'+[guid]::NewGuid().ToString('N')+'.tmp'
 try {[IO.File]::WriteAllBytes($temp,$Bytes);[IO.File]::Replace($temp,$Target,[System.Management.Automation.Language.NullString]::Value)}
 finally {if (Test-Path -LiteralPath $temp) {Remove-Item -LiteralPath $temp -Force}}
}
function Apply-GameSnapshot($Game,$Tier) {
 Invoke-ScrpLocked {
  if ($Tier -notin @('Low','Mid','High','Custom')) {throw 'Unknown preset slot.'}
  Assert-GameClosed $Game;$folder=Get-TuningFolder $Game;$journal=Join-Path $folder 'config-journal.json'
  if (Test-Path $journal) {throw 'An experiment is pending. Restore or keep it first.'}
  $snapshot=Get-Content (Join-Path $folder ($Tier+'.json')) -Raw|ConvertFrom-Json
  $target=Assert-ConfigPath $snapshot.Target;$blob=Get-SnapshotBlob $folder $snapshot.Blob
  if ((Get-ConfigHash $blob) -ne $snapshot.Hash) {throw 'Snapshot integrity check failed.'}
  $before=[IO.File]::ReadAllBytes($target);$beforeHash=Get-ConfigHash $target
  $backup=Join-Path $folder ([guid]::NewGuid().ToString('N')+'.snapshot');[IO.File]::WriteAllBytes($backup,$before)
  if ((Get-ConfigHash $backup) -ne $beforeHash) {throw 'Config changed while backing up; not applied.'}
  Write-JsonFile $journal ([pscustomobject]@{Version=1;Target=$target;Before=[IO.Path]::GetFileName($backup);BeforeHash=$beforeHash;AppliedHash=$snapshot.Hash;Tier=$Tier})
  if ((Get-ConfigHash $target) -ne $beforeHash) {throw 'Config changed before apply; original backup retained.'}
  Write-ConfigAtomically $target ([IO.File]::ReadAllBytes($blob))
  if ((Get-ConfigHash $target) -ne $snapshot.Hash) {throw 'Apply verification failed; recovery journal retained.'}
 }
}
function Get-ConfigExperimentPreview($Game) {
 $file=Join-Path (Get-TuningFolder $Game) 'config-journal.json'
 $journal=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json
 $target=Assert-ConfigPath $journal.Target
 [pscustomobject]@{Target=$target;CurrentHash=(Get-ConfigHash $target);BeforeHash=$journal.BeforeHash;AppliedHash=$journal.AppliedHash}
}
function Finish-ConfigExperiment($Game,[switch]$Keep,[string]$ExpectedCurrentHash='') {
 Invoke-ScrpLocked {
  Assert-GameClosed $Game;$folder=Get-TuningFolder $Game;$file=Join-Path $folder 'config-journal.json'
  if (-not (Test-Path $file)) {throw 'No pending config experiment for this game.'}
  $journal=Get-Content $file -Raw|ConvertFrom-Json
  $target=Assert-ConfigPath $journal.Target
  if (-not $Keep) {
   $current=Get-ConfigHash $target
   if ($current -ne $journal.BeforeHash) {
    if ($current -ne $journal.AppliedHash) {
     if (-not $ExpectedCurrentHash -or $current -ne $ExpectedCurrentHash) {throw 'The game or another app changed this config. Automatic restore stopped; your original snapshot is retained in PerformanceProfiles.'}
     $conflictCopy=Join-Path $folder ([guid]::NewGuid().ToString('N')+'.snapshot')
     [IO.File]::WriteAllBytes($conflictCopy,[IO.File]::ReadAllBytes($target))
     if ((Get-ConfigHash $conflictCopy) -ne $current) {throw 'Config changed again; restore stopped.'}
     $journal|Add-Member NoteProperty Displaced ([IO.Path]::GetFileName($conflictCopy)) -Force
     $journal|Add-Member NoteProperty DisplacedHash $current -Force
     Write-JsonFile $file $journal
    }
    $backup=Get-SnapshotBlob $folder $journal.Before
    if ((Get-ConfigHash $backup) -ne $journal.BeforeHash) {throw 'Backup integrity check failed.'}
    if ((Get-ConfigHash $target) -ne $current) {throw 'Config changed again before restore; no overwrite performed.'}
    Write-ConfigAtomically $target ([IO.File]::ReadAllBytes($backup))
    if ((Get-ConfigHash $target) -ne $journal.BeforeHash) {throw 'Restore verification failed.'}
   }
  }
  Move-Item -LiteralPath $file -Destination (Join-Path $folder ('completed-'+[guid]::NewGuid().ToString('N')+'.json'))
 }
}
