﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
try {
    $os = Get-CimInstance Win32_OperatingSystem
    if ([int]$os.BuildNumber -lt 22000 -or $os.ProductType -ne 1) { throw 'This package is intended for Windows 11.' }
    if (-not [Environment]::Is64BitProcess) { throw 'Use the 64-bit Windows PowerShell launcher.' }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Start normally by double-clicking, not as administrator. This page only changes your own user profile.'
    }
    . (Join-Path $PSScriptRoot 'Engine.ps1')
    $mutex = New-Object Threading.Mutex($false, ('Local\SCREEPYOS-' + $script:Sid))
    if (-not $mutex.WaitOne(0)) { throw 'SCREEPYOS is already open.' }
    $catalog = @(Get-Content (Join-Path $PSScriptRoot 'apps.json') -Raw | ConvertFrom-Json)
    $wallpaper = Join-Path $PSScriptRoot 'assets\SCRP-OS.png'
    $form = New-Object Windows.Forms.Form
    $form.Text = 'SCREEPYOS | SCRP OS 0.9.0 - Xbox kept'
    $form.ClientSize = New-Object Drawing.Size(1000,650)
    $form.MinimumSize = New-Object Drawing.Size(760,500)
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = [Drawing.Color]::FromArgb(16,16,18)
    $form.ForeColor = [Drawing.Color]::FromArgb(225,225,228)
    $form.Font = New-Object Drawing.Font('Segoe UI',10)
    $form.AutoScaleMode = [Windows.Forms.AutoScaleMode]::Dpi
$canvas=New-Object Windows.Forms.Panel
$canvas.Dock='Fill';$canvas.AutoScroll=$true
$canvas.AutoScrollMinSize=New-Object Drawing.Size(1080,780)
$form.Controls.Add($canvas)
    function Label($Text,$X,$Y,$W,$H,$Size=10) {
        $c=New-Object Windows.Forms.Label
        $c.Text=$Text; $c.Location=New-Object Drawing.Point($X,$Y); $c.Size=New-Object Drawing.Size($W,$H)
        $c.Font=New-Object Drawing.Font('Segoe UI',$Size)
        $canvas.Controls.Add($c); return $c
    }
    function Button($Text,$X,$Y,$W,$Action) {
        $b=New-Object Windows.Forms.Button
        $b.Text=$Text; $b.Location=New-Object Drawing.Point($X,$Y); $b.Size=New-Object Drawing.Size($W,36)
        $b.FlatStyle='Flat'; $b.BackColor=[Drawing.Color]::FromArgb(42,42,46)
        $b.ForeColor=$form.ForeColor
        $b.Add_Click($Action); $canvas.Controls.Add($b); return $b
    }
    function Check($Text,$X,$Y,$Checked=$true) {
        $c=New-Object Windows.Forms.CheckBox
        $c.Text=$Text; $c.Location=New-Object Drawing.Point($X,$Y); $c.Size=New-Object Drawing.Size(505,30)
        $c.Checked=$Checked; $canvas.Controls.Add($c); return $c
    }
    $null=Label 'S C R P  O S' 28 20 520 55 30
    $null=Label 'THEME & RECOVERY / settings for your Windows account' 30 79 680 25
    $null=Button 'GAMING-ONLY / advanced cleanup' 30 107 680 {& $script:Navigate 'Gaming'}
    $picture=New-Object Windows.Forms.PictureBox
    $picture.Location=New-Object Drawing.Point(746,15); $picture.Size=New-Object Drawing.Size(306,172)
    $picture.SizeMode='Zoom'; $picture.Image=[Drawing.Image]::FromFile($wallpaper)
    $canvas.Controls.Add($picture)
    $null=Button 'Drivers' 565 155 175 { & $script:Navigate 'Drivers' }
    $null=Button 'Game Center' 365 155 175 { & $script:Navigate 'Metrics' }
    $null=Button 'Hardware profiles' 30 150 300 { & $script:Navigate 'Hardware' }
    $theme=Check 'Black and gray theme + included SCRP OS wallpaper' 30 195
    $game=Check 'Enable Game Mode' 30 230
    $capture=Check 'Disable Xbox game recording (excluded from this profile)' 30 265 $false
    $capture.Enabled=$false
    $quiet=Check 'Fewer suggestions and ads' 30 300
    $anim=Check 'Reduce window and taskbar animations' 30 335
    $null=Label "Kept by this page: Store, WinGet, Defender, Windows Update, Edge/WebView2,`r`naudio, Bluetooth, Wi-Fi, printing, search and gaming services." 30 379 505 52
    $null=Label "Xbox and game recording are left unchanged. No overclocking or`r`nunverified timer, network or memory tweaks." 30 441 505 47
    $null=Label 'REMOVE APPS  /  your account only' 565 195 480 28 12
    $appList=New-Object Windows.Forms.CheckedListBox
    $appList.Location=New-Object Drawing.Point(565,228); $appList.Size=New-Object Drawing.Size(485,245)
    $appList.BackColor=[Drawing.Color]::FromArgb(27,27,30); $appList.ForeColor=$form.ForeColor
    $appList.BorderStyle='FixedSingle'; $appList.CheckOnClick=$true
    $canvas.Controls.Add($appList)
    $script:Rows=@()
    function Refresh-Apps {
        $appList.Items.Clear(); $script:Rows=@()
        $installed=@(Get-AppxPackage -ErrorAction Stop)
        foreach ($entry in $catalog) {
            $found=@($installed | Where-Object { $_.Name -eq $entry.package -and -not $_.IsFramework -and -not $_.NonRemovable })
            foreach ($p in $found) {
                $script:Rows += $p
                $null=$appList.Items.Add($entry.label,[bool]$entry.selected)
            }
        }
    }
    $null=Label 'Uncheck to keep. Local data from removed apps may be lost.' 565 479 485 42
    $script:ScrpLogTextBox=New-Object Windows.Forms.TextBox
    $script:ScrpLogTextBox.Location=New-Object Drawing.Point(30,620); $script:ScrpLogTextBox.Size=New-Object Drawing.Size(1020,130)
    $script:ScrpLogTextBox.Multiline=$true; $script:ScrpLogTextBox.ReadOnly=$true; $script:ScrpLogTextBox.ScrollBars='Vertical'
    $script:ScrpLogTextBox.BackColor=[Drawing.Color]::FromArgb(23,23,26); $script:ScrpLogTextBox.ForeColor=[Drawing.Color]::Silver
    $canvas.Controls.Add($script:ScrpLogTextBox)
    $logger={param($message) $script:ScrpLogTextBox.AppendText("$message`r`n"); $script:ScrpLogTextBox.Refresh()}
    function Get-Options {
        [pscustomobject]@{ Theme=$theme.Checked; GameMode=$game.Checked; Capture=$capture.Checked;
            Quiet=$quiet.Checked; Animations=$anim.Checked }
    }
    function Get-SelectedPackages {
        foreach ($i in $appList.CheckedIndices) { $script:Rows[$i] }
    }
    function Get-Preview {
        $options=Get-Options
        $settings=@(Get-Tweaks $options)
        $lines=@('SCREEPYOS - your selection', '', 'Settings:')
        foreach ($t in $settings) { $lines += "$($t.Path)\$($t.Name) = $($t.Value)" }
        if ($options.Theme) { $lines += 'Wallpaper = included SCRP OS image' }
        $lines += @('', 'Remove apps (current account only):')
        $selected=@(Get-SelectedPackages)
        if ($selected.Count -eq 0) { $lines += 'None.' }
        foreach ($p in $selected) { $lines += $p.Name }
        $lines += @('', 'Settings are backed up. App data is not.',
            'Restore resets settings; you must reinstall removed apps yourself.',
            'Registry options may behave differently across Windows builds. Check Windows Settings.',
            'This is not an ISO or a copy of FSOS. No guaranteed FPS gains.')
        return ($lines -join "`r`n")
    }
    $previewButton=Button 'Preview changes' 30 530 180 {
        $dialog=New-Object Windows.Forms.Form
        $dialog.Text='SCREEPYOS - review your selection'; $dialog.Size=New-Object Drawing.Size(930,600)
        $dialog.StartPosition='CenterParent'
        $text=New-Object Windows.Forms.TextBox
        $text.Multiline=$true; $text.ReadOnly=$true; $text.ScrollBars='Both'; $text.WordWrap=$false; $text.Dock='Fill'
        $text.Text=Get-Preview; $dialog.Controls.Add($text)
        $null=$dialog.ShowDialog($form); $dialog.Dispose()
    }
    $applyButton=Button 'Apply selection' 220 530 190 {
        $packages=@(Get-SelectedPackages); $options=Get-Options
        $labels=@($packages | ForEach-Object {$_.Name}) -join "`r`n"
        $message="Settings will change and $($packages.Count) app(s) will be removed:`r`n$labels`r`n`r`nApp data may be lost. Restore only resets settings. Continue?"
        if ([Windows.Forms.MessageBox]::Show($form,$message,'SCREEPYOS','YesNo','Warning') -ne 'Yes') { return }
        $form.UseWaitCursor=$true; $form.Enabled=$false
        try {
            $result=Invoke-ScrpApply $options $packages $wallpaper $logger
            [Windows.Forms.MessageBox]::Show($form,"Finished: $($result.Failures) error(s). Check the log, then sign out and sign back in.",'SCREEPYOS') | Out-Null
            Refresh-Apps
        } catch { & $logger "ERROR: $($_.Exception.Message)" }
        finally { $form.Enabled=$true; $form.UseWaitCursor=$false }
    }
    $restoreButton=Button 'Restore settings' 420 530 210 {
        if ([Windows.Forms.MessageBox]::Show($form,'Restore the latest settings backup? Apps and app data will not be restored.','Restore','YesNo','Question') -ne 'Yes') { return }
        $form.Enabled=$false; $form.UseWaitCursor=$true
        try { $null=Invoke-ScrpRestore $logger }
        catch { & $logger "ERROR: $($_.Exception.Message)" }
        finally { $form.Enabled=$true; $form.UseWaitCursor=$false }
    }
    $null=Button 'Backups / app log' 640 530 180 {
        if (Test-Path -LiteralPath $script:DataRoot) { Start-Process explorer.exe -ArgumentList ('"'+$script:DataRoot+'"') }
        else { & $logger 'No backup yet. It will be created when you apply changes.' }
    }
    $null=Button 'Store' 830 530 105 { Start-Process 'ms-windows-store://home' }
    $null=Button 'User guide' 945 530 105 { & $script:Navigate 'Help' }
    $null=Button 'Graphics settings' 30 575 205 { Start-Process 'ms-settings:display-advancedgraphics' }
    $null=Button 'Startup apps' 245 575 170 { Start-Process 'ms-settings:startupapps' }
    $null=Button 'Game Mode' 425 575 150 { Start-Process 'ms-settings:gaming-gamemode' }
    $null=Button 'Game recording' 585 575 160 { Start-Process 'ms-settings:gaming-gamedvr' }
    $null=Button 'Power' 755 575 135 { Start-Process 'ms-settings:powersleep' }
    $null=Button 'Display / Hz' 900 575 150 { Start-Process 'ms-settings:display-advanced' }
    Refresh-Apps
    & $logger "Windows build $($os.BuildNumber) | $($script:Rows.Count) removable apps found in the catalog."
    & $logger 'Experimental build. Start with Preview changes; code checks do not replace Windows integration tests.'
    & $logger 'Use on standard Windows 11. Results on an already modified Windows installation are unknown.'
    Mount-ScrpPage $form {
        $picture.Image.Dispose();$mutex.ReleaseMutex();$mutex.Dispose()
    }
} catch {
    [Windows.Forms.MessageBox]::Show($_.Exception.Message,'SCREEPYOS - startup failed','OK','Error') | Out-Null
    throw
}
