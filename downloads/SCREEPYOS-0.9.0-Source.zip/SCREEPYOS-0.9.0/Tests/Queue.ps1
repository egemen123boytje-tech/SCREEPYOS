$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Executables/Payload/OptionalFeatures.ps1')
$dir=Join-Path ([IO.Path]::GetTempPath()) ('scrp-queue-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($dir) | Out-Null
function Check($value,$label) {if (-not $value) {throw $label}; "PASS: $label"}
try {
    $p=Join-Path $dir 'choices.json'
    Check (@(Read-ScrpWizardChoices $p).Count -eq 0) 'missing queue is empty'
    $sequence=@('OptionalPrinter','OptionalBluetooth','OptionalFax','OptionalMaps','OptionalMedia','OptionalBackground')
    foreach ($choice in $sequence) {Add-ScrpWizardChoice $p $choice}
    Check ((@(Read-ScrpWizardChoices $p) -join ',') -eq ($sequence -join ',')) 'reported selection sequence survives independent reads and replacements'
    Add-ScrpWizardChoice $p 'OptionalMaps'
    Check (@(Read-ScrpWizardChoices $p).Count -eq 6) 'retry does not duplicate a choice'
    $before=[IO.File]::ReadAllText($p)
    $failed=$false;try {Add-ScrpWizardChoice $p 'WinDefend'} catch {$failed=$true}
    Check ($failed -and [IO.File]::ReadAllText($p) -ceq $before) 'unknown choice leaves queue unchanged'
    foreach ($bad in @((([string][char]0)*296),'','[','{"x":1}','["Unknown"]','[null]','[12]')) {
        [IO.File]::WriteAllText($p,$bad)
        $failed=$false;try {Add-ScrpWizardChoice $p 'OptionalMaps'} catch {$failed=$_.Exception.Message -like '*start a fresh playbook run*'}
        Check ($failed -and [IO.File]::ReadAllText($p) -ceq $bad) 'invalid state is rejected and preserved, never silently discarded'
    }
    Check (@(Get-ChildItem $dir -Filter '*.tmp').Count -eq 0) 'temporary files cleaned up'
    'ALL 12 QUEUE CHECKS PASSED'
} finally {Remove-Item $dir -Recurse -Force}
