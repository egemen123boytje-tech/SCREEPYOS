﻿# Portable orchestration tests: no downloads or Windows mutations.
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Executables/Payload/BrowserEngine.ps1')
$script:tests=0
function Check($ok,$message) {if (-not $ok) {throw "FAIL: $message"};$script:tests++;Write-Output "PASS: $message"}
Add-Type 'public static class ScrpCpuFeatures { public static bool Supported=true; public static bool IsProcessorFeaturePresent(uint f) { return Supported; } }'
function Get-ScrpBrowserPath($Browser) {if ($script:installed) {return ('C:\Browser\'+$Browser+'.exe')};return $null}
function Get-Command($Name) {if ($script:available) {return [pscustomobject]@{Source='Invoke-TestInstaller'}};return $null}
function Invoke-TestInstaller {
 $script:arguments=@($args);$script:calls++
 $global:LASTEXITCODE=$script:exitCode
 if ($script:exitCode -eq 0 -and $script:materialize) {$script:installed=$true}
}
function Reset {
 $script:installed=$false;$script:available=$true;$script:calls=0;$script:exitCode=0;$script:materialize=$true
 [ScrpCpuFeatures]::Supported=$true
}
function Fails($browser) {try {Install-ScrpBrowser $browser | Out-Null;return $false} catch {return $true}}
Reset
$result=Install-ScrpBrowser Brave
Check ($result -eq 'C:\Browser\Brave.exe' -and $script:calls -eq 1) 'successful install requires post-install browser detection'
Check (($script:arguments -contains 'Brave.Brave') -and ($script:arguments -contains '--exact') -and ($script:arguments -contains '--scope') -and ($script:arguments -notcontains '--ignore-security-hash')) 'exact Brave package and no hash bypass'
Reset;$script:installed=$true;$result=Install-ScrpBrowser Brave
Check ($script:calls -eq 0) 'existing browser does not reinstall or downgrade'
Reset;$script:available=$false
Check (Fails Brave) 'missing WinGet stops browser step'
Reset;$script:exitCode=1
Check (Fails Brave) 'installer failure stops browser step'
Reset;$script:materialize=$false
Check (Fails Brave) 'success exit without detected browser is rejected'
Reset;[ScrpCpuFeatures]::Supported=$false
Check ((Fails Thorium) -and $script:calls -eq 0) 'unsupported SSE4 stops before downloading Thorium'
Reset;$result=Install-ScrpBrowser Thorium
Check (($script:arguments -contains 'Alex313031.Thorium') -and ($script:arguments -notcontains 'Alex313031.Thorium.AVX2')) 'Thorium uses general package instead of AVX2'
Write-Output "ALL $script:tests BROWSER CHECKS PASSED"
