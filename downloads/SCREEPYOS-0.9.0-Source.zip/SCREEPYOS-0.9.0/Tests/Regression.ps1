# Portable logic tests. No Windows registry/app/service mutations.
param([string]$Payload=(Join-Path $PSScriptRoot '../Executables/Payload'))
$ErrorActionPreference='Stop'
$script:Tests=0
function Assert($condition,$message) {if (-not $condition) {throw "FAIL: $message"};$script:Tests++;Write-Output "PASS: $message"}
function Load-Functions($file) {
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$errors)
 if ($errors.Count) {throw ($errors|Out-String)}
 foreach ($fn in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)) {
  # Load definitions into script scope, without evaluating Windows-only entrypoints.
  $body=$fn.Body.Extent.Text
  $params=@($fn.Parameters|ForEach-Object {$_.Extent.Text}) -join ','
  if ($params) {$prefix='param('+$params+')'+"`n"} else {$prefix=''}
  Set-Item ('function:script:'+$fn.Name) ([scriptblock]::Create($prefix+$body.Substring(1,$body.Length-2)))
 }
}
foreach ($file in Get-ChildItem (Join-Path $Payload '..') -Recurse -Filter '*.ps1') {
 $tokens=$null;$errors=$null
 [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 Assert ($errors.Count -eq 0) ('native parser: '+$file.Name)
}
$testRoot=Join-Path $PSScriptRoot ('scrp-tests-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $testRoot|Out-Null
$oldLocal=$env:LOCALAPPDATA;$oldSystem=$env:SystemRoot
try {
 $env:LOCALAPPDATA=$testRoot
 . (Join-Path $Payload 'CleanupEngine.ps1')
 $temp=Join-Path $testRoot 'Temp';New-Item -ItemType Directory $temp|Out-Null
 $old=Join-Path $temp 'old.txt';'old'|Set-Content $old;(Get-Item $old).LastWriteTimeUtc=[datetime]::UtcNow.AddDays(-10)
 $recent=Join-Path $temp 'recent.txt';'recent'|Set-Content $recent
 $changed=Join-Path $temp 'changed.txt';'old'|Set-Content $changed;(Get-Item $changed).LastWriteTimeUtc=[datetime]::UtcNow.AddDays(-10)
 $outside=Join-Path $testRoot 'outside.txt';'keep'|Set-Content $outside
 Assert (-not (Test-CleanPath $outside $temp)) 'cleanup rejects outside root'
 $link=Join-Path $temp 'linked';New-Item -ItemType Junction -Path $link -Target $testRoot|Out-Null
 $plan=@(Get-CleanPlan @('Temp'))
 Assert ($plan.Count -eq 2) 'cleanup excludes recent files and recursive junction'
 'changed after preview'|Set-Content $changed
 $result=Invoke-CleanPlan $plan
 Assert ($result.Removed -eq 1 -and $result.Skipped -eq 1) 'cleanup skips changed file after preview'
 Assert ((Test-Path $recent) -and (Test-Path $changed) -and (Test-Path $outside) -and -not (Test-Path $old)) 'cleanup only deletes eligible preview file'
 Load-Functions (Join-Path $Payload 'Engine.ps1')
 Load-Functions (Join-Path $Payload 'CompetitiveEngine.ps1')
 $script:DataRoot=$testRoot;$script:CJournal=Join-Path $testRoot 'session.json';$script:Sid='test-user';$script:CProfileRoot=Join-Path $testRoot 'profiles'
 $exe=Join-Path $testRoot 'game.exe';'test fixture only'|Set-Content $exe
 $p=[pscustomobject]@{Version=1;Id=('a'*32);Name='Test Game';Path=$exe;Launch='';Priority='AboveNormal';Power=$false;CaptureOff=$false;Hud=$true}
 Save-CProfile $p;$loaded=Read-CProfile $p.Id
 Assert ($loaded.Name -eq 'Test Game' -and $loaded.Priority -eq 'AboveNormal') 'profile save/load roundtrip'
 $threw=$false;try {Read-CProfile '../escape'} catch {$threw=$true};Assert $threw 'profile traversal rejected'
 $p.Priority='Realtime';$threw=$false;try {Test-CProfile $p} catch {$threw=$true};Assert $threw 'Realtime priority rejected';$p.Priority='AboveNormal'
 # Empty tweak list avoids any registry interaction.
 New-CSession $p
 Assert (Test-Path $script:CJournal) 'journal exists before priority mutation'
 $script:FakeProc=[pscustomobject]@{Id=4567;StartTime=[datetime]::Now;Path=$exe;PriorityClass=[Diagnostics.ProcessPriorityClass]::Normal;SessionId=[Diagnostics.Process]::GetCurrentProcess().SessionId}
 $script:FakeProc|Add-Member ScriptMethod Refresh {}
 Set-CPriority $script:FakeProc 'AboveNormal'
 $saved=Get-Content $script:CJournal -Raw|ConvertFrom-Json
 Assert ($saved.Processes[0].Before -eq 'Normal' -and $script:FakeProc.PriorityClass.ToString() -eq 'AboveNormal') 'priority records original before write'
 function script:Get-Process {param($Id,$Name,$ErrorAction) return $script:FakeProc}
 $fail=@(Restore-CSession)
 Assert ($fail.Count -eq 0 -and $script:FakeProc.PriorityClass.ToString() -eq 'Normal' -and -not (Test-Path $script:CJournal)) 'priority restored and journal cleared'
 New-CSession $p;Set-CPriority $script:FakeProc 'AboveNormal';$script:FakeProc.PriorityClass=[Diagnostics.ProcessPriorityClass]::High
 $fail=@(Restore-CSession)
 Assert ($fail.Count -eq 1 -and (Test-Path $script:CJournal) -and $script:FakeProc.PriorityClass.ToString() -eq 'High') 'manual priority change preserved; recovery journal retained'
 $script:FakeProc.StartTime=$script:FakeProc.StartTime.AddMinutes(1)
 $fail=@(Restore-CSession)
 Assert ($fail.Count -eq 0 -and $script:FakeProc.PriorityClass.ToString() -eq 'High') 'PID reuse does not restore wrong process'
 New-CSession $p
 $script:CSession.Power=[pscustomobject]@{Before='original';Applied='target'};Save-CSession
 $script:FakePower='manual'
 function script:Get-ScrpActivePower {return $script:FakePower}
 function script:Invoke-ScrpPowercfg {param($Arguments) $script:FakePower=$Arguments[1]}
 $fail=@(Restore-CSession);Assert ($fail.Count -eq 1 -and $script:FakePower -eq 'manual') 'manual power change preserved'
 $script:FakePower='target';$fail=@(Restore-CSession);Assert ($fail.Count -eq 0 -and $script:FakePower -eq 'original') 'original power restored after session'
 # Exact-path discovery excludes a same-name executable elsewhere.
 $script:FakeProc.Path=Join-Path $testRoot 'other/game.exe'
 Assert (@(Get-CProcesses $p).Count -eq 0) 'same-name process with different path excluded'
 $script:FakeProc.Path=$p.Path
 Assert (@(Get-CProcesses $p).Count -eq 1) 'exact path and session matched'
 # Restore captures only the fixed permitted registry targets, preserving conflicts.
 $script:RegMock=[pscustomobject]@{Path='HKCU:\System\GameConfigStore';Name='GameDVR_Enabled';Exists=$true;Kind='DWord';Value=0}
 function script:Get-RegistrySnapshot {param($T) return $script:RegMock}
 function script:Set-RegValue {param($Path,$Name,$Value,$Kind) $script:RegMock=[pscustomobject]@{Path=$Path;Name=$Name;Exists=($Kind -ne 'Delete');Kind=$Kind;Value=$Value}}
 New-CSession $p
 $script:CSession.Registry=@([pscustomobject]@{Before=[pscustomobject]@{Path=$script:RegMock.Path;Name=$script:RegMock.Name;Exists=$true;Kind='DWord';Value=1};Applied=$script:RegMock})
 Save-CSession
 $fail=@(Restore-CSession)
 Assert ($fail.Count -eq 0 -and $script:RegMock.Value -eq 1) 'capture registry original restored'
 New-CSession $p
 $script:CSession.Registry=@([pscustomobject]@{Before=[pscustomobject]@{Path=$script:RegMock.Path;Name=$script:RegMock.Name;Exists=$true;Kind='DWord';Value=1};Applied=[pscustomobject]@{Path=$script:RegMock.Path;Name=$script:RegMock.Name;Exists=$true;Kind='DWord';Value=0}})
 Save-CSession;$script:RegMock.Value=2
 $fail=@(Restore-CSession)
 Assert ($fail.Count -eq 1 -and $script:RegMock.Value -eq 2) 'capture registry manual change preserved'
 # Reproduce the prior callback-name collision with an explicit script-scoped textbox stub.
 $script:ScrpLogTextBox=[pscustomobject]@{Text=''};$script:ScrpLogTextBox|Add-Member ScriptMethod AppendText {param($s) $this.Text+=$s};$script:ScrpLogTextBox|Add-Member ScriptMethod Refresh {}
 $callback={param($message) $script:ScrpLogTextBox.AppendText($message);$script:ScrpLogTextBox.Refresh()}
 function Invoke-LoggingFixture($Log) {& $Log 'works'}
 Invoke-LoggingFixture $callback
 Assert ($script:ScrpLogTextBox.Text -eq 'works') 'AppendText logging collision regression'
 Write-Output "ALL $script:Tests CHECKS PASSED (portable mocks, not Windows integration)."
} finally {
 $env:LOCALAPPDATA=$oldLocal;$env:SystemRoot=$oldSystem
 # Remove test-owned symlink first; never recurse through its target.
 $link=Join-Path $testRoot 'Temp/linked';if (Test-Path $link) {[IO.Directory]::Delete($link)}
 if (-not ([IO.Path]::GetFullPath($testRoot).StartsWith([IO.Path]::GetFullPath($PSScriptRoot)+[IO.Path]::DirectorySeparatorChar))) {throw 'Invalid test cleanup path.'}; Remove-Item -LiteralPath $testRoot -Recurse -Force
}


