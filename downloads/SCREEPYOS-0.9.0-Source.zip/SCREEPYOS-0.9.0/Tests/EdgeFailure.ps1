$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot '../Executables/Install.ps1') -Raw
$block=[scriptblock]::Create((($source -split '# BEGIN OPTIONAL EDGE REMOVAL',2)[1] -split '# END OPTIONAL EDGE REMOVAL',2)[0])
$base=Join-Path ([IO.Path]::GetTempPath()) ([guid]::NewGuid().ToString())
New-Item $base -ItemType Directory | Out-Null
# Start-Process is mocked; keep SystemRoot intact for native .NET configuration.
$arguments='test'
function Start-Process {if ($script:cancel) {throw 'UAC cancelled'};[pscustomobject]@{ExitCode=$script:code}}
try {
 foreach ($case in @(@{Code=0;Cancel=$false;Expected=$true},@{Code=1;Cancel=$false;Expected=$false},@{Code=0;Cancel=$true;Expected=$false})) {
  $script:code=$case.Code;$script:cancel=$case.Cancel
  . $block
  $result=Get-Content (Join-Path $base 'edge-removal-status.json') -Raw | ConvertFrom-Json
  if ($result.RemovalConfirmed -ne $case.Expected) {throw 'Unexpected Edge status'}
  if (-not $case.Expected -and -not $result.Warning) {throw 'Missing warning'}
  Write-Output "PASS: Edge code=$($case.Code), cancellation=$($case.Cancel): stage continues with accurate status"
 }
 if ($source.IndexOf("throw 'The selected browser is missing.") -gt $source.IndexOf('# BEGIN OPTIONAL EDGE REMOVAL')) {throw 'Browser guard moved inside optional handler'}
 Write-Output 'PASS: mandatory browser guard remains outside optional removal handler'
 Write-Output 'ALL 4 EDGE FAILURE CHECKS PASSED'
} finally {Remove-Item $base -Recurse -Force}


