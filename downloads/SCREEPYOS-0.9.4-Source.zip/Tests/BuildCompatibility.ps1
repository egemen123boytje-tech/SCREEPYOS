﻿$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
[xml]$config=Get-Content (Join-Path $root 'playbook.conf') -Raw
$builds=@(22631,26100,26200,26300)
if ((@($config.Playbook.SupportedBuilds.string) -join ',') -ne ($builds -join ',')) {throw 'Wizard build mismatch'}
if (@($config.Playbook.UpgradableFrom.string) -notcontains '0.9.0') {throw 'Missing 0.9.0 upgrade'}
$count=2
foreach ($path in @('Executables/Install.ps1','Executables/Payload/Profiles.ps1')) {
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root $path),[ref]$tokens,[ref]$errors)
 if ($errors.Count) {throw 'Parse failure'}
 $guard=$ast.Find({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Clauses[0].Item1.Extent.Text -match 'os.ProductType'},$true)
 if (-not $guard) {throw 'Missing OS guard'}
 $condition=[scriptblock]::Create($guard.Clauses[0].Item1.Extent.Text)
 foreach ($build in @($builds)+@(19045,22000,28000,99999)) {
  foreach ($product in @(1,2,3)) {
   $os=[pscustomobject]@{BuildNumber=[string]$build;ProductType=$product}
   $blocked=& $condition
   if ($blocked -ne ($product -ne 1 -or $build -notin $builds)) {throw "Bad guard: $path $build $product"}
   $count++
  }
 }
}
Write-Output "PASS: $count build/upgrade checks; no installer or tweaks executed."
