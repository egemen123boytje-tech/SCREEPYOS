﻿param([string]$TestRoot)
$ErrorActionPreference='Stop'
if (-not $TestRoot) {throw 'Supply an isolated workspace TestRoot'}
. (Join-Path $PSScriptRoot '../Executables/Payload/Engine.ps1')
$script:DataRoot=$TestRoot
$script:effects=@{};$script:registry=@{};$script:writes=0
foreach ($e in Get-ScrpVisualEffects) {$script:effects[$e.Name]=$true}
function Read-ScrpEffect($e) {return $script:effects[$e.Name]}
function Assert-Backup {if (-not (Get-LatestBackup)) {throw 'Mutation before backup'};$script:writes++}
function Write-ScrpEffect($e,[bool]$v) {Assert-Backup;$script:effects[$e.Name]=$v}
function Get-RegistrySnapshot($t) {
 $key=$t.Path+'|'+$t.Name
 if (-not $script:registry.ContainsKey($key)) {$script:registry[$key]=[pscustomobject]@{Path=$t.Path;Name=$t.Name;Exists=$true;Kind=$t.Kind;Value=$(if ($t.Kind -eq 'String') {'1'} else {9})}}
 $script:registry[$key]
}
function Set-RegValue($Path,$Name,$Value,$Kind) {Assert-Backup;$script:registry[$Path+'|'+$Name]=[pscustomobject]@{Path=$Path;Name=$Name;Exists=$true;Kind=$Kind;Value=$Value}}
$options=[pscustomobject]@{Theme=$false;GameMode=$false;Capture=$false;Quiet=$false;Animations=$true;VisualEffects=$true}
$result=Invoke-ScrpApplyCore $options @() '' {param($m)}
if ($result.Failures -ne 0 -or $script:writes -ne 20) {throw 'Expected 12 API and 8 registry writes'}
if (@($script:effects.Values|Where-Object {$_}).Count) {throw 'Effects not disabled'}
foreach ($pair in @(@('VisualFXSetting',3),@('ListviewShadow',1),@('IconsOnly',1),@('ListviewAlphaSelect',0),@('EnableAeroPeek',0),@('AlwaysHibernateThumbnails',0))) {
 $entry=@($script:registry.Values|Where-Object Name -eq $pair[0])
 if ($entry.Count -ne 1 -or $entry[0].Value -ne $pair[1]) {throw "Wrong setting $($pair[0])"}
}
$before=Get-Content (Join-Path $result.Run 'before.json') -Raw|ConvertFrom-Json
if ($before.VisualEffects.Count -ne 12 -or $before.Registry.Count -ne 8) {throw 'Incomplete backup'}
# Keep an unrelated later user change instead of overwriting it on restore.
$key=@($script:registry.Keys|Where-Object {$_ -like '*|IconsOnly'})[0]
$script:registry[$key].Value=7
if ((Invoke-ScrpRestoreCore {param($m)}) -ne 1) {throw 'Expected restore conflict'}
if ($script:registry[$key].Value -ne 7) {throw 'User change lost'}
if (@($script:effects.Values|Where-Object {-not $_}).Count) {throw 'API values not restored'}
$script:registry[$key].Value=1
if ((Invoke-ScrpRestoreCore {param($m)}) -ne 0) {throw 'Restore retry failed'}
$options.Animations=$false;$options.VisualEffects=$false
if (@(Get-Tweaks $options).Count -ne 0) {throw 'Unchecked preset changes values'}
[xml]$config=Get-Content (Join-Path $PSScriptRoot '../playbook.conf') -Raw
$check=@($config.Playbook.FeaturePages.CheckboxPage.Options.CheckboxOption | Where-Object Name -eq 'animations')
if ($check[0].IsChecked -ne 'true') {throw 'Preset must default on'}
Write-Output 'PASS: preset values, backup before writes, apply/restore, conflict preservation, restore retry, opt-out and wizard default; OS calls mocked.'
