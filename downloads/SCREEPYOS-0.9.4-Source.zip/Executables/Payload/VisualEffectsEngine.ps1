﻿# Documented SystemParametersInfo BOOL settings. No packed preference-mask writes.
function Get-ScrpVisualEffects {
 @(
  @('Menu animation',0x1002,0x1003,0),@('Combo animation',0x1004,0x1005,0),
  @('Smooth list scrolling',0x1006,0x1007,0),@('Menu fade',0x1012,0x1013,0),
  @('Selection fade',0x1014,0x1015,0),@('Tooltip animation',0x1016,0x1017,0),
  @('Tooltip fade',0x1018,0x1019,0),@('Cursor shadow',0x101A,0x101B,0),
  @('Window shadow',0x1024,0x1025,0),@('Client area animation',0x1042,0x1043,0),
  @('Full window dragging',0x0026,0x0025,1),@('Font smoothing',0x004A,0x004B,1)
 ) | ForEach-Object {[pscustomobject]@{Name=$_[0];Get=[int]$_[1];Set=[int]$_[2];Ui=[bool]$_[3]}}
}
function Initialize-ScrpEffectsNative {
 if ('Scrp.EffectsNative' -as [type]) {return}
 Add-Type @'
using System;
using System.Runtime.InteropServices;
namespace Scrp { public static class EffectsNative {
 [DllImport("user32.dll", EntryPoint="SystemParametersInfoW", SetLastError=true)]
 public static extern bool Read(uint action,uint param,ref int value,uint flags);
 [DllImport("user32.dll", EntryPoint="SystemParametersInfoW", SetLastError=true)]
 public static extern bool Write(uint action,uint param,IntPtr value,uint flags);
} }
'@
}
function Read-ScrpEffect($Effect) {
 Initialize-ScrpEffectsNative
 $value=0
 if (-not [Scrp.EffectsNative]::Read($Effect.Get,0,[ref]$value,0)) {throw "Cannot read visual effect: $($Effect.Name)"}
 return [bool]$value
}
function Write-ScrpEffect($Effect,[bool]$Value) {
 Initialize-ScrpEffectsNative
 $ui=0;$ptr=[IntPtr]::Zero
 if ($Effect.Ui) {$ui=[uint32]$Value} else {$ptr=[IntPtr]([int]$Value)}
 if (-not [Scrp.EffectsNative]::Write($Effect.Set,$ui,$ptr,3)) {throw "Cannot write visual effect: $($Effect.Name)"}
 if ((Read-ScrpEffect $Effect) -ne $Value) {throw "Visual effect verification failed: $($Effect.Name)"}
}
function Restore-ScrpEffects($Saved,$LogCallback) {
 $errors=0
 foreach ($item in $Saved) {
  try {
   $effect=@(Get-ScrpVisualEffects | Where-Object Name -eq $item.Name)
   if ($effect.Count -ne 1 -or $item.Before -isnot [bool]) {throw 'Invalid visual effect backup'}
   $current=Read-ScrpEffect $effect[0]
   if ($current -ne $item.Before) {Write-ScrpEffect $effect[0] $item.Before}
   & $LogCallback "RESTORED visual effect: $($item.Name)"
  } catch {$errors++; & $LogCallback "ERROR restoring visual effect: $($_.Exception.Message)"}
 }
 return $errors
}
