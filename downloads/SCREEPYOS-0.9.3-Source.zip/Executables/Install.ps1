﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][ValidateSet('Setup','Theme','Debloat','Gaming','Quiet','Animations','BrowserBrave','BrowserThorium','RemoveEdge','OptionalPrinter','OptionalBluetooth','OptionalSearch','OptionalFax','OptionalMaps','OptionalMedia','OptionalBackground','Finish')][string]$Stage)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$logStarted=$false
$exitCode=0
try {
    $os=Get-CimInstance Win32_OperatingSystem
    if ($os.ProductType -ne 1 -or [int]$os.BuildNumber -notin @(22631,26100,26200,26300)) { throw 'This experimental build targets Windows 11 builds 22631, 26100, 26200 and 26300 (26H2; experimental).' }
    if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64') {throw 'This version is for Intel/AMD x64; ARM64 has not been validated.'}
    if (-not [Environment]::Is64BitProcess) {throw 'Use 64-bit AME Wizard.'}
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    if ($identity.IsSystem -or $identity.User.Value -in @('S-1-5-18','S-1-5-19','S-1-5-20')) {throw 'Installation must run as the signed-in user, not a system account.'}
    $principal=New-Object Security.Principal.WindowsPrincipal($identity)
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {throw 'The playbook action must use runas: currentUser, without elevation.'}
    $base=Join-Path $env:LOCALAPPDATA 'SCREEPYOS'
    $app=Join-Path $base 'App-0.9.3'
    $logs=Join-Path $base 'Logs'
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
    Start-Transcript -Path (Join-Path $logs ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+$Stage+'.log')) -Force | Out-Null
    $logStarted=$true
    if ($Stage -eq 'Setup') {
        $oldQueue=Join-Path $base 'wizard-features.json'
        if (Test-Path -LiteralPath $oldQueue) {
            Copy-Item -LiteralPath $oldQueue -Destination (Join-Path $logs ('wizard-features-before-setup-'+[guid]::NewGuid().ToString('N')+'.json')) -ErrorAction Stop
            Remove-Item -LiteralPath $oldQueue -Force -ErrorAction Stop
        }
        Remove-Item (Join-Path $base 'browser-ready.json') -Force -ErrorAction SilentlyContinue
        $receipt=Join-Path $base 'installed-version.json'
        if (Test-Path (Join-Path $base 'competitive-session.json')) {throw 'Recover the pending Competitive session in the dashboard first.'}
        if (Test-Path $receipt) {
            $v=(Get-Content $receipt -Raw|ConvertFrom-Json).Version
            if ($v -notin @('0.4.1','0.5.0','0.6.0','0.7.0','0.7.1','0.7.2','0.7.3','0.7.4','0.7.5','0.8.0','0.9.0','0.9.1','0.9.2','0.9.3')) {throw "Upgrade from $v is not supported. Use a supported previous version or a clean Windows installation."}
        } else {
            $old=@(Get-ChildItem $base -Directory -Filter 'App-*' -ErrorAction SilentlyContinue | Where-Object {$_.Name -ne 'App-0.9.3'})
            if ($old.Count -and -not (($old.Name -contains 'App-0.4.1') -or ($old.Name -contains 'App-0.5.0') -or ($old.Name -contains 'App-0.6.0') -or ($old.Name -contains 'App-0.7.0') -or ($old.Name -contains 'App-0.7.1') -or ($old.Name -contains 'App-0.7.2') -or ($old.Name -contains 'App-0.7.3') -or ($old.Name -contains 'App-0.7.4') -or ($old.Name -contains 'App-0.7.5') -or ($old.Name -contains 'App-0.8.0') -or ($old.Name -contains 'App-0.9.0') -or ($old.Name -contains 'App-0.9.1') -or ($old.Name -contains 'App-0.9.2'))) {throw 'Only a clean installation or an upgrade from a supported previous version is allowed.'}
        }
        foreach ($proc in @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'")) {
            if ($proc.ProcessId -ne $PID -and $proc.CommandLine -and $proc.CommandLine.Contains($base+'\App-')) {throw 'Close all SCREEPYOS windows, then restart installation.'}
        }
        $payload=Join-Path $PSScriptRoot 'Payload' 
        if (-not (Test-Path (Join-Path $payload 'Engine.ps1'))) {throw 'Playbook payload is missing.'}
        New-Item -ItemType Directory -Path $app -Force | Out-Null
        Get-ChildItem -LiteralPath $payload -Force | Copy-Item -Destination $app -Recurse -Force
        $launcher=Join-Path $app 'SCREEPYOS.exe'
        $temporaryLauncher=Join-Path $app ('SCREEPYOS-'+[guid]::NewGuid().ToString('N')+'.exe')
        Add-Type -TypeDefinition (Get-Content (Join-Path $app 'AppLauncher.cs') -Raw) -Language CSharp -OutputAssembly $temporaryLauncher -OutputType WindowsApplication
        Move-Item -LiteralPath $temporaryLauncher -Destination $launcher -Force
        $shell=New-Object -ComObject WScript.Shell
        foreach ($folder in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))) {
            if (-not $folder) {continue}
            $link=$shell.CreateShortcut((Join-Path $folder 'SCREEPYOS.lnk'))
            $link.TargetPath=$launcher
            $link.Arguments='Home'
            $link.WorkingDirectory=$app;$link.Description='SCREEPYOS dashboard, Game Center and recovery';$link.Save()
        }
        @{Version='0.9.3';Installed=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content $receipt -Encoding UTF8
        Write-Output 'SCREEPYOS 0.9.3 English, Competitive Mode and Disk Cleanup installed.'
    } elseif ($Stage -in @('BrowserBrave','BrowserThorium')) {
        . (Join-Path $app 'BrowserEngine.ps1')
        $browser=if ($Stage -eq 'BrowserBrave') {'Brave'} else {'Thorium'}
        $path=Install-ScrpBrowser $browser
        @{Browser=$browser;Path=[string](@($path)[-1]);Version='0.9.3'} | ConvertTo-Json | Set-Content (Join-Path $base 'browser-ready.json') -Encoding UTF8
    } elseif ($Stage -eq 'RemoveEdge') {
        $ready=Join-Path $base 'browser-ready.json'
        if (-not (Test-Path $ready)) {throw 'No successful browser installation step found. Edge is kept.'}
        $selection=Get-Content $ready -Raw | ConvertFrom-Json
        . (Join-Path $app 'BrowserEngine.ps1')
        if ($selection.Version -ne '0.9.3' -or -not (Get-ScrpBrowserPath $selection.Browser)) {throw 'The selected browser is missing. Edge is kept.'}
        $worker=Join-Path $app 'Gaming-Machine.ps1'
        $arguments='-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$worker+'" -Mode Edge -ExpectedSid '+$identity.User.Value+' -NoPrompt'
        Write-Output 'Selected browser verified. Removing Edge; confirm UAC and the Microsoft uninstaller if prompted.'
        # BEGIN OPTIONAL EDGE REMOVAL
        $edgeWarning=$null
        try {
            $process=Start-Process (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Verb RunAs -WindowStyle Hidden -ArgumentList $arguments -Wait -PassThru
            if ($process.ExitCode -ne 0) {throw "Edge worker returned exit code $($process.ExitCode)."}
        } catch {
            $edgeWarning='Edge removal was not confirmed: '+$_.Exception.Message+' Edge may still be installed. Continuing with the selected tweaks. See C:\ProgramData\SCREEPYOS-Machine for details. WebView2 is kept.'
            Write-Warning $edgeWarning
        }
        @{RemovalConfirmed=($null -eq $edgeWarning);Warning=$edgeWarning;CheckedAt=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content (Join-Path $base 'edge-removal-status.json') -Encoding UTF8
        # END OPTIONAL EDGE REMOVAL
    } elseif ($Stage -like 'Optional*') {
        . (Join-Path $app 'OptionalFeatures.ps1')
        Resolve-ScrpOptionalChoices @($Stage) | Out-Null
        $queue=Join-Path $base 'wizard-features.json'
        Add-ScrpWizardChoice -Path $queue -Choice $Stage
        Write-Output "Queued $Stage. Applied together at Finish; restart required."
    } elseif ($Stage -eq 'Finish') {
        $queue=Join-Path $base 'wizard-features.json'
        if (Test-Path $queue) {
            . (Join-Path $app 'OptionalFeatures.ps1')
            $choices=@(Read-ScrpWizardChoices -Path $queue)
            $features=@(Resolve-ScrpOptionalChoices $choices | Select-Object -Unique)
            if ($features.Count) {
                $worker=Join-Path $app 'Gaming-Machine.ps1'
                $arguments='-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$worker+'" -Mode Apply -ExpectedSid '+$identity.User.Value+' -Features '+($features -join ',')+' -NoPrompt'
                Write-Output 'Applying selected optional features. Confirm UAC. Backup and logs: C:\ProgramData\SCREEPYOS-Machine'
                $process=Start-Process (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Verb RunAs -WindowStyle Hidden -ArgumentList $arguments -Wait -PassThru
                if ($process.ExitCode -ne 0) {throw 'Some optional features could not be applied. See C:\ProgramData\SCREEPYOS-Machine. Earlier changes have backups; use Gaming-only > Restore system settings if needed.'}
                Write-Output 'Optional feature processing completed. Services with enabled dependents are skipped and recorded as warnings in C:\ProgramData\SCREEPYOS-Machine. RESTART Windows. Restore with Gaming-only > Restore system settings.'
            }
        }

        $audit=Join-Path $app 'Service-Audit.ps1'
        & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoProfile -ExecutionPolicy Bypass -File $audit -NoOpen
        if ($LASTEXITCODE -ne 0) {throw "Service audit failed, exit code $LASTEXITCODE. Check the log."}
        $edgeStatus=Join-Path $base 'edge-removal-status.json'
        if (Test-Path $edgeStatus) {
            $edgeResult=Get-Content $edgeStatus -Raw | ConvertFrom-Json
            if (-not $edgeResult.RemovalConfirmed) {Write-Warning $edgeResult.Warning}
        }
        Write-Output 'Next, select Hardware profiles in the dashboard: Low-end, Mid-end or High-end.'
        Write-Output 'Browser installed. Choose your default browser in Settings > Apps > Default apps.'
        Write-Output 'Done. Use the SCREEPYOS shortcut. Sign out and back in to fully refresh the theme.'
        Write-Output 'Next, open Gaming-only in the dashboard for OneDrive, Office, 38 app categories and selected services. These additional choices have not been applied yet.'
    } else {
        . (Join-Path $app 'Engine.ps1')
        $options=[pscustomobject]@{Theme=($Stage -eq 'Theme');GameMode=($Stage -eq 'Gaming');Capture=$false;Quiet=($Stage -eq 'Quiet');Animations=($Stage -eq 'Animations');VisualEffects=($Stage -eq 'Animations')}
        $packages=@()
        if ($Stage -eq 'Debloat') {
            $catalog=@(Get-Content (Join-Path $app 'apps.json') -Raw | ConvertFrom-Json)
            $names=@($catalog | ForEach-Object {$_.package})
            $packages=@(Get-AppxPackage | Where-Object {$names -contains $_.Name -and -not $_.IsFramework -and -not $_.NonRemovable})
        }
        $result=Invoke-ScrpApply $options $packages (Join-Path $app 'assets\SCRP-OS.png') {param($m) Write-Output $m}
        # Engine returns log text and the final result on the success stream; select the result object.
        $summary=@($result | Where-Object {$null -ne $_ -and $_.PSObject.Properties.Name -contains 'Failures'}) | Select-Object -Last 1
        $result | Where-Object {$_ -is [string]} | ForEach-Object {Write-Output $_}
        if ($null -eq $summary) {throw 'No installation result received.'}
        if ($summary.Failures -gt 0) {throw "Stage $Stage had $($summary.Failures) error(s). Backup: $($summary.Run)"}
    }
} catch {
    Write-Output ('INSTALLATION ERROR: '+$_.Exception.Message)
    Write-Output $_.ScriptStackTrace
    $exitCode=1
} finally {
    if ($logStarted) {Stop-Transcript | Out-Null}
}
exit $exitCode
