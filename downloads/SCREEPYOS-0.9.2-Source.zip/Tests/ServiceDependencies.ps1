$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot '../Executables/Payload/Gaming-Machine.ps1'),[ref]$tokens,[ref]$errors)
if ($errors.Count) {throw ($errors|Out-String)}
$loop=$ast.Find({param($n) $n -is [Management.Automation.Language.ForEachStatementAst] -and $n.Label -eq 'ApplyFeature'},$true)
if (-not $loop) {throw 'Missing feature loop'}
$block=[scriptblock]::Create(':ApplyFeature '+($loop.Extent.Text -replace '^:ApplyFeature\s*',''))
function Get-ItemProperty($path) {
 if ($path -match 'CurrentVersion') {return [pscustomobject]@{EditionID='Professional';CurrentBuild=26300;UBR=9457}}
 [pscustomobject]@{Start=$script:dependentStart}
}
function Get-Service($name) {
 [pscustomobject]@{Name=$name;DependentServices=@(if ($name -eq 'WSearch') {[pscustomobject]@{Name='workfolderssvc'}})}
}
function Snapshot($d) {[pscustomobject]@{Exists=$true;Value=$(if ($script:written -contains $d[0]) {4} else {2})}}
function WriteValue($d,$exists,$v) {if ($script:failWrite) {throw 'mock access denied'};$script:written+=,$d[0]}
function Save($file,$obj) {if ($script:failSave) {throw 'mock backup failure'}}
function Write-Warning($message) {$script:warnings+=,$message}
$defs=@{}
foreach ($id in @('WSearch','workfolderssvc','Spooler')) {$defs[$id]=@("SYSTEM\CurrentControlSet\Services\$id",'Start',4)}
$file='unused-mock';$passed=0
foreach ($case in @(
 @{Start=3;Names=@('WSearch','Spooler');Expected=@('Spooler');Code=0;Warn=$true},
 @{Start=4;Names=@('WSearch');Expected=@('WSearch');Code=0;Warn=$false},
 @{Start=3;Names=@('WSearch','workfolderssvc');Expected=@('WSearch','workfolderssvc');Code=0;Warn=$false},
 @{Start=4;Names=@('WSearch');Expected=@();Code=1;Warn=$false;FailWrite=$true},
 @{Start=4;Names=@('WSearch');Expected=@();Code=1;Warn=$false;FailSave=$true}
)) {
 $script:dependentStart=$case.Start;$names=$case.Names;$script:written=@();$code=0
 $script:failWrite=$case.FailWrite;$script:failSave=$case.FailSave
 $state=[pscustomobject]@{Items=@()};$script:warnings=@()
 . $block
 $actual=@($script:written|ForEach-Object {($_ -split '\\')[-1]})
 if (($actual -join ',') -ne ($case.Expected -join ',') -or $code -ne $case.Code) {throw 'Wrong writes/exit status'}
 if ($case.Warn -and -not ($warnings|Out-String).Contains('workfolderssvc')) {throw 'Missing dependent warning'}
 if ($case.Warn -and @($state.Items|Where-Object Id -eq 'WSearch').Count) {throw 'Skipped service must not be journaled'}
 $passed++
}
Write-Output "PASS: $passed service dependency regression scenarios; all OS operations mocked."
