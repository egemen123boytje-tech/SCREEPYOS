﻿#requires -Version 5.1
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$gameMutex=New-Object Threading.Mutex($false,('Local\SCREEPYOS-Games-'+[Security.Principal.WindowsIdentity]::GetCurrent().User.Value))
$ownsMutex=$false
try {$ownsMutex=$gameMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$ownsMutex=$true}
if (-not $ownsMutex) {
    [Windows.Forms.MessageBox]::Show('Game Center is already open.','SCREEPYOS') | Out-Null
    $gameMutex.Dispose()
    throw 'This page is already open.'
}
$root=Join-Path $env:LOCALAPPDATA 'SCREEPYOS' 
New-Item -ItemType Directory -Path $root -Force | Out-Null
$profileFile=Join-Path $root 'game-profiles.json'
$priorityFile=Join-Path $root 'priority-backup.json'
function Save-Data($Path,$Value) {
    $Value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$Path.tmp" -Encoding UTF8
    Move-Item -LiteralPath "$Path.tmp" -Destination $Path -Force
}
function Get-Data($Path) {
    if (Test-Path -LiteralPath $Path) { return @(Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json) }
    return @()
}
function Get-Metrics($Path) {
    $first=Get-Content -LiteralPath $Path -TotalCount 1
    $delimiter=','; if ($first.Contains(';')) {$delimiter=';'}
    $rows=@(Import-Csv -LiteralPath $Path -Delimiter $delimiter)
    if ($rows.Count -lt 100) { throw 'Use a frame-time CSV with at least 100 frames, preferably several thousand.' }
    $columns=@($rows[0].PSObject.Properties.Name)
    $column=@('FrameTimeMs','MsBetweenPresents','msBetweenPresents') | Where-Object { $columns -ccontains $_ } | Select-Object -First 1
    if (-not $column) { throw 'CSV must contain FrameTimeMs or MsBetweenPresents (milliseconds per frame).' }
    foreach ($identityColumn in @('Application','ProcessID','SwapChainAddress')) {
        if ($columns -contains $identityColumn) {
            $distinct=@($rows | ForEach-Object { $_.$identityColumn } | Select-Object -Unique)
            if ($distinct.Count -gt 1) { throw "CSV contains multiple values for $identityColumn. Export only the game and a single swap chain first." }
        }
    }
    $frames=New-Object 'System.Collections.Generic.List[double]'
    foreach ($row in $rows) {
        $value=0.0
        $raw=[string]$row.$column
        if ($delimiter -eq ';') { $raw=$raw.Replace(',','.') }
        $ok=[double]::TryParse($raw,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$value)
        if (-not $ok -or [double]::IsNaN($value) -or [double]::IsInfinity($value) -or $value -le 0) {
            throw 'CSV contains missing, zero or invalid frame times. Export a clean measurement period without the startup frame.'
        }
        $frames.Add($value)
    }
    $sorted=@($frames.ToArray() | Sort-Object -Descending)
    $tail=[int][math]::Ceiling($sorted.Count*0.01)
    $mean=($sorted | Measure-Object -Average).Average
    $slow=($sorted | Select-Object -First $tail | Measure-Object -Average).Average
    $p99=$sorted[$sorted.Count - [int][math]::Ceiling(0.99*$sorted.Count)]
    [pscustomobject]@{Frames=$sorted.Count; MeanMs=$mean; AverageFPS=1000.0/$mean; Low1FPS=1000.0/$slow; P99Ms=$p99; Source=$Path}
}
function Message($Text) { [Windows.Forms.MessageBox]::Show($form,$Text,'SCREEPYOS Game Center') | Out-Null }
$form=New-Object Windows.Forms.Form
$form.Text='SCREEPYOS 0.9.2 | Game Center'
$form.ClientSize=New-Object Drawing.Size(1000,650)
$form.StartPosition='CenterScreen'; $form.AutoScaleMode='Dpi'
$form.BackColor=[Drawing.Color]::FromArgb(17,17,19); $form.ForeColor=[Drawing.Color]::Gainsboro
$form.Font=New-Object Drawing.Font('Segoe UI',10)
$form.FormBorderStyle='Sizable'; $form.MaximizeBox=$true
$canvas=New-Object Windows.Forms.Panel
$canvas.Dock='Fill';$canvas.AutoScroll=$true
$canvas.AutoScrollMinSize=New-Object Drawing.Size(1080,780)
$form.Controls.Add($canvas)
function Label($Text,$X,$Y,$W,$H) {
    $c=New-Object Windows.Forms.Label; $c.Text=$Text
    $c.Location=New-Object Drawing.Point($X,$Y);$c.Size=New-Object Drawing.Size($W,$H);$canvas.Controls.Add($c)
}
function Button($Text,$X,$Y,$W,$Action) {
    $c=New-Object Windows.Forms.Button; $c.Text=$Text
    $c.Location=New-Object Drawing.Point($X,$Y);$c.Size=New-Object Drawing.Size($W,36)
    $c.FlatStyle='Flat';$c.BackColor=[Drawing.Color]::FromArgb(43,43,47)
    $c.Add_Click($Action);$canvas.Controls.Add($c)
}
Label 'SCRP OS / GAME CENTER' 25 18 900 35
Label 'Start your game through its normal launcher. Select the actual game executable here.' 25 58 930 30
$profiles=New-Object Windows.Forms.ListBox
$profiles.Location=New-Object Drawing.Point(25,95);$profiles.Size=New-Object Drawing.Size(610,130)
$profiles.BackColor=[Drawing.Color]::FromArgb(28,28,32);$profiles.ForeColor=$form.ForeColor;$canvas.Controls.Add($profiles)
$priority=New-Object Windows.Forms.ComboBox
$priority.Location=New-Object Drawing.Point(650,95);$priority.Size=New-Object Drawing.Size(290,30)
$priority.DropDownStyle='DropDownList';$priority.Items.AddRange(@('Normal','AboveNormal','High'));$priority.SelectedIndex=0
$canvas.Controls.Add($priority)
$script:Games=@()
function Refresh-Profiles {
    $script:Games=@(Get-Data $profileFile)
    $profiles.Items.Clear()
    foreach ($g in $script:Games) { $null=$profiles.Items.Add("$($g.Name) [$($g.Priority)]") }
}
$profiles.Add_SelectedIndexChanged({ if ($profiles.SelectedIndex -ge 0) { $priority.SelectedItem=[string]$script:Games[$profiles.SelectedIndex].Priority } })
Button 'Add game' 25 235 175 {
    try {
        $d=New-Object Windows.Forms.OpenFileDialog;$d.Filter='Game executable (*.exe)|*.exe'
        if ($d.ShowDialog() -ne 'OK') { return }
        $path=$d.FileName; $games=@(Get-Data $profileFile)
        if (@($games | Where-Object {$_.Path -eq $path}).Count -gt 0) { Message 'This profile already exists.'; return }
        $games += [pscustomobject]@{Name=[IO.Path]::GetFileNameWithoutExtension($path);Path=$path;Priority='Normal'}
        Save-Data $profileFile $games; Refresh-Profiles
    } catch { Message $_.Exception.Message }
}
Button 'Save profile' 210 235 175 {
    try {
        if ($profiles.SelectedIndex -lt 0) { throw 'Select a game first.' }
        $script:Games[$profiles.SelectedIndex].Priority=[string]$priority.SelectedItem
        Save-Data $profileFile $script:Games; Refresh-Profiles
    } catch { Message $_.Exception.Message }
}
Button 'Apply priority' 650 140 290 {
    try {
        if (Test-Path (Join-Path $root 'competitive-session.json')) {throw 'Stop and restore the current game session before using legacy priority controls.'}
        if ($profiles.SelectedIndex -lt 0) { throw 'Select a game first.' }
        $g=$script:Games[$profiles.SelectedIndex];$level=[string]$priority.SelectedItem
        if ($level -eq 'High' -and [Windows.Forms.MessageBox]::Show($form,'High priority may starve other processes. Test and compare results. Continue?','CPU priority','YesNo','Warning') -ne 'Yes') {return}
        $targets=@(Get-Process | Where-Object {
            try {$_.SessionId -eq [Diagnostics.Process]::GetCurrentProcess().SessionId -and $_.Path -eq $g.Path} catch {$false}
        })
        if ($targets.Count -eq 0) {throw 'No accessible game process found at this exact path. Start the game first; anti-cheat may block access.'}
        $backup=@(Get-Data $priorityFile);$ok=0;$failed=0
        foreach ($p in $targets) {
            try {
                $stamp=$p.StartTime.ToUniversalTime().Ticks.ToString()
                if (@($backup | Where-Object {$_.Id -eq $p.Id -and $_.StartTicks -eq $stamp}).Count -eq 0) {
                    $backup += [pscustomobject]@{Id=$p.Id;StartTicks=$stamp;Path=$g.Path;Priority=$p.PriorityClass.ToString();Applied=$level}
                    Save-Data $priorityFile $backup
                }
                $p.PriorityClass=([Diagnostics.ProcessPriorityClass]$level)
                $ok++
            } catch {$failed++}
        }
        Message "Applied to $ok process(es); $failed error(s). Only affects these active processes. This profile is not automatically applied when a game starts."
    } catch { Message $_.Exception.Message }
}
Button 'Restore priority' 650 187 290 {
    try {
        if (Test-Path (Join-Path $root 'competitive-session.json')) {throw 'Stop and restore the current game session first.'}
        $remaining=@();$restored=0
        foreach ($b in @(Get-Data $priorityFile)) {
            $p=Get-Process -Id $b.Id -ErrorAction SilentlyContinue
            if ($null -eq $p) {continue}
            try {
                if ($p.StartTime.ToUniversalTime().Ticks.ToString() -ne $b.StartTicks) {continue}
                if ($p.Path -ne $b.Path) {throw 'Process identity changed.'}
                if ($p.PriorityClass.ToString() -ne $b.Priority) {
                    if (-not ($b.PSObject.Properties.Name -contains 'Applied') -or $p.PriorityClass.ToString() -ne $b.Applied) {throw 'Priority changed elsewhere, or legacy backup has no applied value. Skipped.'}
                    $p.PriorityClass=([Diagnostics.ProcessPriorityClass]([string]$b.Priority))
                };$restored++
            } catch {$remaining += $b}
        }
        Save-Data $priorityFile $remaining
        Message "$restored process(es) restored; $($remaining.Count) still pending. Closed processes do not need recovery."
    } catch { Message $_.Exception.Message }
}
Label 'No Realtime priority or anti-cheat bypass. Normal is the default; AboveNormal is an optional test.' 25 280 930 30
Label 'BACKGROUND WINDOWS / only selected windows receive a close request' 25 323 925 26
$windows=New-Object Windows.Forms.CheckedListBox
$windows.Location=New-Object Drawing.Point(25,355);$windows.Size=New-Object Drawing.Size(610,115)
$windows.BackColor=$profiles.BackColor;$windows.ForeColor=$form.ForeColor;$windows.CheckOnClick=$true;$canvas.Controls.Add($windows)
$script:Windows=@()
Button 'Refresh windows' 650 355 290 {
    $script:Windows=@();$windows.Items.Clear()
    foreach ($p in @(Get-Process)) {
        try {
            if ($p.Id -eq $PID -or $p.SessionId -ne [Diagnostics.Process]::GetCurrentProcess().SessionId -or $p.MainWindowHandle -eq [IntPtr]::Zero) {continue}
            if ($p.ProcessName -in @('explorer','dwm','winlogon','csrss','services','lsass','sihost','ShellExperienceHost','StartMenuExperienceHost','ApplicationFrameHost')) {continue}
            $script:Windows += [pscustomobject]@{Id=$p.Id;StartTicks=$p.StartTime.ToUniversalTime().Ticks.ToString()}
            $null=$windows.Items.Add("$($p.ProcessName) - $($p.MainWindowTitle)")
        } catch {continue}
    }
}
Button 'Close selected windows' 650 407 290 {
    if ($windows.CheckedIndices.Count -eq 0) {return}
    if ([Windows.Forms.MessageBox]::Show($form,'Send a close request to the checked apps? Save your work. Apps may show their own save prompt.','Close windows','YesNo','Question') -ne 'Yes') {return}
    $sent=0
    foreach ($i in $windows.CheckedIndices) {
        try {
            $w=$script:Windows[$i];$p=Get-Process -Id $w.Id
            if ($p.StartTime.ToUniversalTime().Ticks.ToString() -eq $w.StartTicks -and $p.CloseMainWindow()) {$sent++}
        } catch {continue}
    }
    Message "$sent close request(s) sent. Apps are not forcibly terminated."
}
Label 'FRAME-TIME COMPARISON / import two CSV measurements from the same game and scene' 25 500 935 25
$script:Before=$null;$script:After=$null
$metrics=New-Object Windows.Forms.TextBox
$metrics.Location=New-Object Drawing.Point(25,572);$metrics.Size=New-Object Drawing.Size(915,110)
$metrics.Multiline=$true;$metrics.ReadOnly=$true;$metrics.BackColor=$profiles.BackColor;$metrics.ForeColor=$form.ForeColor;$canvas.Controls.Add($metrics)
function Show-Metrics {
    $lines=@()
    foreach ($key in @('Before','After')) {
        $m=Get-Variable -Name $key -Scope Script -ValueOnly
        if ($null -ne $m) {$lines += ('{0}: {1} frames | FPS {2:N1} | 1% low {3:N1} | P99 {4:N2} ms' -f $key,$m.Frames,$m.AverageFPS,$m.Low1FPS,$m.P99Ms)}
    }
    if ($null -ne $script:Before -and $null -ne $script:After) {
        $lines += ('FPS difference: {0:+0.0;-0.0;0.0}% | 1% low: {1:+0.0;-0.0;0.0}%' -f (100*($script:After.AverageFPS/$script:Before.AverageFPS-1)),(100*($script:After.Low1FPS/$script:Before.Low1FPS-1)))
    }
    $lines += '1% low = 1000 / average of the slowest 1% of frame times. This does not measure input latency.'
    $metrics.Text=$lines -join "`r`n"
}
function Import-Metric($Slot) {
    try {
        $d=New-Object Windows.Forms.OpenFileDialog;$d.Filter='Frametime CSV (*.csv)|*.csv'
        if ($d.ShowDialog() -ne 'OK') {return}
        $m=Get-Metrics $d.FileName
        Set-Variable -Name $Slot -Scope Script -Value $m
        Show-Metrics
    } catch {Message $_.Exception.Message}
}
Button 'Import BEFORE' 25 531 185 {Import-Metric 'Before'}
Button 'Import AFTER' 220 531 185 {Import-Metric 'After'}
Button 'Guide and game checklist' 650 531 290 {& $script:Navigate 'Help'}
Refresh-Profiles
Mount-ScrpPage $form {$gameMutex.ReleaseMutex();$gameMutex.Dispose()}
