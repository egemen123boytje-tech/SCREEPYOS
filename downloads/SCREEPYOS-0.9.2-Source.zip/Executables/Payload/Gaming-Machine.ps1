﻿#requires -Version 5.1
#requires -RunAsAdministrator
param([ValidateSet('Apply','Restore','Office','Edge')][string]$Mode='Apply',[string]$Features='', [Parameter(Mandatory=$true)][string]$ExpectedSid, [switch]$NoPrompt)
$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if ($identity.User.Value -ne $ExpectedSid) {throw 'Use the same account for UAC. Elevation under a different administrator account is not supported.'}
$root=Join-Path $env:ProgramData 'SCREEPYOS-Machine'
if (Test-Path $root) {if ((Get-Item $root).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Invalid backup directory.'}}
else {New-Item -ItemType Directory $root | Out-Null}
# Never consume writable backup data in an elevated process.
$acl=New-Object Security.AccessControl.DirectorySecurity
$acl.SetAccessRuleProtection($true,$false)
foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
 $rule=New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)),'FullControl','ContainerInherit,ObjectInherit','None','Allow')
 $acl.AddAccessRule($rule)
}
$reader=New-Object Security.AccessControl.FileSystemAccessRule($identity.User,'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow')
$acl.AddAccessRule($reader)
Set-Acl $root $acl
foreach ($child in (Get-ChildItem $root -Recurse -Force)) {if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Backup directory contains a link; action stopped.'}}
$defs=@{
 OneDrive=@('SOFTWARE\Policies\Microsoft\Windows\OneDrive','DisableFileSyncNGSC',1)
 Widgets=@('SOFTWARE\Policies\Microsoft\Dsh','AllowNewsAndInterests',0)
 DeliveryPeers=@('SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization','DODownloadMode',0)
 FastStartup=@('SYSTEM\CurrentControlSet\Control\Session Manager\Power','HiberbootEnabled',0)
 RecallSnapshots=@('SOFTWARE\Policies\Microsoft\Windows\WindowsAI','DisableAIDataAnalysis',1)
 WebSearch=@('SOFTWARE\Policies\Microsoft\Windows\Windows Search','ConnectedSearchUseWeb',0)
}
foreach ($s in @('Fax','MapsBroker','RetailDemo','RemoteRegistry','WMPNetworkSvc','DiagTrack','Spooler','WSearch','bthserv','BTAGService','BthAvctpSvc','BluetoothUserService')) {$defs[$s]=@("SYSTEM\CurrentControlSet\Services\$s",'Start',4)}
function Snapshot($d) {
 $k=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($d[0]);$exists=$false;$v=$null
 try {if ($k -and $k.GetValueNames() -contains $d[1]) {if ($k.GetValueKind($d[1]) -ne 'DWord') {throw 'Unexpected registry value type.'};$exists=$true;$v=$k.GetValue($d[1])}}
 finally {if ($k) {$k.Dispose()}}
 [pscustomobject]@{Exists=$exists;Value=$v}
}
function WriteValue($d,$exists,$v) {
 $k=[Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($d[0])
 try {if ($exists) {$k.SetValue($d[1],[int]$v,[Microsoft.Win32.RegistryValueKind]::DWord)} else {$k.DeleteValue($d[1],$false)}} finally {$k.Dispose()}
}
function Save($file,$obj) {$obj|ConvertTo-Json -Depth 8|Set-Content "$file.tmp" -Encoding UTF8;Move-Item "$file.tmp" $file -Force}
$mutex=New-Object Threading.Mutex($false,'Global\SCREEPYOS-Machine-04');$owned=$false;$code=0;$transcript=$false
try {
 try {$owned=$mutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$owned=$true}
 if (-not $owned) {throw 'Another system action is active.'}
 Start-Transcript (Join-Path $root ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.log')) | Out-Null;$transcript=$true
 if ($Mode -eq 'Edge') {
  . (Join-Path $PSScriptRoot 'BrowserEngine.ps1')
  $browserFound=[bool]((Get-ScrpBrowserPath Brave) -or (Get-ScrpBrowserPath Thorium))
  foreach ($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths')) {
   foreach ($name in @('chrome.exe','firefox.exe','brave.exe','opera.exe','thorium.exe')) {
    $entry=Get-ItemProperty -LiteralPath (Join-Path $key $name) -ErrorAction SilentlyContinue
    if ($entry -and $entry.'(default)' -and (Test-Path -LiteralPath $entry.'(default)')) {$browserFound=$true}
   }
  }
  if (-not $browserFound) {throw 'No other registered browser found. Install another browser first, or use Windows > Apps to uninstall manually.'}
  $base=Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application'
  if (-not (Test-Path (Join-Path $base 'msedge.exe'))) {
   $userEdge=Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'
   $nativeEdge=Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'
   if ((Test-Path $userEdge) -or (Test-Path $nativeEdge)) {throw 'Edge was found in a different install directory; use Windows > Apps to uninstall it.'}
   Write-Host 'Edge is already absent from the checked locations. WebView2 is kept.'
  } else {
  $setups=@(Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '^\d+\.\d+\.\d+\.\d+$'} | Sort-Object {[version]$_.Name} -Descending)
  $setup=$null
  foreach ($folder in $setups) {$candidate=Join-Path $folder.FullName 'Installer\setup.exe';if (Test-Path -LiteralPath $candidate) {$setup=$candidate;break}}
  if (-not $setup) {throw 'No Edge system installer found. Check Settings > Apps.'}
  $sig=Get-AuthenticodeSignature $setup
  if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'CN=Microsoft Corporation(?:,|$)') {throw 'Invalid Microsoft signature.'}
  $proc=Start-Process $setup -ArgumentList '--uninstall --system-level --verbose-logging' -PassThru
  if (-not $proc.WaitForExit(600000)) {throw 'The Edge uninstaller is still open after 10 minutes. Complete its dialog manually; it will not be forcibly closed.'}
  $proc.Refresh()
  $edgeStillPresent=Test-Path (Join-Path $base 'msedge.exe')
  Write-Host ('Edge uninstaller exit code: '+$proc.ExitCode+'; executable still present: '+$edgeStillPresent)
  if ($proc.ExitCode -ne 0 -or $edgeStillPresent) {throw 'Edge removal not confirmed. Windows may block it outside supported regions/builds. Use Settings > Apps; no forced bypass was applied.'}
  Write-Host 'Edge browser removed. WebView2 runtime is kept.'
  }
 } elseif ($Mode -eq 'Office') {
  $office='HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
  if (-not (Test-Path $office)) {throw 'No Click-to-Run Office found. Remove MSI or older Office versions through Settings > Apps.'}
  $busy=@(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -in @('WINWORD','EXCEL','POWERPNT','OUTLOOK','ONENOTE','MSACCESS','MSPUB','VISIO','WINPROJ')})
  if ($busy.Count) {throw 'Save your documents and close all Office apps, then try again.'}
  $work=Join-Path $root ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory $work | Out-Null
  $download=Join-Path $work 'ODT.exe'
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest 'https://download.microsoft.com/download/6c1eeb25-cf8b-41d9-8d0d-cc1dbc032140/officedeploymenttool_20326-20112.exe' -OutFile $download -UseBasicParsing -TimeoutSec 120
  function VerifyMicrosoft($f) {$sig=Get-AuthenticodeSignature $f;if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'CN=Microsoft Corporation(?:,|$)') {throw 'Microsoft signature is missing or invalid.'}}
  VerifyMicrosoft $download
  $proc=Start-Process $download -ArgumentList ('/quiet /extract:"'+$work+'"') -Wait -PassThru
  if ($proc.ExitCode -ne 0) {throw "ODT extraction failed: $($proc.ExitCode)"}
  $setup=Join-Path $work 'setup.exe';VerifyMicrosoft $setup
  $config=Join-Path $work 'remove.xml'
  '<Configuration><Remove All="TRUE"/><Display Level="Full" AcceptEULA="TRUE"/><Property Name="FORCEAPPSHUTDOWN" Value="FALSE"/></Configuration>' | Set-Content $config -Encoding UTF8
  $proc=Start-Process $setup -ArgumentList ('/configure "'+$config+'"') -Wait -PassThru
  if ($proc.ExitCode -notin @(0,3010)) {throw "Office removal stopped: $($proc.ExitCode)"}
  $remaining=Get-ItemProperty $office -Name ProductReleaseIds -ErrorAction SilentlyContinue
  if ($remaining -and $remaining.ProductReleaseIds) {throw 'Office products are still registered. Check the Office message and restart.'}
  Write-Host 'Office Click-to-Run removed. SCREEPYOS did not delete documents. Reinstalling requires an installer/license.'
 } elseif ($Mode -eq 'Apply') {
  $names=@($Features.Split(',')|Where-Object {$_}|Select-Object -Unique)
  if ($names -contains 'Bluetooth') {$names=@($names | Where-Object {$_ -ne 'Bluetooth'})+@('BTAGService','BthAvctpSvc','BluetoothUserService','bthserv')}
  foreach ($name in $names) {if (-not $defs.ContainsKey($name)) {throw "Unknown option: $name"}}
  $state=[pscustomobject]@{Version=1;Items=@();Restored=$false}
  $file=Join-Path $root ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+[guid]::NewGuid().ToString('N')+'.json')
  :ApplyFeature foreach ($name in $names) {
   try {
    $d=$defs[$name]
    $cv=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    if ($name -in @('DeliveryPeers','RecallSnapshots') -and $cv.EditionID -notmatch 'Professional|Enterprise|Education|IoT') {Write-Host "$name UNSUPPORTED: Windows edition";continue}
    if ($name -eq 'RecallSnapshots') {
     if ([int]$cv.CurrentBuild -lt 26100 -or ([int]$cv.CurrentBuild -eq 26100 -and [int]$cv.UBR -lt 3915)) {Write-Host 'Recall UNSUPPORTED: Windows build';continue}
     $recall=Get-WindowsOptionalFeature -Online -FeatureName Recall -ErrorAction SilentlyContinue
     if (-not $recall -or $recall.State -notin @('Enabled','EnablePending')) {Write-Host 'Recall NOT ACTIVE: skipped';continue}
    }
    if ($name -eq 'WebSearch' -and $cv.EditionID -notmatch 'Enterprise|Education|IoT') {Write-Host 'WebSearch UNSUPPORTED: policy only supports Enterprise/Education/IoT. Use Windows search settings.';continue}
    if ($name -eq 'Widgets') {
     $edition=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').EditionID
     if ($edition -notmatch 'Professional|Enterprise|Education|IoT') {Write-Host 'Widgets policy skipped: this Windows edition is not supported.';continue}
    }
    if ($d[0] -like 'SYSTEM\CurrentControlSet\Services\*') {
     $svc=Get-Service $name -ErrorAction SilentlyContinue
     if (-not $svc -and -not ($name -eq 'BluetoothUserService' -and (Test-Path ("HKLM:\"+$d[0])))) {Write-Host "$name is not present";continue}
     # Preserve any service with enabled dependents, including stopped trigger-start services.
     foreach ($dep in @($svc | ForEach-Object {$_.DependentServices})) {
      $start=(Get-ItemProperty ("HKLM:\SYSTEM\CurrentControlSet\Services\"+$dep.Name)).Start
      if ($start -ne 4 -and $names -notcontains $dep.Name -and -not ($names -contains 'BluetoothUserService' -and $dep.Name -match '^BluetoothUserService_[0-9a-fA-F]+$')) {Write-Warning "$name SKIPPED: enabled dependent service $($dep.Name). Both services are left unchanged.";continue ApplyFeature}
     }
    }
    $old=Snapshot $d
    if ($old.Exists -and $old.Value -eq $d[2]) {Write-Host "$name was already disabled";continue}
    $state.Items+= [pscustomobject]@{Id=$name;Before=$old}
    Save $file $state
    WriteValue $d $true $d[2]
    $actual=Snapshot $d
    if (-not $actual.Exists -or $actual.Value -ne $d[2]) {throw 'Verification after writing failed.'}
    Write-Host "$name configured. Restart required."
   } catch {$code=1;Write-Host "ERROR$name : $($_.Exception.Message)"}
  }
 } else {
  $file=$null;$state=$null
  foreach ($f in (Get-ChildItem $root -Filter '*.json' | Sort-Object Name -Descending)) {
   if ($f.Attributes -band [IO.FileAttributes]::ReparsePoint) {continue}
   $s=Get-Content $f.FullName -Raw|ConvertFrom-Json
   if ($s.Version -eq 1 -and -not $s.Restored) {$file=$f.FullName;$state=$s;break}
  }
  if (-not $file) {throw 'No active system backup.'}
  foreach ($item in $state.Items) {
   try {
    if (-not $defs.ContainsKey([string]$item.Id)) {throw 'Invalid backup option.'}
    $d=$defs[$item.Id];$now=Snapshot $d;$old=$item.Before
    if ($now.Exists -eq $old.Exists -and (-not $now.Exists -or $now.Value -eq $old.Value)) {continue}
    if (-not $now.Exists -or $now.Value -ne $d[2]) {throw 'Changed later: not overwritten.'}
    if ($old.Exists -and ($old.Value -isnot [int] -and $old.Value -isnot [long])) {throw 'Invalid original value.'}
    if ($d[0] -like 'SYSTEM\CurrentControlSet\Services\*' -and (-not $old.Exists -or $old.Value -notin @(2,3,4))) {throw 'Invalid original service state.'}
    WriteValue $d $old.Exists $old.Value
    $check=Snapshot $d
    if ($check.Exists -ne $old.Exists -or ($old.Exists -and $check.Value -ne $old.Value)) {throw 'Restore verification failed.'}
    Write-Host "RESTORED $($item.Id)"
   } catch {$code=1;Write-Host "ERROR restoring: $($_.Exception.Message)"}
  }
  if ($code -eq 0) {$state.Restored=$true;Save $file $state}
  Write-Host 'Restart to activate the restored system settings.'
 }
} catch {$code=1;Write-Host ('ERROR: '+$_.Exception.Message)}
finally {if ($transcript) {Stop-Transcript|Out-Null};if ($owned) {$mutex.ReleaseMutex()};$mutex.Dispose()}
Write-Host "Exit code: $code. Log files: $root"
if (-not $NoPrompt) {Read-Host 'Press Enter to close this window' | Out-Null}
exit $code
