﻿$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Executables/Payload/OptionalFeatures.ps1')
function Check($ok,$message) {if (-not $ok) {throw $message};Write-Output "PASS: $message"}
Check (@(Resolve-ScrpOptionalChoices @()).Count -eq 0) 'unchecked options make no changes'
Check ((@(Resolve-ScrpOptionalChoices @('OptionalPrinter')) -join ',') -eq 'Spooler') 'printer choice targets only printing'
Check ((@(Resolve-ScrpOptionalChoices @('OptionalBluetooth')) -join ',') -eq 'Bluetooth') 'Bluetooth requires explicit choice'
$all=@(Resolve-ScrpOptionalChoices @((Get-ScrpOptionalChoices).Keys))
Check ($all -notcontains 'WlanSvc' -and $all -notcontains 'WinDefend' -and $all -notcontains 'GamingServices') 'network, security and Xbox excluded'
$failed=$false;try {Resolve-ScrpOptionalChoices @('WinDefend')} catch {$failed=$true}
Check $failed 'unknown selections rejected before elevation'
[xml]$x=Get-Content (Join-Path $PSScriptRoot '../playbook.conf') -Raw
foreach ($id in @('disable-printer','disable-bluetooth','disable-search')) {
 $o=@($x.Playbook.FeaturePages.CheckboxPage.Options.CheckboxOption | Where-Object {$_.Name -eq $id})
 Check ($o.Count -eq 1 -and $o[0].IsChecked -eq 'false') "$id defaults to unchanged"
}
Write-Output 'ALL 8 OPTIONAL FEATURE CHECKS PASSED'
