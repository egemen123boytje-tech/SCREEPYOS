﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path $PSScriptRoot ('performance-fixtures-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $testRoot|Out-Null
$oldLocal=$env:LOCALAPPDATA;$env:LOCALAPPDATA=Join-Path $testRoot 'Local'
$script:checks=0
function Check($Condition,$Label) {if (-not $Condition) {throw "FAIL: $Label"};$script:checks++;"PASS: $Label"}
function Reject($Action) {try {& $Action|Out-Null;return $false} catch {return $true}}
try {
 . (Join-Path $PSScriptRoot '../Executables/Payload/PerformanceEngine.ps1')
 . (Join-Path $PSScriptRoot '../Executables/Payload/CaptureEngine.ps1')
 $game=[pscustomobject]@{Version=1;Id=('b'*32);Name='Fixture';Path=(Join-Path $testRoot 'game.exe');Launch='';Priority='Normal';Power=$false;CaptureOff=$false;Hud=$false}
 function Get-CProcesses($Game) {return @()}
 $file=Join-Path $testRoot 'game.cfg';[IO.File]::WriteAllBytes($file,[byte[]]@(239,187,191,65,13,10))
 $original=Get-ConfigHash $file
 Save-GameSnapshot $game $file 'Low'
 [IO.File]::WriteAllText($file,'BEFORE EXPERIMENT');$before=Get-ConfigHash $file
 Apply-GameSnapshot $game 'Low'
 Check ((Get-ConfigHash $file) -eq $original) 'snapshot apply preserves BOM and exact bytes'
 Check (Reject {Apply-GameSnapshot $game 'Low'}) 'second experiment blocked while recovery pending'
 Finish-ConfigExperiment $game
 Check ((Get-ConfigHash $file) -eq $before) 'restore returns exact original file'
 Apply-GameSnapshot $game 'Low';[IO.File]::WriteAllText($file,'changed by game')
 Check (Reject {Finish-ConfigExperiment $game}) 'later game changes are not overwritten'
 Check ([IO.File]::ReadAllText($file) -eq 'changed by game') 'conflict retains current file'
 $preview=Get-ConfigExperimentPreview $game
 Check (Reject {Finish-ConfigExperiment $game -ExpectedCurrentHash ('f'*64)}) 'stale conflict confirmation cannot overwrite newer changes'
 Finish-ConfigExperiment $game -ExpectedCurrentHash $preview.CurrentHash
 Check ((Get-ConfigHash $file) -eq $before) 'explicit conflict review can restore original config'
 $completed=@(Get-ChildItem (Get-TuningFolder $game) -Filter 'completed-*.json'|ForEach-Object {Get-Content $_.FullName -Raw|ConvertFrom-Json}|Where-Object {$_.PSObject.Properties.Name -contains 'Displaced'})
 Check ($completed.Count -eq 1 -and (Get-ConfigHash (Join-Path (Get-TuningFolder $game) $completed[0].Displaced)) -eq $preview.CurrentHash) 'conflict restore retains displaced file backup'
 Apply-GameSnapshot $game 'Low'
 Finish-ConfigExperiment $game -Keep
 Check (-not (Test-Path (Join-Path (Get-TuningFolder $game) 'config-journal.json'))) 'keep archives recovery journal'
 Check (Reject {Save-GameSnapshot $game $file '../escape'}) 'invalid slot rejected'
 $scriptFile=Join-Path $testRoot 'fake.ps1';'fixture'|Set-Content $scriptFile
 Check (Reject {Assert-ConfigPath $scriptFile}) 'executable script config rejected'
 $snapshotMeta=Get-Content (Join-Path (Get-TuningFolder $game) 'Low.json') -Raw|ConvertFrom-Json
 'tampered'|Set-Content (Join-Path (Get-TuningFolder $game) $snapshotMeta.Blob)
 Check (Reject {Apply-GameSnapshot $game 'Low'}) 'tampered snapshot refused'
 Check (Reject {Get-SnapshotBlob (Get-TuningFolder $game) '..\escape.snapshot'}) 'snapshot traversal rejected'
 function Get-CProcesses($Game) {return @([pscustomobject]@{Id=123})}
 Check (Reject {Save-GameSnapshot $game $file 'Mid'}) 'running game blocks configuration mutation'
 Check (-not (Test-BackgroundTarget $game.Path $game.Path)) 'game process is protected'
 Check (-not (Test-BackgroundTarget 'C:\Program Files\Steam\steam.exe' $game.Path)) 'launcher is protected'
 Check (-not (Test-BackgroundTarget ($env:SystemRoot+'\System32\notepad.exe') $game.Path)) 'Windows executables are protected'
 $script:fake=[pscustomobject]@{Id=123;StartTime=[datetime]::Now;Path='C:\Apps\Browser\browser.exe';SessionId=[Diagnostics.Process]::GetCurrentProcess().SessionId;Closed=$false}
 $script:fake|Add-Member ScriptMethod CloseMainWindow {$this.Closed=$true;return $true}
 $candidate=[pscustomobject]@{Id=123;Stamp=$script:fake.StartTime.ToUniversalTime().Ticks.ToString();Path=$script:fake.Path;Label='Fixture browser'}
 function Get-Process {param($Id,$ErrorAction) return $script:fake}
 $null=Close-BackgroundCandidate $candidate $game
 Check $script:fake.Closed 'selected window receives normal close request'
 $script:fake.Closed=$false;$script:fake.StartTime=$script:fake.StartTime.AddSeconds(1)
 Check (Reject {Close-BackgroundCandidate $candidate $game}) 'PID reuse is rejected'
 Check (-not $script:fake.Closed) 'wrong process never receives close request'
 $args=New-CaptureArguments 123 60 'C:\Capture Folder\frames.csv' ('SCRP'+('a'*32))
 Check ($args.Contains('--v1_metrics') -and $args.Contains('--output_file "C:\Capture Folder\frames.csv"') -and $args.Contains('--no_track_input')) 'capture uses compatible frames, quoted path and no input tracking'
 Check (Reject {New-CaptureArguments 123 1000 'x' ('SCRP'+('a'*32))}) 'unbounded capture duration rejected'
 "ALL $script:checks PERFORMANCE CHECKS PASSED."
} finally {
 $env:LOCALAPPDATA=$oldLocal
 if (-not ([IO.Path]::GetFullPath($testRoot).StartsWith([IO.Path]::GetFullPath($PSScriptRoot)+[IO.Path]::DirectorySeparatorChar))) {throw 'Invalid fixture cleanup path.'}
 Remove-Item -LiteralPath $testRoot -Recurse -Force
}
