﻿$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../Executables/Payload/BenchmarkEngine.ps1')
$root=Join-Path $PSScriptRoot ('fixtures-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $root|Out-Null
$script:checks=0
function Check($ok,$label) {if (-not $ok) {throw "FAIL: $label"};$script:checks++;"PASS: $label"}
function Reject($path) {try {Get-Metrics $path|Out-Null;return $false} catch {return $true}}
try {
 $file=Join-Path $root 'run.csv'
 @('FrameTimeMs')+@(1..100|ForEach-Object {'10'}) | Set-Content $file
 $a=Get-Metrics $file
 Check ($a.AverageFPS -eq 100 -and $a.Low1FPS -eq 100 -and $a.P99Ms -eq 10) 'constant frame time yields expected FPS/lows/P99'
 @('FrameTimeMs')+@(1..99|ForEach-Object {'10'})+@('100') | Set-Content $file
 $b=Get-Metrics $file
 Check ([math]::Abs($b.AverageFPS-(100000.0/1090)) -lt 0.00001 -and $b.Low1FPS -eq 10 -and $b.P99Ms -eq 10) 'single stutter changes average and slowest-one-percent low'
 $summary=Get-BenchmarkSummary @($a,$a,$b)
 Check ($summary.MedianFPS -eq 100 -and $summary.MinFPS -eq $b.AverageFPS -and $summary.Runs -eq 3) 'multi-run median and range'
 $summary=Get-BenchmarkSummary @($a,$b)
 Check ($summary.MedianFPS -eq (($a.AverageFPS+$b.AverageFPS)/2)) 'even run count median'
 Check ($null -eq (Get-BenchmarkSummary @()) -and $null -eq (Get-BenchmarkSummary $null)) 'empty comparison remains unmeasured'
 @('FrameTimeMs')+@(1..99|ForEach-Object {'10'})+@('0') | Set-Content $file
 Check (Reject $file) 'zero frame time rejected'
 @('FrameTimeMs')+@(1..99|ForEach-Object {'10'})+@('NaN') | Set-Content $file
 Check (Reject $file) 'NaN rejected'
 @('FrameTimeMs')+@(1..99|ForEach-Object {'10'}) | Set-Content $file
 Check (Reject $file) 'too-short capture rejected'
 @('FrameTimeMs,ProcessID')+@(1..99|ForEach-Object {'10,1'})+@('10,2') | Set-Content $file
 Check (Reject $file) 'mixed game processes rejected'
 @('MsBetweenPresents;ProcessID')+@(1..100|ForEach-Object {'12,5;1'}) | Set-Content $file
 Check ((Get-Metrics $file).AverageFPS -eq 80) 'semicolon delimiter with decimal commas supported'
 @('MsBetweenPresents','0')+@(1..100|ForEach-Object {'10'}) | Set-Content $file
 Check ((Get-Metrics $file).Frames -eq 100 -and (Get-Metrics $file).AverageFPS -eq 100) 'PresentMon initial zero frame is excluded explicitly'
 @('MsBetweenPresents','0')+@(1..99|ForEach-Object {'10'}) | Set-Content $file
 Check (Reject $file) 'minimum valid frame count enforced after initial zero'
 "ALL $script:checks BENCHMARK CHECKS PASSED."
} finally {
 $resolved=[IO.Path]::GetFullPath($root)
 if (-not $resolved.StartsWith([IO.Path]::GetFullPath($PSScriptRoot)+[IO.Path]::DirectorySeparatorChar)) {throw 'Invalid fixture cleanup path.'}
 Remove-Item -LiteralPath $resolved -Recurse -Force
}
