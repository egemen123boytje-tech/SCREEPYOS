﻿if ($PSVersionTable.PSVersion.Major -lt 7) {Write-Output 'SKIP: PowerShell 7 simulation only; run Queue.ps1 on native 5.1.';return}
$ErrorActionPreference='Stop'
# Reproduce Windows PowerShell 5.1's non-enumerating ConvertFrom-Json output.
function ConvertFrom-Json {
    [CmdletBinding()]
    param([Parameter(ValueFromPipeline=$true)]$InputObject)
    process { Microsoft.PowerShell.Utility\ConvertFrom-Json -InputObject $InputObject -NoEnumerate }
}
. (Join-Path $PSScriptRoot '../Executables/Payload/OptionalFeatures.ps1')
$dir=Join-Path ([IO.Path]::GetTempPath()) ('scrp-compat-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($dir) | Out-Null
try {
    $old=@(ConvertFrom-Json -InputObject '["OptionalPrinter"]')
    if ($old[0] -is [string]) {throw 'Test does not reproduce the old failure.'}
    'PASS: old command wrapping reproduces a non-string array element'
    $p=Join-Path $dir 'empty.json'
    [IO.File]::WriteAllText($p,'[]')
    if (@(Read-ScrpWizardChoices $p).Count -ne 0) {throw 'Empty array failed.'}
    'PASS: empty array supported with non-enumerating output'
    & (Join-Path $PSScriptRoot 'Queue.ps1')
    'ALL 14 COMPATIBILITY CHECKS PASSED (simulated 5.1 output on PowerShell 7)'
} finally {Remove-Item $dir -Recurse -Force}
