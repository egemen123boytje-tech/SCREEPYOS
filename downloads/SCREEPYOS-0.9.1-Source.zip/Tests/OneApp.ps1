﻿param([string]$Payload=(Join-Path $PSScriptRoot '../Executables/Payload'))
$ErrorActionPreference='Stop';$checks=0
function Assert($yes,$message) {if (-not $yes) {throw "FAIL: $message"};$script:checks++;"PASS: $message"}
. (Join-Path $Payload 'DriverEngine.ps1')
Assert ((Get-ScrpVendor 'PCI\VEN_10DE&DEV_1' 'GPU') -eq 'NVIDIA') 'NVIDIA from PCI vendor'
Assert ((Get-ScrpVendor 'PCI\VEN_1002&DEV_1' 'GPU') -eq 'AMD') 'AMD from PCI vendor'
Assert ((Get-ScrpVendor 'PCI\VEN_8086&DEV_1' 'GPU') -eq 'Intel') 'Intel GPU from PCI vendor'
Assert ((Get-ScrpVendor 'PCI\VEN_9999&DEV_1' 'GPU') -eq 'Unknown') 'unknown hardware not guessed'
Assert ((Get-ScrpVendor 'PCI\VEN_15AD&DEV_1' 'VMware SVGA') -eq 'Virtual') 'VMware not classified as physical vendor'
Add-Type -TypeDefinition (Get-Content (Join-Path $Payload 'AppLauncher.cs') -Raw)
$args=[ScrpLauncher]::BuildArguments('C:\Test Folder\App.ps1',[string[]]@('Competitive',('a'*32),'AutoStart'))
Assert ($args.Contains('-File "C:\Test Folder\App.ps1"') -and $args.EndsWith('-AutoStart')) 'launcher quotes script path and forwards profile'
$threw=$false;try {[ScrpLauncher]::BuildArguments('x',[string[]]@('Other'))} catch {$threw=$true};Assert $threw 'launcher rejects unknown page'
$threw=$false;try {[ScrpLauncher]::BuildArguments('x',[string[]]@('Competitive','abc;calc'))} catch {$threw=$true};Assert $threw 'launcher rejects command injection in profile'
$mod1=New-Module -Name ScrpMockOne -ScriptBlock {$script:Value='one';$localState=40;function Change {$script:Value+='!';return $localState};$script:Event={Change}}
$mod2=New-Module -Name ScrpMockTwo -ScriptBlock {$script:Value='two';$localState=80;function Change {$script:Value+='?';return $localState};$script:Event={Change}}
$callback1=& $mod1 {$script:Event};$callback2=& $mod2 {$script:Event}
Assert ((& $callback1) -eq 40 -and (& $callback2) -eq 80) 'event handlers keep page-local functions and variables after initialization'
Assert ((& $mod1 {$script:Value}) -eq 'one!' -and (& $mod2 {$script:Value}) -eq 'two?') 'same function and variable names remain isolated across pages'
foreach ($name in @('SCREEPYOS','Profiles','GameCenter','GamingOnly','Cleanup','Competitive','Drivers')) {
 $s=Get-Content (Join-Path $Payload ($name+'.ps1')) -Raw
 Assert ($s.Contains('Mount-ScrpPage') -and $s -notmatch 'Start-Process\s+\(Join-Path\s+\$PSScriptRoot\s+[^\r\n]+\.cmd') ('embedded page has no console navigation: '+$name)
}
$worker=Get-Content (Join-Path $Payload 'Gaming-Machine.ps1') -Raw
Assert ($worker.Contains('if (-not $NoPrompt)')) 'GUI worker does not wait for invisible Enter prompt'
$hostCode=Get-Content (Join-Path $Payload 'PageHost.ps1') -Raw
Assert ($hostCode.Contains('-WindowStyle Hidden') -and $hostCode.Contains('-NoPrompt')) 'elevated worker launched without console or read prompt'
$competitive=Get-Content (Join-Path $Payload 'Competitive.ps1') -Raw
Assert (-not $competitive.Contains('$script:CHudForm.Show()')) 'HUD remains inside app'
'ALL '+$checks+' ONE-APP CHECKS PASSED (not native Windows UI integration).'
