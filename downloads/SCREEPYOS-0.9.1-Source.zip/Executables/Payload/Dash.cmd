@echo off
start "" "%~dp0SCREEPYOS.exe" Home
exit /b
