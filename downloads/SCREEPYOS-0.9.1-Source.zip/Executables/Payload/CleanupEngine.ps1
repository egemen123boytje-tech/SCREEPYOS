﻿#requires -Version 5.1
function Get-CleanRoots {
 @{
  Temp=(Join-Path $env:LOCALAPPDATA 'Temp')
  Reports=(Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WER\ReportArchive')
  Shader=(Join-Path $env:LOCALAPPDATA 'D3DSCache')
 }
}
function Test-CleanPath([string]$path,[string]$root) {
 $r=[IO.Path]::GetFullPath($root).TrimEnd('\','/')
 $f=[IO.Path]::GetFullPath($path)
 if (-not $f.StartsWith($r+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {return $false}
 $cursor=$f
 while ($cursor) {
  if (Test-Path -LiteralPath $cursor) {
   if ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {return $false}
  }
  $next=[IO.Path]::GetDirectoryName($cursor)
  if ($next -eq $cursor) {break};$cursor=$next
 }
 return $true
}
function Get-CleanPlan([string[]]$categories) {
 $roots=Get-CleanRoots;$count=0
 foreach ($id in $categories) {
  if (-not $roots.ContainsKey($id)) {throw 'Unknown cleanup category.'}
  $root=$roots[$id]
  if (-not (Test-Path -LiteralPath $root -PathType Container)) {continue}
  $stack=New-Object 'System.Collections.Generic.Stack[string]';$stack.Push($root)
  while ($stack.Count) {
   $folder=$stack.Pop()
   if ($folder -ne $root -and -not (Test-CleanPath $folder $root)) {continue}
   if ((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {continue}
   foreach ($f in @(Get-ChildItem -LiteralPath $folder -Force -ErrorAction SilentlyContinue)) {
    $count++;if ($count -gt 100000) {throw 'More than 100,000 items. Use Windows Storage for this folder.'}
    if ($f.Attributes -band [IO.FileAttributes]::ReparsePoint) {continue}
    if ($f.PSIsContainer) {$stack.Push($f.FullName);continue}
    if ($id -ne 'Shader' -and $f.LastWriteTimeUtc -gt [DateTime]::UtcNow.AddDays(-7)) {continue}
    if (Test-CleanPath $f.FullName $root) {[pscustomobject]@{Category=$id;Root=$root;Path=$f.FullName;Bytes=$f.Length;Stamp=$f.LastWriteTimeUtc.Ticks}}
   }
  }
 }
}
function Invoke-CleanPlan($plan) {
 $removed=0;$bytes=0L;$skipped=0;$roots=Get-CleanRoots
 foreach ($item in $plan) {
  try {
   if (-not $roots.ContainsKey($item.Category) -or $roots[$item.Category] -ne $item.Root) {throw 'Invalid root directory.'}
   if (-not (Test-CleanPath $item.Path $item.Root)) {throw 'Path has changed or is a link.'}
   $f=Get-Item -LiteralPath $item.Path -Force
   if ($f.PSIsContainer -or $f.Length -ne $item.Bytes -or $f.LastWriteTimeUtc.Ticks -ne $item.Stamp) {throw 'File has changed since the preview.'}
   Remove-Item -LiteralPath $f.FullName -ErrorAction Stop
   $removed++;$bytes+=$item.Bytes
  } catch {$skipped++}
 }
 [pscustomobject]@{Removed=$removed;Bytes=$bytes;Skipped=$skipped}
}
