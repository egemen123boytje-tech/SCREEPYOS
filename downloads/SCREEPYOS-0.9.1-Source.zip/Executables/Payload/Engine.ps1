﻿# SCREEPYOS 0.1 - current-user changes only. Dot-sourced by the dashboard.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:DataRoot = Join-Path $env:LOCALAPPDATA 'SCREEPYOS'
$script:Sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
function New-Tweak($Path, $Name, $Value, $Kind = 'DWord') {
    [pscustomobject]@{ Path=$Path; Name=$Name; Value=$Value; Kind=$Kind }
}
function Get-Tweaks($Options) {
    $cv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion'
    if ($Options.Theme) {
        New-Tweak "$cv\Themes\Personalize" 'AppsUseLightTheme' 0
        New-Tweak "$cv\Themes\Personalize" 'SystemUsesLightTheme' 0
        New-Tweak "$cv\Themes\Personalize" 'EnableTransparency' 0
        New-Tweak "$cv\Themes\Personalize" 'ColorPrevalence' 0
        New-Tweak 'HKCU:\Software\Microsoft\Windows\DWM' 'ColorPrevalence' 0
        New-Tweak 'HKCU:\Software\Microsoft\Windows\DWM' 'AccentColor' 4284900966
        New-Tweak 'HKCU:\Control Panel\Desktop' 'WallpaperStyle' '10' 'String'
        New-Tweak 'HKCU:\Control Panel\Desktop' 'TileWallpaper' '0' 'String'
    }
    if ($Options.GameMode) {
        New-Tweak 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1
        New-Tweak 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1
    }
    if ($Options.Capture) {
        New-Tweak 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0
        New-Tweak "$cv\GameDVR" 'AppCaptureEnabled' 0
        New-Tweak "$cv\GameDVR" 'HistoricalCaptureEnabled' 0
    }
    if ($Options.Quiet) {
        foreach ($name in @('SoftLandingEnabled','SystemPaneSuggestionsEnabled','SilentInstalledAppsEnabled',
                'SubscribedContent-338388Enabled','SubscribedContent-338389Enabled','SubscribedContent-353694Enabled',
                'SubscribedContent-353696Enabled')) {
            New-Tweak "$cv\ContentDeliveryManager" $name 0
        }
        New-Tweak "$cv\AdvertisingInfo" 'Enabled' 0
        New-Tweak "$cv\Privacy" 'TailoredExperiencesWithDiagnosticDataEnabled' 0
        New-Tweak "$cv\UserProfileEngagement" 'ScoobeSystemSettingEnabled' 0
        New-Tweak "$cv\Explorer\Advanced" 'ShowSyncProviderNotifications' 0
        New-Tweak "$cv\Explorer\Advanced" 'TaskbarMn' 0
    }
    if ($Options.PSObject.Properties.Name -contains 'ProfileVisual') {
        if ($Options.ProfileVisual -notin @('Minimal','Reduced','Full')) {throw 'Unknown visual profile.'}
        $window='1'; $taskbar=1
        if ($Options.ProfileVisual -eq 'Minimal') {$window='0';$taskbar=0}
        if ($Options.ProfileVisual -eq 'Reduced') {$taskbar=0}
        New-Tweak 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' $window 'String'
        New-Tweak "$cv\Explorer\Advanced" 'TaskbarAnimations' $taskbar
    }
    if ($Options.PSObject.Properties.Name -contains 'EdgeBackground' -and $Options.EdgeBackground) {
        New-Tweak 'HKCU:\Software\Policies\Microsoft\Edge' 'StartupBoostEnabled' 0
        New-Tweak 'HKCU:\Software\Policies\Microsoft\Edge' 'BackgroundModeEnabled' 0
    }
    if ($Options.PSObject.Properties.Name -contains 'OneDriveStartup' -and $Options.OneDriveStartup) {
        New-Tweak "$cv\Run" 'OneDrive' $null 'Delete'
    }
    if ($Options.Animations) {
        New-Tweak 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String'
        New-Tweak "$cv\Explorer\Advanced" 'TaskbarAnimations' 0
    }
}
function Get-RegistrySnapshot($Tweak) {
    $key = Get-Item -LiteralPath $Tweak.Path -ErrorAction SilentlyContinue
    $exists = $null -ne $key -and $key.GetValueNames() -contains $Tweak.Name
    $kind = $null; $value = $null
    if ($exists) {
        $kind = $key.GetValueKind($Tweak.Name).ToString()
        $value = $key.GetValue($Tweak.Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    }
    [pscustomobject]@{ Path=$Tweak.Path; Name=$Tweak.Name; Exists=$exists; Kind=$kind; Value=$value }
}
function Set-RegValue($Path, $Name, $Value, $Kind) {
    if ($Path -notlike 'HKCU:\*') { throw 'Only HKCU settings are allowed.' }
    if ($Kind -eq 'Delete') {
        if (Test-Path -LiteralPath $Path) {Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue}
        return
    }
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -Path $Path -Force | Out-Null }
    # DWORD values use the signed Int32 representation in the registry provider.
    if ($Kind -eq 'DWord') {
        $n = [long]$Value
        if ($n -gt [int]::MaxValue) { $n -= 4294967296 }
        $Value = [int]$n
    }
    if ($Kind -eq 'Binary') { $Value = [byte[]]$Value }
    if ($Kind -eq 'MultiString') { $Value = [string[]]$Value }
    if ($Kind -eq 'QWord') { $Value = [long]$Value }
    New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Kind -Force | Out-Null
}
function Set-Wallpaper($Path) {
    if (-not ('Scrp.Native' -as [type])) {
        Add-Type @'
using System;
using System.Runtime.InteropServices;
namespace Scrp { public static class Native {
 [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
 public static extern bool SystemParametersInfo(int action, int parameter, string value, int flags);
} }
'@
    }
    if (-not [Scrp.Native]::SystemParametersInfo(20, 0, $Path, 3)) {
        throw "Failed to change wallpaper: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
    }
}
function Write-JsonFile($Path, $Object) {
    $temporary = "$Path.tmp"
    $Object | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}
function Invoke-ScrpApplyCore($Options, $Packages, $Wallpaper, $LogCallback) {
    $id = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
    $run = Join-Path $script:DataRoot "Backups\$id"
    New-Item -ItemType Directory -Path $run -Force | Out-Null
    $tweaks = @(Get-Tweaks $Options)
    if ($Options.Theme) {
        if (-not (Test-Path -LiteralPath $Wallpaper)) { throw 'Wallpaper is missing. Reinstall the complete playbook.' }
        $savedWallpaper = Join-Path $run 'SCRP-OS.png'
        Copy-Item -LiteralPath $Wallpaper -Destination $savedWallpaper
        $tweaks += New-Tweak 'HKCU:\Control Panel\Desktop' 'Wallpaper' $savedWallpaper 'String'
    }
    $before = @($tweaks | ForEach-Object { Get-RegistrySnapshot $_ })
    $state = [pscustomobject]@{ Version=2; Intended=@($tweaks | ForEach-Object {Get-ScrpIntended $_}); Sid=$script:Sid; Created=(Get-Date).ToString('o');
        Registry=$before; Packages=@($Packages | Select-Object -Property @("Name", "PackageFullName")); Options=$Options }
    # All original values are saved before the first registry change or app removal.
    Write-JsonFile (Join-Path $run 'before.json') $state
    $failures = 0
    foreach ($t in $tweaks) {
        try {
            Set-RegValue $t.Path $t.Name $t.Value $t.Kind
            if (-not (Test-ScrpSame (Get-RegistrySnapshot $t) (Get-ScrpIntended $t))) {throw 'Registry verification after writing failed.'}
            & $LogCallback "OK setting: $($t.Name)"
        } catch { $failures++; & $LogCallback "ERROR$($t.Name): $($_.Exception.Message)" }
    }
    if ($Options.Theme) {
        try { Set-Wallpaper $savedWallpaper; & $LogCallback 'OK wallpaper applied.' }
        catch { $failures++; & $LogCallback "ERROR wallpaper: $($_.Exception.Message)" }
    }
    $appResults = @()
    foreach ($p in $Packages) {
        $result = [ordered]@{ Name=$p.Name; PackageFullName=$p.PackageFullName; Removed=$false; Error=$null }
        try {
            if ($p.Name -like 'Microsoft.Xbox*' -or $p.Name -in @('Microsoft.GamingApp','Microsoft.GamingServices')) {
                throw 'Xbox components are protected in this profile.'
            }
            Remove-AppxPackage -Package $p.PackageFullName -ErrorAction Stop
            $result.Removed=$true; & $LogCallback "REMOVED: $($p.Name)"
        } catch {
            $failures++; $result.Error=$_.Exception.Message
            & $LogCallback "KEPT / ERROR $($p.Name): $($_.Exception.Message)"
        }
        $appResults += [pscustomobject]$result
        Write-JsonFile (Join-Path $run 'apps-result.json') $appResults
    }
    & $LogCallback "Backup: $run"
    & $LogCallback "Finished with $failures error(s). Sign out and back in to refresh all visual changes."
    [pscustomobject]@{ Run=$run; Failures=$failures }
}
function Get-LatestBackup {
    $base = Join-Path $script:DataRoot 'Backups'
    if (-not (Test-Path -LiteralPath $base)) { return $null }
    Get-ChildItem -LiteralPath $base -Directory | Sort-Object Name -Descending |
        Where-Object { (Test-Path (Join-Path $_.FullName 'before.json')) -and
                      -not (Test-Path (Join-Path $_.FullName 'restored.txt')) } |
        Select-Object -First 1
}
function Invoke-ScrpRestoreCore($LogCallback) {
    $backup = Get-LatestBackup
    if ($null -eq $backup) { throw 'No active backup exists for this user.' }
    $state = Get-Content (Join-Path $backup.FullName 'before.json') -Raw | ConvertFrom-Json
    if ($state.Version -notin @(1,2) -or $state.Sid -ne $script:Sid) { throw 'Backup does not belong to this user or version.' }
    if ($state.Version -eq 1) {throw 'This old backup does not record applied values. Automatic conflict-aware recovery is unavailable. Use the old version with care or restore a full system backup.'}
    $failures = 0
    # Refresh desktop before exact registry restore, because SPI also writes Wallpaper.
    $wall = @($state.Registry | Where-Object { $_.Path -eq 'HKCU:\Control Panel\Desktop' -and $_.Name -eq 'Wallpaper' })
    if ($wall.Count -gt 0) {
        try {
            $old = ''; if ($wall[0].Exists) { $old = [string]$wall[0].Value }
            if ($old -and -not (Test-Path -LiteralPath $old)) { throw 'Original wallpaper is missing; select it again in Personalization.' }
            $wanted=@($state.Intended | Where-Object {$_.Path -eq $wall[0].Path -and $_.Name -eq 'Wallpaper'})
            if (-not (Test-ScrpSame (Get-RegistrySnapshot $wall[0]) $wall[0])) {
                if ($wanted.Count -ne 1 -or -not (Test-ScrpSame (Get-RegistrySnapshot $wall[0]) $wanted[0])) {throw 'Wallpaper was changed later; not overwritten.'}
                Set-Wallpaper $old
            }
        } catch { $failures++; & $LogCallback "ERROR restoring wallpaper: $($_.Exception.Message)" }
    }
    foreach ($t in $state.Registry) {
        try {
            if ($t.Path -notlike 'HKCU:\*') { throw 'Invalid registry path in backup.' }
            # Skip a value already equal to its backup (also handles the failed Widgets write in 0.2.1).
            $current = Get-RegistrySnapshot $t
            $same = $current.Exists -eq $t.Exists
            if ($same -and $t.Exists) {
                $same = ($current.Kind -eq $t.Kind) -and
                    ((ConvertTo-Json -InputObject $current.Value -Compress -Depth 8) -eq
                     (ConvertTo-Json -InputObject $t.Value -Compress -Depth 8))
            }
            if ($same) { & $LogCallback "UNCHANGED: $($t.Name)"; continue }
            $wanted=@($state.Intended | Where-Object {$_.Path -eq $t.Path -and $_.Name -eq $t.Name})
            if ($wanted.Count -ne 1 -or -not (Test-ScrpSame $current $wanted[0])) {throw 'Changed later or never applied: restoration skipped.'}
            if ($t.Exists) { Set-RegValue $t.Path $t.Name $t.Value $t.Kind }
            elseif (Test-Path -LiteralPath $t.Path) {
                $key = Get-Item -LiteralPath $t.Path
                if ($key.GetValueNames() -contains $t.Name) {
                    Remove-ItemProperty -LiteralPath $t.Path -Name $t.Name -ErrorAction Stop
                }
            }
            if (-not (Test-ScrpSame (Get-RegistrySnapshot $t) $t)) {throw 'Restore verification failed.'}
            & $LogCallback "RESTORED: $($t.Name)"
        } catch { $failures++; & $LogCallback "ERROR restoring $($t.Name): $($_.Exception.Message)" }
    }
    if ($failures -eq 0) { 'Settings restored. Removed apps are not restored.' | Set-Content (Join-Path $backup.FullName 'restored.txt') }
    & $LogCallback "Restore finished with $failures error(s). Removed apps and app data were NOT restored."
    & $LogCallback 'Reinstall any apps you need through Microsoft Store. Sign out and back in.'
    return $failures
}

function Get-ScrpIntended($T) {
    $v=$T.Value
    if ($T.Kind -eq 'DWord' -and [long]$v -gt [int]::MaxValue) {$v=[int]([long]$v-4294967296)}
    [pscustomobject]@{Path=$T.Path;Name=$T.Name;Exists=($T.Kind -ne 'Delete');Kind=$(if ($T.Kind -eq 'Delete') {$null} else {$T.Kind});Value=$v}
}
function Test-ScrpSame($A,$B) {
    if ($A.Exists -ne $B.Exists) {return $false}
    if (-not $A.Exists) {return $true}
    return ($A.Kind -eq $B.Kind -and (ConvertTo-Json -InputObject $A.Value -Compress -Depth 8) -eq (ConvertTo-Json -InputObject $B.Value -Compress -Depth 8))
}
function Invoke-ScrpLocked($Work) {
    $m=New-Object Threading.Mutex($false,('Local\SCREEPYOS-Settings-'+$script:Sid));$own=$false
    try {
        try {$own=$m.WaitOne(0)} catch [Threading.AbandonedMutexException] {$own=$true}
        if (-not $own) {throw 'Another SCREEPYOS window is applying settings. Wait until it finishes.'}
        & $Work
    } finally {if ($own) {$m.ReleaseMutex()};$m.Dispose()}
}
function Invoke-ScrpApply($Options,$Packages,$Wallpaper,$LogCallback) {Invoke-ScrpLocked {Invoke-ScrpApplyCore $Options $Packages $Wallpaper $LogCallback}}
function Invoke-ScrpRestore($LogCallback) {Invoke-ScrpLocked {Invoke-ScrpRestoreCore $LogCallback}}
