﻿function Set-ScrpTheme($Root) {
 $Root.BackColor=[Drawing.Color]::FromArgb(10,10,10)
 $Root.ForeColor=[Drawing.Color]::FromArgb(235,235,235)
 foreach ($c in $Root.Controls) {
  Set-ScrpTheme $c
  if ($c -is [Windows.Forms.Button]) {
   $c.FlatStyle='Flat';$c.FlatAppearance.BorderSize=1
   $c.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(65,65,65)
   $c.FlatAppearance.MouseOverBackColor=[Drawing.Color]::FromArgb(52,52,52)
   $c.BackColor=[Drawing.Color]::FromArgb(28,28,28)
   $c.UseMnemonic=$false;$c.Cursor=[Windows.Forms.Cursors]::Hand
  } elseif ($c -is [Windows.Forms.TextBox] -or $c -is [Windows.Forms.ListBox] -or $c -is [Windows.Forms.ComboBox]) {
   $c.BackColor=[Drawing.Color]::FromArgb(20,20,20)
  }
 }
}
