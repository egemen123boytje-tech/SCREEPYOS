﻿#requires -Version 5.1
& (Join-Path $PSScriptRoot 'App.ps1')
