﻿#requires -Version 5.1
# No vendor drivers, services, firmware or security policies are changed.
. (Join-Path $PSScriptRoot 'Engine.ps1')
$script:PowerBackup = Join-Path $script:DataRoot 'power-profile-backup.json'
function Get-ScrpHardware {
    $result=[ordered]@{ CPU='Unknown'; GPU='Unknown'; RAM='Unknown'; System='Unknown'; Virtual=$false; Architecture=$env:PROCESSOR_ARCHITECTURE; Build='Unknown'; HVCI='Unknown'; VBS='Unknown'; Power='Unknown' }
    try { $result.CPU=(@(Get-CimInstance Win32_Processor | ForEach-Object {$_.Name}) -join '; ') } catch {}
    try { $result.GPU=(@(Get-CimInstance Win32_VideoController | ForEach-Object {$_.Name+' (driver '+$_.DriverVersion+')'}) -join '; ') } catch {}
    try {
        $cs=Get-CimInstance Win32_ComputerSystem
        $result.RAM=('{0:N1} GB' -f ($cs.TotalPhysicalMemory/1073741824))
        $result.System=$cs.Manufacturer+' '+$cs.Model
        $result.Virtual=$result.System -match 'VMware|VirtualBox|Virtual Machine|KVM|QEMU|Parallels|Xen'
    } catch {}
    try { $result.Build=(Get-CimInstance Win32_OperatingSystem).BuildNumber } catch {}
    try {
        $dg=Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard
        $result.HVCI=if (@($dg.SecurityServicesRunning) -contains 2) {'Active'} else {'Inactive'}
        $result.VBS=switch ([int]$dg.VirtualizationBasedSecurityStatus) {
            0 {'Off'}
            1 {'Configured, inactive'}
            2 {'Active'}
            default {'Unknown'}
        }
    } catch { $result.HVCI='Cannot read status; check Windows Security' }
    try { $result.Power=Get-ScrpActivePower } catch {}
    [pscustomobject]$result
}
function Invoke-ScrpPowercfg([string[]]$Arguments) {
    $output=& (Join-Path $env:SystemRoot 'System32\powercfg.exe') @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw ('Power plan was not changed or could not be read: '+($output -join ' ')) }
    return ($output -join "`n")
}
function Get-ScrpActivePower {
    $raw=Invoke-ScrpPowercfg @('/getactivescheme')
    $m=[regex]::Match($raw,'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}')
    if (-not $m.Success) {throw 'Active power plan GUID not found.'}
    $m.Value.ToLowerInvariant()
}
function Get-ScrpPowerPlans {
    $raw=Invoke-ScrpPowercfg @('/list')
    foreach ($line in ($raw -split "`n")) {
        $m=[regex]::Match($line,'(?<id>[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})\s+\((?<label>.+)\)')
        if ($m.Success) { [pscustomobject]@{ Id=$m.Groups['id'].Value.ToLowerInvariant(); Label=$m.Groups['label'].Value } }
    }
}
function Set-ScrpPower([string]$Target) {
    if (@(Get-ScrpPowerPlans | Where-Object {$_.Id -eq $Target}).Count -ne 1) {throw 'Power plan unavailable. Use Windows power settings.'}
    $current=Get-ScrpActivePower
    if ($current -eq $Target) {return 'This power plan is already active.'}
    if (Test-Path -LiteralPath $script:PowerBackup) {throw 'A power plan backup already exists. Restore it before testing another plan.'}
    New-Item -ItemType Directory -Path $script:DataRoot -Force | Out-Null
    # Save before mutation, including a failed or interrupted attempt.
    Write-JsonFile $script:PowerBackup ([pscustomobject]@{Sid=$script:Sid;Before=$current;Applied=$Target;Created=(Get-Date).ToString('o')})
    $null=Invoke-ScrpPowercfg @('/setactive',$Target)
    if ((Get-ScrpActivePower) -ne $Target) {throw 'The new plan was not confirmed. Use Restore power plan.'}
    'Power plan applied. Use Restore power plan after your test.'
}
function Restore-ScrpPower {
    if (-not (Test-Path -LiteralPath $script:PowerBackup)) {return 'No power plan backup found.'}
    $b=Get-Content -LiteralPath $script:PowerBackup -Raw | ConvertFrom-Json
    if ($b.Sid -ne $script:Sid) {throw 'This backup belongs to another user.'}
    $current=Get-ScrpActivePower
    if ($current -ne $b.Before -and $current -ne $b.Applied) {throw 'The power plan was changed elsewhere. Backup kept; select the original plan manually in Windows.'}
    if ($current -ne $b.Before) {
        if (@(Get-ScrpPowerPlans | Where-Object {$_.Id -eq $b.Before}).Count -ne 1) {throw 'The original power plan no longer exists.'}
        $null=Invoke-ScrpPowercfg @('/setactive',[string]$b.Before)
        if ((Get-ScrpActivePower) -ne $b.Before) {throw 'Restore not confirmed; backup kept.'}
    }
    Remove-Item -LiteralPath $script:PowerBackup
    'Original power plan restored.'
}
