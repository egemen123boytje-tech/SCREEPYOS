﻿#requires -Version 5.1
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'CleanupEngine.ps1')
$form=New-DashForm 'SCREEPYOS / Disk Cleanup';$canvas=New-DashCanvas $form 720
$tip=New-Object Windows.Forms.ToolTip
$null=Add-DashLabel $canvas 'D I S K   C L E A N U P' 24 22 900 48 23
$null=Add-DashLabel $canvas 'Preview first, then delete. Downloads and games are not selected.' 26 83 880 45
$temp=Add-DashCheck $canvas 'User temporary files older than 7 days' 26 150 870 $true $tip 'Only LocalAppData\Temp. Locked or changed files and links are skipped.'
$reports=Add-DashCheck $canvas 'Old error-report archives for this user' 26 194 870 $false $tip 'Only WER ReportArchive files older than 7 days. Deleted reports are no longer available for diagnostics.'
$shader=Add-DashCheck $canvas 'DirectX shader cache (only for cache problems)' 26 238 870 $false $tip 'WARNING: rebuilding the cache can cause temporary stutter. This is not a standard FPS tweak. Close games first.'
$script:CleanList=New-Object Windows.Forms.TextBox;$script:CleanList.SetBounds(26,352,880,235);$script:CleanList.Multiline=$true;$script:CleanList.ReadOnly=$true;$script:CleanList.ScrollBars='Both';$canvas.Controls.Add($script:CleanList)
$script:CleanPlan=@();$script:CleanSelection=''
function CleanSelection { $ids=@();if ($temp.Checked) {$ids+='Temp'};if ($reports.Checked) {$ids+='Reports'};if ($shader.Checked) {$ids+='Shader'};return $ids }
$null=Add-DashButton $canvas 'Preview selection' 26 294 280 {
 try {
  $script:CleanPlan=@(Get-CleanPlan @(CleanSelection));$script:CleanSelection=(@(CleanSelection)-join ',')
  $total=($script:CleanPlan|Measure-Object Bytes -Sum).Sum
  $lines=@(('{0} files / {1:N1} MB. Preview shows up to 150 paths.' -f $script:CleanPlan.Count,($total/1048576)))
  $lines+=@($script:CleanPlan|Select-Object -First 150|ForEach-Object {$_.Path})
  $script:CleanList.Text=$lines -join "`r`n"
 } catch {$script:CleanList.Text=$_.Exception.Message}
}
$null=Add-DashButton $canvas 'Delete previewed files' 326 294 280 {
 if ((@(CleanSelection)-join ',') -ne $script:CleanSelection -or -not $script:CleanPlan.Count) {[Windows.Forms.MessageBox]::Show('Create a fresh preview first.','SCREEPYOS')|Out-Null;return}
 if ([Windows.Forms.MessageBox]::Show('These files will be permanently deleted, not moved to the Recycle Bin. Continue?','SCREEPYOS cleanup','YesNo','Warning') -ne 'Yes') {return}
 $result=Invoke-CleanPlan $script:CleanPlan;$script:CleanPlan=@()
 $script:CleanList.Text=('{0} files deleted / {1:N1} MB. {2} skipped (locked or changed).' -f $result.Removed,($result.Bytes/1048576),$result.Skipped)
}
$null=Add-DashButton $canvas 'Windows storage / system cleanup' 26 614 425 {Start-Process 'ms-settings:storagesense'}
$null=Add-DashButton $canvas 'Open Recycle Bin (empty manually)' 471 614 435 {Start-Process explorer.exe -ArgumentList 'shell:RecycleBinFolder'}
$null=Add-DashLabel $canvas 'Cleanup frees disk space. It does not guarantee higher FPS. Deleted files cannot be restored by this tool.' 26 666 880 42
Mount-ScrpPage $form {$tip.Dispose()}
