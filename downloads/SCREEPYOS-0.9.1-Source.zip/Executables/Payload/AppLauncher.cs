using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
public static class ScrpLauncher {
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int MessageBox(IntPtr handle,string text,string caption,uint flags);
 public static string BuildArguments(string scriptPath,string[] args) {
  string page=args.Length>0?args[0]:"Home";
  string[] pages={"Home","Competitive","Gaming","Metrics","Cleanup","Theme","Hardware","Drivers","Help","Performance"};
  if (Array.IndexOf(pages,page)<0) throw new ArgumentException("Unknown page.");
  if (scriptPath.IndexOf('"')>=0) throw new ArgumentException("Invalid script path.");
  string result="-NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File \""+scriptPath+"\" -Page "+page;
  if(args.Length>1) {
   if(!Regex.IsMatch(args[1],"\\A[0-9a-f]{32}\\z")) throw new ArgumentException("Invalid game profile.");
   result+=" -ProfileId "+args[1];
  }
  if(args.Length>2) {if(args[2]!="AutoStart") throw new ArgumentException("Invalid launch option.");result+=" -AutoStart";}
  if(args.Length>3) throw new ArgumentException("Too many arguments.");
  return result;
 }
 [STAThread] public static void Main(string[] args) {
  try {
   string root=AppDomain.CurrentDomain.BaseDirectory;
   string script=Path.Combine(root,"App.ps1");
   if(!File.Exists(script)) throw new FileNotFoundException("App.ps1 is missing. Reinstall SCREEPYOS.");
   string exe=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),@"System32\WindowsPowerShell\v1.0\powershell.exe");
   ProcessStartInfo info=new ProcessStartInfo(exe,BuildArguments(script,args));
   info.UseShellExecute=false;info.CreateNoWindow=true;info.WindowStyle=ProcessWindowStyle.Hidden;info.WorkingDirectory=root;
   Process.Start(info);
  } catch(Exception e) {MessageBox(IntPtr.Zero,e.Message,"SCREEPYOS failed to start",0x10);}
 }
}
