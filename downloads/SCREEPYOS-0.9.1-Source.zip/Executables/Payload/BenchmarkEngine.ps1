﻿function Get-Metrics($Path) {
    $first=Get-Content -LiteralPath $Path -TotalCount 1
    $delimiter=','; if ($first.Contains(';')) {$delimiter=';'}
    $rows=@(Import-Csv -LiteralPath $Path -Delimiter $delimiter)
    if ($rows.Count -lt 100) { throw 'Use a frame-time CSV with at least 100 frames, preferably several thousand.' }
    $columns=@($rows[0].PSObject.Properties.Name)
    $column=@('FrameTimeMs','MsBetweenPresents','msBetweenPresents') | Where-Object { $columns -ccontains $_ } | Select-Object -First 1
    if (-not $column) { throw 'CSV must contain FrameTimeMs or MsBetweenPresents (milliseconds per frame).' }
    foreach ($identityColumn in @('Application','ProcessID','SwapChainAddress')) {
        if ($columns -contains $identityColumn) {
            $distinct=@($rows | ForEach-Object { $_.$identityColumn } | Select-Object -Unique)
            if ($distinct.Count -gt 1) { throw "CSV contains multiple values for $identityColumn. Export only the game and a single swap chain first." }
        }
    }
    $frames=New-Object 'System.Collections.Generic.List[double]'
    $rowIndex=-1
    foreach ($row in $rows) {
        $rowIndex++
        $value=0.0
        $raw=[string]$row.$column
        if ($delimiter -eq ';') { $raw=$raw.Replace(',','.') }
        $ok=[double]::TryParse($raw,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$value)
        if ($ok -and $value -eq 0 -and $rowIndex -eq 0) {continue}
        if (-not $ok -or [double]::IsNaN($value) -or [double]::IsInfinity($value) -or $value -le 0) {
            throw 'CSV contains missing, zero or invalid frame times. Export a clean measurement period without the startup frame.'
        }
        $frames.Add($value)
    }
    if ($frames.Count -lt 100) {throw 'At least 100 valid frame times are required after excluding an initial zero.'}
    $sorted=@($frames.ToArray() | Sort-Object -Descending)
    $tail=[int][math]::Ceiling($sorted.Count*0.01)
    $mean=($sorted | Measure-Object -Average).Average
    $slow=($sorted | Select-Object -First $tail | Measure-Object -Average).Average
    $p99=$sorted[$sorted.Count - [int][math]::Ceiling(0.99*$sorted.Count)]
    [pscustomobject]@{Frames=$sorted.Count; MeanMs=$mean; AverageFPS=1000.0/$mean; Low1FPS=1000.0/$slow; P99Ms=$p99; Source=$Path}
}

function Get-BenchmarkSummary($Runs) {
 $items=@($Runs | Where-Object {$null -ne $_});if (-not $items.Count) {return $null}
 $fps=@($items | ForEach-Object {$_.AverageFPS} | Sort-Object)
 $mid=[int][math]::Floor($fps.Count/2)
 $median=if ($fps.Count % 2) {$fps[$mid]} else {($fps[$mid-1]+$fps[$mid])/2}
 [pscustomobject]@{Runs=$items.Count;MedianFPS=$median;MinFPS=$fps[0];MaxFPS=$fps[-1];MeanLow=($items|Measure-Object Low1FPS -Average).Average;MeanP99=($items|Measure-Object P99Ms -Average).Average}
}

