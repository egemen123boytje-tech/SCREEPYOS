﻿function New-CaptureArguments($GameId,$Seconds,$Output,$Session) {
 if ([int]$GameId -le 0 -or [int]$Seconds -lt 15 -or [int]$Seconds -gt 600 -or $Output.Contains('"') -or $Session -notmatch '^SCRP[0-9a-f]{32}$') {throw 'Invalid capture options.'}
 return ('--process_id '+[int]$GameId+' --timed '+[int]$Seconds+' --output_file "'+$Output+'" --session_name '+$Session+' --v1_metrics --no_console_stats --no_track_input --terminate_after_timed --terminate_on_proc_exit')
}
function Start-PerformanceCapture($Game,$Seconds,$PresentMon,$Gpu,$Temperatures) {
 $targets=@(Get-CProcesses $Game)
 if ($targets.Count -ne 1) {throw 'Start the actual game first. Capture requires exactly one accessible process matching its executable path.'}
 if ($Seconds -lt 15 -or $Seconds -gt 600) {throw 'Choose 15 to 600 seconds.'}
 if ($PresentMon -and (-not (Test-Path -LiteralPath $PresentMon -PathType Leaf) -or [IO.Path]::GetFileName($PresentMon) -notmatch '^PresentMon.*\.exe$')) {throw 'Choose the official PresentMon console executable, or leave it empty for telemetry only.'}
 $id=[guid]::NewGuid().ToString('N');$folder=Join-Path $script:DataRoot ('Captures\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+$id.Substring(0,6));New-Item -ItemType Directory $folder -Force|Out-Null
 $hostProcess=Get-Process -Id $PID
 $request=Join-Path $folder 'capture.json';$stopFile=Join-Path $folder 'stop';$target=$targets[0]
 $cfg=[pscustomobject]@{Version=1;GameName=$Game.Name;GamePath=$Game.Path;GameId=$target.Id;GameStamp=$target.StartTime.ToUniversalTime().Ticks.ToString();HostId=$PID;HostStamp=$hostProcess.StartTime.ToUniversalTime().Ticks.ToString();Seconds=$Seconds;GpuCounters=[bool]$Gpu;Temperatures=[bool]$Temperatures;Output=(Join-Path $folder 'telemetry.csv');StopFile=$stopFile}
 Write-JsonFile $request $cfg
 $pm=$null
 if ($PresentMon) {
  $arguments=New-CaptureArguments $target.Id $Seconds (Join-Path $folder 'frames.csv') ('SCRP'+$id)
  $pm=Start-Process -FilePath $PresentMon -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $folder 'presentmon.log') -RedirectStandardError (Join-Path $folder 'presentmon-error.log')
 }
 $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $worker=Start-Process -FilePath $exe -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'TelemetryWorker.ps1')+'" -Request "'+$request+'"') -WindowStyle Hidden -PassThru
 return [pscustomobject]@{Folder=$folder;Worker=$worker;PresentMon=$pm;StopFile=$stopFile;Started=(Get-Date);Seconds=$Seconds}
}
