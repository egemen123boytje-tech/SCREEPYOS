@echo off
start "" "%~dp0SCREEPYOS.exe" Hardware
exit /b
