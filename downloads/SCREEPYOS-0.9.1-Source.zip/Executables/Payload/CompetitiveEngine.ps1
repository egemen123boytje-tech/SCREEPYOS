﻿#requires -Version 5.1
. (Join-Path $PSScriptRoot 'ProfilesEngine.ps1')
$script:CProfileRoot=Join-Path $script:DataRoot 'CompetitiveProfiles'
$script:CJournal=Join-Path $script:DataRoot 'competitive-session.json'
function Test-CProfile($p) {
 if ($p.Version -ne 1 -or $p.Id -notmatch '^[0-9a-f]{32}$') {throw 'Unknown profile version or invalid ID.'}
 if ($p.Priority -notin @('Normal','AboveNormal','High')) {throw 'Invalid priority.'}
 foreach ($key in @('Power','CaptureOff','Hud')) {if ($p.$key -isnot [bool]) {throw "Invalid option $key"}}
 if (-not [IO.Path]::IsPathRooted($p.Path) -or [IO.Path]::GetExtension($p.Path) -ne '.exe') {throw 'Choose the full path to the game executable.'}
 if ($p.Launch -and ([IO.Path]::GetExtension($p.Launch) -notin @('.exe','.lnk','.url'))) {throw 'Launch file must be an exe, lnk or game URL shortcut.'}
 if ($p.Path.StartsWith($env:SystemRoot+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'A Windows system process cannot be a game profile.'}
 if ([IO.Path]::GetFileNameWithoutExtension($p.Path) -in @('steam','EpicGamesLauncher','Battle.net','XboxPcApp','powershell','pwsh','cmd','explorer','msedge')) {throw 'Choose the actual game process; put the launcher in Launch file.'}
}
function Save-CProfile($p) {
 Test-CProfile $p
 New-Item -ItemType Directory $script:CProfileRoot -Force | Out-Null
 Write-JsonFile (Join-Path $script:CProfileRoot ($p.Id+'.json')) $p
}
function Read-CProfile([string]$id) {
 if ($id -notmatch '^[0-9a-f]{32}$') {throw 'Invalid profile ID.'}
 $p=Get-Content -LiteralPath (Join-Path $script:CProfileRoot ($id+'.json')) -Raw|ConvertFrom-Json
 Test-CProfile $p
 if ($p.Id -ne $id) {throw 'Profile ID does not match.'}
 return $p
}
function Get-CProfiles {
 if (Test-Path $script:CProfileRoot) {
  foreach ($f in Get-ChildItem $script:CProfileRoot -Filter '*.json') {
   try {Read-CProfile $f.BaseName} catch {Write-Warning "Profile skipped: $($f.Name)"}
  }
 }
}
function Get-CProcesses($p) {
 foreach ($proc in @(Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($p.Path)) -ErrorAction SilentlyContinue)) {
  try {if ($proc.SessionId -eq [Diagnostics.Process]::GetCurrentProcess().SessionId -and $proc.Path -eq $p.Path) {$proc}} catch {}
 }
}
function Save-CSession {Write-JsonFile $script:CJournal $script:CSession}
function New-CSession($p) {
 Test-CProfile $p
 if (Test-Path $script:CJournal) {throw 'A session backup is pending. Select Recover previous session first.'}
 if (-not (Test-Path -LiteralPath $p.Path -PathType Leaf)) {throw 'Game executable not found.'}
 if ($p.Launch -and -not (Test-Path -LiteralPath $p.Launch -PathType Leaf)) {throw 'Launch file not found.'}
 New-Item -ItemType Directory $script:DataRoot -Force | Out-Null
 $opts=[pscustomobject]@{Theme=$false;GameMode=$false;Capture=$p.CaptureOff;Quiet=$false;Animations=$false}
 $tweaks=@(Get-Tweaks $opts)
 $script:CSession=[pscustomobject]@{Version=1;Sid=$script:Sid;Game=$p.Path;Registry=@();Processes=@();Power=$null;Created=(Get-Date).ToString('o')}
 foreach ($t in $tweaks) {$script:CSession.Registry += [pscustomobject]@{Before=(Get-RegistrySnapshot $t);Applied=(Get-ScrpIntended $t)}}
 if ($p.Power) {
  if ([Windows.Forms.SystemInformation]::PowerStatus.PowerLineStatus -ne 'Online') {throw 'High performance requires AC power. Disable this profile option on battery.'}
  $target='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
  if (@(Get-ScrpPowerPlans|Where-Object {$_.Id -eq $target}).Count -ne 1) {throw 'High performance is unavailable. Disable this profile option; no power plan is forced.'}
  $script:CSession.Power=[pscustomobject]@{Before=(Get-ScrpActivePower);Applied=$target}
 }
 Save-CSession
 foreach ($t in $tweaks) {
  Set-RegValue $t.Path $t.Name $t.Value $t.Kind
  if (-not (Test-ScrpSame (Get-RegistrySnapshot $t) (Get-ScrpIntended $t))) {throw 'Capture setting not confirmed.'}
 }
 if ($script:CSession.Power) {
  $null=Invoke-ScrpPowercfg @('/setactive',$script:CSession.Power.Applied)
  if ((Get-ScrpActivePower) -ne $script:CSession.Power.Applied) {throw 'Power plan not confirmed.'}
 }
}
function Set-CPriority($proc,$level) {
 $stamp=$proc.StartTime.ToUniversalTime().Ticks.ToString()
 $known=@($script:CSession.Processes|Where-Object {$_.Id -eq $proc.Id -and $_.Stamp -eq $stamp})
 if ($known.Count) {return}
 $original=$proc.PriorityClass.ToString()
 $record=[pscustomobject]@{Id=$proc.Id;Stamp=$stamp;Path=$proc.Path;Before=$original;Applied=$level}
 $script:CSession.Processes += $record
 Save-CSession
 $proc.PriorityClass=[Diagnostics.ProcessPriorityClass]$level
 $proc.Refresh()
 if ($proc.PriorityClass.ToString() -ne $level) {throw 'Priority not confirmed.'}
}
function Restore-CSession {
 if (-not (Test-Path $script:CJournal)) {return @()}
 $s=Get-Content $script:CJournal -Raw|ConvertFrom-Json
 if ($s.Version -ne 1 -or $s.Sid -ne $script:Sid) {throw 'Session backup has an unknown version or user.'}
 $fail=New-Object 'System.Collections.Generic.List[string]'
 foreach ($r in $s.Registry) {
  try {
   $allowed=@('HKCU:\System\GameConfigStore|GameDVR_Enabled','HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR|AppCaptureEnabled','HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR|HistoricalCaptureEnabled')
   $t=$r.Before
   if (($t.Path+'|'+$t.Name) -notin $allowed) {throw 'Unknown registry target.'}
   $current=Get-RegistrySnapshot $t
   if (Test-ScrpSame $current $t) {continue}
   if (-not (Test-ScrpSame $current $r.Applied)) {throw "Changed later: $($t.Name)"}
   if ($t.Exists) {Set-RegValue $t.Path $t.Name $t.Value $t.Kind} else {Set-RegValue $t.Path $t.Name $null 'Delete'}
   if (-not (Test-ScrpSame (Get-RegistrySnapshot $t) $t)) {throw 'Registry restore not confirmed.'}
  } catch {$fail.Add($_.Exception.Message)}
 }
 foreach ($r in $s.Processes) {
  $proc=Get-Process -Id $r.Id -ErrorAction SilentlyContinue
  if (-not $proc) {continue}
  try {
   if ($proc.StartTime.ToUniversalTime().Ticks.ToString() -ne $r.Stamp) {continue}
   if ($proc.Path -ne $r.Path -or $proc.SessionId -ne [Diagnostics.Process]::GetCurrentProcess().SessionId) {throw 'Process identity does not match.'}
   if ($proc.PriorityClass.ToString() -eq $r.Before) {continue}
   if ($proc.PriorityClass.ToString() -ne $r.Applied) {throw 'Priority was changed elsewhere.'}
   $proc.PriorityClass=[Diagnostics.ProcessPriorityClass]([string]$r.Before)
   $proc.Refresh();if ($proc.PriorityClass.ToString() -ne $r.Before) {throw 'Priority restore not confirmed.'}
  } catch {$fail.Add("PID $($r.Id): $($_.Exception.Message)")}
 }
 if ($s.Power) {
  try {
   $current=Get-ScrpActivePower
   if ($current -ne $s.Power.Before) {
    if ($current -ne $s.Power.Applied) {throw 'Power plan was changed elsewhere.'}
    $null=Invoke-ScrpPowercfg @('/setactive',[string]$s.Power.Before)
    if ((Get-ScrpActivePower) -ne $s.Power.Before) {throw 'Power plan recovery not confirmed.'}
   }
  } catch {$fail.Add($_.Exception.Message)}
 }
 if ($fail.Count -eq 0) {Remove-Item $script:CJournal}
 return $fail.ToArray()
}
function New-CShortcut($p) {
 Test-CProfile $p
 $desktop=[Environment]::GetFolderPath('Desktop')
 $path=Join-Path $desktop ('SCRP Competitive '+$p.Id.Substring(0,8)+'.lnk')
 $shell=New-Object -ComObject WScript.Shell;$link=$shell.CreateShortcut($path)
 $link.TargetPath=Join-Path $PSScriptRoot 'SCREEPYOS.exe'
 $link.Arguments='Competitive '+$p.Id+' AutoStart'
 $link.WorkingDirectory=$PSScriptRoot;$link.Description='SCREEPYOS Competitive: '+$p.Name
 $link.IconLocation=$p.Path+',0';$link.Save()
 return $path
}
