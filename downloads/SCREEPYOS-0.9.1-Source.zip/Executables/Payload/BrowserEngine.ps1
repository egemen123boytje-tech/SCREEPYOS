﻿#requires -Version 5.1
function Get-ScrpBrowserPath([ValidateSet('Brave','Thorium')][string]$Browser) {
 $exe=if ($Browser -eq 'Brave') {'brave.exe'} else {'thorium.exe'}
 $paths=@()
 foreach ($key in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths')) {
  $entry=Get-ItemProperty -LiteralPath (Join-Path $key $exe) -ErrorAction SilentlyContinue
  if ($entry -and $entry.PSObject.Properties['(default)']) {$paths += [string]$entry.'(default)'}
 }
 $relative=if ($Browser -eq 'Brave') {'BraveSoftware\Brave-Browser\Application\brave.exe'} else {'Thorium\Application\thorium.exe'}
 foreach ($root in @($env:LOCALAPPDATA,$env:ProgramFiles,${env:ProgramFiles(x86)})) {
  if ($root) {$paths += Join-Path $root $relative}
 }
 foreach ($path in $paths) {
  $path=$path.Trim('"')
  if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) {
   $item=Get-Item -LiteralPath $path
   if ($item.Length -gt 0 -and $item.VersionInfo.ProductName -match $Browser) {return $item.FullName}
  }
 }
 return $null
}
function Install-ScrpBrowser([ValidateSet('Brave','Thorium')][string]$Browser) {
 if ($Browser -eq 'Thorium') {
  if (-not ('ScrpCpuFeatures' -as [type])) {
   Add-Type 'using System.Runtime.InteropServices; public static class ScrpCpuFeatures { [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)] public static extern bool IsProcessorFeaturePresent(uint feature); }'
  }
  if (-not [ScrpCpuFeatures]::IsProcessorFeaturePresent(37) -or -not [ScrpCpuFeatures]::IsProcessorFeaturePresent(38)) {throw 'Thorium requires SSE4.1/4.2. Choose Brave on this processor. Edge is kept.'}
 }
 $existing=Get-ScrpBrowserPath $Browser
 if ($existing) {Write-Host "$Browser already exists: $existing. No downgrade or profile changes.";return $existing}
 $winget=Get-Command winget.exe -ErrorAction SilentlyContinue
 if (-not $winget) {throw 'WinGet is missing. Update App Installer through Microsoft Store and try again. Edge has not been removed.'}
 $id=if ($Browser -eq 'Brave') {'Brave.Brave'} else {'Alex313031.Thorium'}
 # Exact package IDs; use the general Thorium build, never force AVX/AVX2.
 # WinGet verifies the installer against its manifest hash. No ignore-security flags.
 Write-Host "Downloading and installing $Browser through WinGet ($id). Internet is required."
 & $winget.Source install --id $id --exact --source winget --architecture x64 --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity --no-upgrade | ForEach-Object {Write-Host $_}
 $code=$LASTEXITCODE
 if ($code -ne 0) {throw "Installation of $Browser failed (WinGet $code). Edge is kept. Check the installation log."}
 $installed=Get-ScrpBrowserPath $Browser
 if (-not $installed) {throw "$Browser could not be verified after installation. Edge is kept."}
 Write-Host "$Browser verified: $installed. Select your default browser in Windows Settings after installation."
 return $installed
}
