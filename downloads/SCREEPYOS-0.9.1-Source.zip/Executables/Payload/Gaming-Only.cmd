@echo off
start "" "%~dp0SCREEPYOS.exe" Gaming
exit /b
