@echo off
start "" "%~dp0SCREEPYOS.exe" Theme
exit /b
