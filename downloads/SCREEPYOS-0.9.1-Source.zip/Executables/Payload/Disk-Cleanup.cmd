@echo off
start "" "%~dp0SCREEPYOS.exe" Cleanup
exit /b
