﻿#requires -Version 5.1
param([ValidateSet('Home','Competitive','Gaming','Metrics','Cleanup','Theme','Hardware','Drivers','Help','Legacy','Performance')][string]$Page='Home',[string]$ProfileId='',[switch]$AutoStart)
$ErrorActionPreference='Stop'
try {
. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'HomeUI.ps1')
$script:AppRoot=$PSScriptRoot;$script:AppSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$script:Inbox=Join-Path $env:LOCALAPPDATA 'SCREEPYOS\AppRequests'
$script:AppMutex=New-Object Threading.Mutex($false,('Local\SCREEPYOS-App-'+$script:AppSid));$script:AppOwns=$false
try {$script:AppOwns=$script:AppMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$script:AppOwns=$true}
if (-not $script:AppOwns) {
 New-Item -ItemType Directory $script:Inbox -Force|Out-Null
 $request=Join-Path $script:Inbox ([guid]::NewGuid().ToString('N')+'.json')
 @{Page=$Page;ProfileId=$ProfileId;AutoStart=[bool]$AutoStart}|ConvertTo-Json|Set-Content ($request+'.tmp') -Encoding UTF8
 Move-Item ($request+'.tmp') $request
 $script:AppMutex.Dispose();exit 0
}
$global:ScrpBusy=$false
$global:ScrpShell=New-DashForm 'SCREEPYOS 0.9.1 / One App'
$global:ScrpShell.ClientSize=New-Object Drawing.Size(1230,790);$global:ScrpShell.MinimumSize=New-Object Drawing.Size(900,580)
$script:Modules=@{};$script:Panels=@{};$script:NavButtons=@{}
$script:Pages=@{Competitive='Competitive.ps1';Gaming='GamingOnly.ps1';Metrics='Benchmarks.ps1';Cleanup='Cleanup.ps1';Theme='SCREEPYOS.ps1';Hardware='Profiles.ps1';Drivers='Drivers.ps1';Legacy='GameCenter.ps1';Performance='Performance.ps1'}
$layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=2;$layout.RowCount=1
[void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',190)))
[void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
$global:ScrpShell.Controls.Add($layout)
$sidebar=New-Object Windows.Forms.FlowLayoutPanel;$sidebar.Dock='Fill';$sidebar.FlowDirection='TopDown';$sidebar.WrapContents=$false;$sidebar.AutoScroll=$true;$sidebar.Padding=New-Object Windows.Forms.Padding(12,20,10,10);$layout.Controls.Add($sidebar,0,0)
# Render the original wallpaper logo directly, without altering the asset.
$script:BrandArtwork=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'assets\SCRP-OS.png'))
$brand=New-Object Windows.Forms.Panel;$brand.Size=New-Object Drawing.Size(155,162);$brand.BackColor=[Drawing.Color]::Black
$brand.Add_Paint({param($sender,$event)
 $event.Graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
 $event.Graphics.DrawImage($script:BrandArtwork,(New-Object Drawing.Rectangle(4,0,147,137)),620,240,430,400,[Drawing.GraphicsUnit]::Pixel)
})
$edition=New-Object Windows.Forms.Label;$edition.Text='0.9.1 / GAMING PC';$edition.ForeColor=[Drawing.Color]::FromArgb(145,145,145)
$edition.TextAlign='MiddleCenter';$edition.Dock='Bottom';$edition.Height=25;$edition.Font=New-Object Drawing.Font('Segoe UI',8)
$brand.Controls.Add($edition);$sidebar.Controls.Add($brand)
$sidebar.BackColor=[Drawing.Color]::Black
$script:Content=New-Object Windows.Forms.Panel;$script:Content.Dock='Fill';$layout.Controls.Add($script:Content,1,0)
$script:Footer=New-Object Windows.Forms.Label;$script:Footer.Text='Ready';$script:Footer.Dock='Bottom';$script:Footer.Height=27;$global:ScrpShell.Controls.Add($script:Footer)
$script:Navigate={param($target) Show-AppPage $target}
function Show-AppPage($target,$incomingProfile='',$launch=$false) {
 if ($target -notin @('Home','Competitive','Gaming','Metrics','Cleanup','Theme','Hardware','Drivers','Help','Legacy','Performance')) {throw 'Unknown page.'}
 try {
  $newPage=(-not $script:Panels.ContainsKey($target))
  if ($newPage) {
   $panel=New-Object Windows.Forms.Panel;$panel.Dock='Fill';$panel.Visible=$false;$script:Content.Controls.Add($panel)
   if ($target -eq 'Home') {
    New-ScrpHome $panel $script:Navigate
   } elseif ($target -eq 'Help') {
    $helpBox=New-Object Windows.Forms.TextBox;$helpBox.Multiline=$true;$helpBox.ReadOnly=$true;$helpBox.Dock='Fill';$helpBox.ScrollBars='Vertical';$helpBox.BackColor=[Drawing.Color]::FromArgb(20,20,20);$helpBox.ForeColor=[Drawing.Color]::Gainsboro
    $legacyButton=New-Object Windows.Forms.Button;$legacyButton.Text='Legacy 0.7.x profiles / priority recovery';$legacyButton.Dock='Top';$legacyButton.Height=42;$legacyButton.Add_Click({Show-AppPage 'Legacy'});$panel.Controls.Add($legacyButton)
    $helpBox.Text=Get-Content (Join-Path $script:AppRoot 'START-HERE.txt') -Raw;$panel.Controls.Add($helpBox)
   } else {
    $file=Join-Path $script:AppRoot $script:Pages[$target]
    $module=New-Module -Name ('ScrpPage_'+$target) -ArgumentList $file,$panel,$script:Navigate,$incomingProfile,$launch -ScriptBlock {
     param($file,$container,$navigate,$incoming,$launch)
     $script:EmbeddedPanel=$container;$script:Navigate=$navigate;$script:Mounted=$false;$script:PageCleanup={};$script:PageForm=$null;$script:InitError=$null
     . (Join-Path ([IO.Path]::GetDirectoryName($file)) 'PageHost.ps1')
     try {if ([IO.Path]::GetFileName($file) -eq 'Competitive.ps1') {. $file -ProfileId $incoming -AutoStart:$launch} else {. $file}}
     catch {
      $script:InitError=$_.Exception.Message
      foreach ($key in @('mutex','gameMutex','CMutex')) {
       $held=Get-Variable -Name $key -Scope Script -ErrorAction SilentlyContinue
       if ($held -and $held.Value) {try {$held.Value.ReleaseMutex()} catch {};try {$held.Value.Dispose()} catch {}}
      }
     }
    }
    $script:Modules[$target]=$module
    $initError=& $module {$script:InitError};if ($initError) {throw $initError}
    if (-not (& $module {$script:Mounted})) {throw 'Unable to load page.'}
   }
   $script:Panels[$target]=$panel
  } elseif ($target -eq 'Competitive' -and $incomingProfile) {
   & $script:Modules[$target] {param($id,$auto)
    if ($script:CActive) {CLog 'A session is already active. Stop it first.';return}
    Refresh-CList $id;if ($auto) {Start-CMode}
   } $incomingProfile $launch
  }
  foreach ($key in $script:Panels.Keys) {$script:Panels[$key].Visible=($key -eq $target)}
  $script:Panels[$target].BringToFront()
  if ($target -eq 'Home') {Update-ScrpHome}

  if ($newPage -and $target -eq 'Competitive' -and $launch) {& $script:Modules[$target] {Start-CMode}}
  foreach ($key in $script:NavButtons.Keys) {$script:NavButtons[$key].BackColor=if ($key -eq $target) {[Drawing.Color]::FromArgb(65,65,65)} else {[Drawing.Color]::FromArgb(23,23,23)}}
  $script:Footer.Text='SCREEPYOS / '+$target
 } catch {
  $failure=$_.Exception.Message
  if ($newPage) {
   if ($script:Modules.ContainsKey($target)) {Remove-Module $script:Modules[$target] -Force -ErrorAction SilentlyContinue;$script:Modules.Remove($target)}
   if ($panel) {$panel.Dispose()};$script:Panels.Remove($target)
  }
  $script:Footer.Text='Error: '+$failure
  [Windows.Forms.MessageBox]::Show($global:ScrpShell,$failure,'SCREEPYOS')|Out-Null
 }
}
foreach ($row in @(@('Home','Overview'),@('Competitive','Game library'),@('Gaming','Optional cleanup'),@('Metrics','Benchmarks'),@('Performance','Performance Lab'),@('Cleanup','Cleanup'),@('Theme','Theme & recovery'),@('Hardware','Hardware & power'),@('Drivers','Drivers & devices'),@('Help','User guide'))) {
 $button=New-Object Windows.Forms.Button;$button.Text=$row[1];$button.Tag=$row[0];$button.Size=New-Object Drawing.Size(155,45);$button.FlatStyle='Flat';$button.BackColor=[Drawing.Color]::FromArgb(23,23,23)
 $button.Add_Click({param($sender,$event) Show-AppPage ([string]$sender.Tag)})
 $button.UseMnemonic=$false;$button.FlatAppearance.MouseOverBackColor=[Drawing.Color]::FromArgb(38,38,38);$button.FlatAppearance.BorderSize=0;$button.TextAlign='MiddleLeft';$button.Padding=New-Object Windows.Forms.Padding(10,0,0,0)
 $sidebar.Controls.Add($button);$script:NavButtons[$row[0]]=$button
}
$script:RequestTimer=New-Object Windows.Forms.Timer;$script:RequestTimer.Interval=600
$script:RequestTimer.Add_Tick({
 if ($global:ScrpBusy -or -not (Test-Path $script:Inbox)) {return}
 $file=Get-ChildItem $script:Inbox -Filter '*.json'|Sort-Object CreationTime|Select-Object -First 1
 if (-not $file) {return}
 if ($file.CreationTime -lt (Get-Date).AddMinutes(-2)) {Remove-Item $file.FullName;return}
 try {
  $request=Get-Content $file.FullName -Raw|ConvertFrom-Json
  Remove-Item $file.FullName
  if ($request.ProfileId -and $request.ProfileId -notmatch '^[0-9a-f]{32}$') {throw 'Invalid profile ID.'}
  Show-AppPage $request.Page $request.ProfileId ([bool]$request.AutoStart)
  $global:ScrpShell.WindowState='Normal';$global:ScrpShell.Activate()
 } catch {$script:Footer.Text='Shortcut: '+$_.Exception.Message;if (Test-Path $file.FullName) {Remove-Item $file.FullName}}
})
$global:ScrpShell.Add_Shown({Show-AppPage $Page $ProfileId ([bool]$AutoStart);$script:RequestTimer.Start()})
$global:ScrpShell.Add_FormClosing({param($sender,$event)
 if ($global:ScrpBusy) {$event.Cancel=$true;return}
 if (Test-Path (Join-Path $env:LOCALAPPDATA 'SCREEPYOS\power-profile-backup.json')) {
  if ([Windows.Forms.MessageBox]::Show('Hardware & power has a pending power plan backup. Close without restoring it now?','SCREEPYOS','YesNo','Question') -ne 'Yes') {$event.Cancel=$true;return}
 }
 $script:RequestTimer.Stop()
 foreach ($module in $script:Modules.Values) {
  try {& $module {if ($script:PageForm) {$script:PageForm.Close()}; & $script:PageCleanup;if ($script:PageForm) {$script:PageForm.Dispose()}}} catch {$script:Footer.Text=$_.Exception.Message}
 }
 if (Test-Path (Join-Path $env:LOCALAPPDATA 'SCREEPYOS\competitive-session.json')) {[Windows.Forms.MessageBox]::Show('Session recovery is incomplete. Open Competitive Mode again and select Recover previous session.','SCREEPYOS')|Out-Null}
})
try {[void]$global:ScrpShell.ShowDialog()} finally {
 $script:RequestTimer.Dispose();$global:ScrpShell.Dispose();$script:BrandArtwork.Dispose();if ($script:HomeArtwork) {$script:HomeArtwork.Dispose()}
 foreach ($module in $script:Modules.Values) {Remove-Module $module -Force -ErrorAction SilentlyContinue}
 if ($script:AppOwns) {$script:AppMutex.ReleaseMutex()};$script:AppMutex.Dispose()
}

} catch {
 $message=$_.Exception.Message
 $folder=Join-Path $env:LOCALAPPDATA 'SCREEPYOS\Logs'
 New-Item -ItemType Directory $folder -Force -ErrorAction SilentlyContinue|Out-Null
 ($_.Exception.ToString()+"`r`n"+$_.ScriptStackTrace)|Set-Content (Join-Path $folder 'App-startup.log') -Encoding UTF8 -ErrorAction SilentlyContinue
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show($message+"`r`nLog: "+(Join-Path $folder 'App-startup.log'),'SCREEPYOS could not start')|Out-Null
}
