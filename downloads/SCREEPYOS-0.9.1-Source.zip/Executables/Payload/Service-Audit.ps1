﻿#requires -Version 5.1
# Read-only service inventory. Only writes report files; never changes services.
param([switch]$NoOpen)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
try {
    $keep = @(Get-Content (Join-Path $PSScriptRoot 'services-keep.txt') | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') } | Select-Object -Unique)
    $os = Get-CimInstance Win32_OperatingSystem
    $services = @(Get-CimInstance Win32_Service | Sort-Object Name)
    $drivers = @(Get-CimInstance Win32_SystemDriver | Sort-Object Name)
    $all = @($services) + @($drivers)
    $nodes = @{}; $issues = New-Object 'System.Collections.Generic.List[string]'
    foreach ($s in $all) {
        $driver = $s.CimClass.CimClassName -eq 'Win32_SystemDriver'
        $required = @(); $groups = @(); $delayed = $null; $type = $null; $dependencyRead = $false
        try {
            $key = Get-Item -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\' + $s.Name)
            $required = @($key.GetValue('DependOnService', @()) | Where-Object { $_ })
            $groups = @($key.GetValue('DependOnGroup', @()) | Where-Object { $_ })
            $delayed = $key.GetValue('DelayedAutoStart', 0)
            $type = [int]$key.GetValue('Type', 0)
            $dependencyRead = $true
        } catch { $issues.Add("Unable to read dependencies: $($s.Name)") }
        $nodes[$s.Name] = [pscustomobject]@{
            Name=$s.Name; DisplayName=$s.DisplayName; State=$s.State; StartMode=$s.StartMode;
            DelayedAutoStart=$delayed; IsDriver=$driver; ServiceType=$type;
            PerUser=($null -ne $type -and (($type -band 64) -ne 0));
            RequiredServices=$required; RequiredGroups=$groups; DependenciesRead=$dependencyRead;
            InRequestedList=($keep -contains $s.Name); Classification=''; RequiredBy=@()
        }
    }
    # Walk transitive named dependencies from the user's list. Drivers are inventory only.
    $needed = @{}; $parents = @{}; $queue = New-Object 'System.Collections.Generic.Queue[string]'
    foreach ($n in $keep) { $queue.Enqueue($n) }
    while ($queue.Count -gt 0) {
        $n = $queue.Dequeue()
        if ($needed.ContainsKey($n)) { continue }
        $needed[$n] = $true
        if (-not $nodes.ContainsKey($n)) { continue }
        foreach ($dep in $nodes[$n].RequiredServices) {
            if (-not $parents.ContainsKey($dep)) { $parents[$dep] = @() }
            $parents[$dep] += $n
            if (-not $needed.ContainsKey($dep)) { $queue.Enqueue($dep) }
        }
        if ($nodes[$n].RequiredGroups.Count -gt 0) {
            $issues.Add("Group dependencies need additional review: $n")
        }
    }
    foreach ($n in $nodes.Keys) {
        $row = $nodes[$n]
        if ($parents.ContainsKey($n)) { $row.RequiredBy = @($parents[$n] | Select-Object -Unique) }
        if ($row.IsDriver) { $row.Classification='DRIVER_NOT_A_DISABLE_TARGET' }
        elseif ($row.InRequestedList) { $row.Classification='KEEP_REQUESTED' }
        elseif ($needed.ContainsKey($n)) { $row.Classification='DEPENDENCY_OUTSIDE_LIST' }
        elseif (-not $row.DependenciesRead) { $row.Classification='UNKNOWN_ACCESS_ERROR' }
        elseif ($row.PerUser) { $row.Classification='REVIEW_PER_USER_SERVICE' }
        elseif ($row.StartMode -eq 'Disabled') { $row.Classification='ALREADY_DISABLED' }
        else { $row.Classification='REVIEW_OUTSIDE_LIST' }
    }
    $missing = @($keep | Where-Object { -not $nodes.ContainsKey($_) })
    $unresolved = @($needed.Keys | Where-Object { -not $nodes.ContainsKey($_) -and $keep -notcontains $_ })
    $disabledKeep = @($services | Where-Object { $keep -contains $_.Name -and $_.StartMode -eq 'Disabled' } | ForEach-Object { $_.Name })
    $rows = @($nodes.Values | Sort-Object Name)
    $report = [pscustomobject]@{
        SchemaVersion=1; CreatedUtc=[datetime]::UtcNow.ToString('o'); WindowsVersion=$os.Version; WindowsBuild=$os.BuildNumber;
        ReadOnly=$true; AppliedChanges=0; RequestedKeepList=$keep; MissingRequested=$missing;
        DisabledRequested=$disabledKeep; UnresolvedRequired=$unresolved; Warnings=@($issues.ToArray()); Services=$rows;
        Limitation='Named SCM dependencies only. Application, anti-cheat, hardware, per-user templates and service-group requirements need separate review. Outside the list does not mean safe to disable.'
    }
    $out = Join-Path $env:LOCALAPPDATA ('SCREEPYOS\Reports\' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    New-Item -ItemType Directory -Path $out -Force | Out-Null
    $json = Join-Path $out 'SCREEPYOS-services.json'
    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $json -Encoding UTF8
    $outside = @($rows | Where-Object { $_.Classification -eq 'DEPENDENCY_OUTSIDE_LIST' })
    $review = @($rows | Where-Object { $_.Classification -like 'REVIEW*' })
    $text = @('SCREEPYOS - SERVICE AUDIT', '', 'No changes were made.',
        "Windows build: $($os.BuildNumber)", "Your keep-list: $($keep.Count) services", "Services found: $($services.Count)",
        "Direct/indirect dependencies outside your list: $($outside.Count)", "Other services to review: $($review.Count)",
        '', 'DEPENDENCIES OUTSIDE YOUR LIST:')
    foreach ($r in $outside) { $text += "$($r.Name) - required by: $($r.RequiredBy -join ', ')" }
    $text += @('', 'REQUESTED BUT NOT FOUND (services differ between builds):', ($missing -join ', '),
        '', 'REQUESTED BUT CURRENTLY DISABLED:', ($disabledKeep -join ', '),
        '', 'OTHER SERVICES: review manually; do not automatically disable.')
    foreach ($r in $review) { $text += "$($r.Name) | $($r.DisplayName) | $($r.StartMode) | $($r.State)" }
    $text += @('', 'NOTES:', ($issues -join "`r`n"), '',
        'Services without registered dependencies may still be used by games, drivers and Windows.',
        'Manual/trigger-start does not mean continuously running. The keep-list is not all set to Automatic.',
        'Drivers are marked separately and never changed by this audit.',
        'The report contains service names and the Windows build, not usernames, computer names, IP addresses, tokens or executable paths.',
        'Share SCREEPYOS-services.json for help reviewing the service configuration on your PC.')
    $text | Set-Content -LiteralPath (Join-Path $out 'READ-SERVICE-AUDIT.txt') -Encoding UTF8
    Write-Host "Done. No changes were made. Share this file:`n$json" -ForegroundColor Green
    if (-not $NoOpen) { Start-Process explorer.exe -ArgumentList ('"'+$out+'"') }
} catch {
    Write-Host "Audit failed: $($_.Exception.Message)" -ForegroundColor Red
    throw
}
