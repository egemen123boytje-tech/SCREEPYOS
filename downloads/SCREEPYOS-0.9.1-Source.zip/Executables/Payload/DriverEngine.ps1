﻿function Get-ScrpVendor([string]$pnp,[string]$name) {
 if ($pnp -match 'VEN_10DE') {return 'NVIDIA'}
 if ($pnp -match 'VEN_1002') {return 'AMD'}
 if ($pnp -match 'VEN_8086') {return 'Intel'}
 if ($name -match 'VMware|VirtualBox|Hyper-V|Virtual Display|VirtIO') {return 'Virtual'}
 return 'Unknown'
}
function Get-ScrpDriverInventory {
 $system=Get-CimInstance Win32_ComputerSystem
 $cpu=@(Get-CimInstance Win32_Processor|ForEach-Object {$_.Name}) -join '; '
 $board=Get-CimInstance Win32_BaseBoard|Select-Object -First 1
 $drivers=@(Get-CimInstance Win32_PnPSignedDriver -Filter "DeviceClass='DISPLAY'")
 $rows=@()
 foreach ($gpu in @(Get-CimInstance Win32_VideoController)) {
  $driver=$drivers|Where-Object {$_.DeviceID -eq $gpu.PNPDeviceID}|Select-Object -First 1
  $version=[string]$gpu.DriverVersion;$provider='Unknown';$date='Unknown'
  if ($driver) {$version=[string]$driver.DriverVersion;$provider=[string]$driver.DriverProviderName;if ($driver.DriverDate) {$date=([datetime]$driver.DriverDate).ToString('yyyy-MM-dd')}}
  $rows += [pscustomobject]@{Vendor=(Get-ScrpVendor $gpu.PNPDeviceID $gpu.Name);Model=$gpu.Name;Version=$version;Provider=$provider;Date=$date;Status=$gpu.Status;PNP=$gpu.PNPDeviceID}
 }
 [pscustomobject]@{Manufacturer=$system.Manufacturer;Model=$system.Model;CPU=$cpu;Board=$(if ($board) {$board.Manufacturer+' '+$board.Product} else {'Unknown'});Virtual=([string]$system.Model -match 'Virtual|VMware|KVM|QEMU');Adapters=$rows}
}
