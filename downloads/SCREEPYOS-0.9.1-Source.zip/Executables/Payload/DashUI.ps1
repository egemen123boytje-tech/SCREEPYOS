﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$dashIdentity=[Security.Principal.WindowsIdentity]::GetCurrent()
$dashPrincipal=New-Object Security.Principal.WindowsPrincipal($dashIdentity)
if ($dashIdentity.IsSystem -or $dashPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
 [Windows.Forms.MessageBox]::Show('Start the dashboard as the signed-in standard user. Only explicit system actions request UAC.','SCREEPYOS')|Out-Null
 throw 'The dashboard must start without elevation.'
}
[Windows.Forms.Application]::EnableVisualStyles()
function New-DashForm($title) {
 $f=New-Object Windows.Forms.Form;$f.Text=$title;$f.ClientSize=New-Object Drawing.Size(1020,720)
 $f.MinimumSize=New-Object Drawing.Size(730,520);$f.StartPosition='CenterScreen';$f.AutoScaleMode='Dpi'
 $f.Font=New-Object Drawing.Font('Segoe UI',10);$f.BackColor=[Drawing.Color]::FromArgb(10,10,10);$f.ForeColor=[Drawing.Color]::Gainsboro
 return $f
}
function New-DashCanvas($form,$height=820) {
 $p=New-Object Windows.Forms.Panel;$p.Dock='Fill';$p.AutoScroll=$true;$p.AutoScrollMinSize=New-Object Drawing.Size(960,$height);$form.Controls.Add($p);return $p
}
function Add-DashLabel($panel,$text,$x,$y,$width,$height,$size=10) {
 $c=New-Object Windows.Forms.Label;$c.Text=$text;$c.SetBounds($x,$y,$width,$height);$c.Font=New-Object Drawing.Font('Segoe UI',$size);$panel.Controls.Add($c);return $c
}
function Add-DashButton($panel,$text,$x,$y,$width,$action) {
 $b=New-Object Windows.Forms.Button;$b.Text=$text;$b.SetBounds($x,$y,$width,38);$b.FlatStyle='Flat';$b.BackColor=[Drawing.Color]::FromArgb(28,28,28);$b.Add_Click($action);$panel.Controls.Add($b);return $b
}
function Add-DashCheck($panel,$text,$x,$y,$width,$checked,$tip,$tipText) {
 $c=New-Object Windows.Forms.CheckBox;$c.Text=$text;$c.SetBounds($x,$y,$width,32);$c.Checked=$checked;$panel.Controls.Add($c);$tip.SetToolTip($c,$tipText);return $c
}
