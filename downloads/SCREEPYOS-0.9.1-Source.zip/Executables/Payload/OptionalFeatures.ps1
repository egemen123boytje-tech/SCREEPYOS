﻿# Fixed wizard choices. Unchecked means leave the existing configuration unchanged.
function Get-ScrpOptionalChoices {
    @{
        OptionalPrinter=@('Spooler')
        OptionalBluetooth=@('Bluetooth')
        OptionalSearch=@('WSearch')
        OptionalFax=@('Fax')
        OptionalMaps=@('MapsBroker')
        OptionalMedia=@('WMPNetworkSvc')
        OptionalBackground=@('OneDrive','Widgets','DeliveryPeers','RetailDemo','RemoteRegistry','DiagTrack')
    }
}
function Resolve-ScrpOptionalChoices($Choices) {
    $map=Get-ScrpOptionalChoices
    foreach ($choice in @($Choices)) {
        if (-not $map.ContainsKey([string]$choice)) {throw "Unknown wizard feature: $choice"}
        foreach ($feature in $map[[string]$choice]) { $feature }
    }
}

# Queue files are installation state, never executable instructions.
function Read-ScrpWizardChoices([string]$Path) {
    if (-not [IO.File]::Exists($Path)) { return }
    try {
        $raw=[IO.File]::ReadAllText($Path)
        if ([string]::IsNullOrWhiteSpace($raw) -or $raw.IndexOf([char]0) -ge 0 -or -not $raw.TrimStart().StartsWith('[')) {
            throw 'Expected a JSON array without NUL bytes.'
        }
        # Windows PowerShell 5.1 emits a JSON array as one pipeline object.
        # Assign first, then enumerate the value; do not wrap the command in @().
        $parsed=ConvertFrom-Json -InputObject $raw -ErrorAction Stop
        $items=@()
        if ($null -ne $parsed) { $items=@($parsed) }
        elseif ($raw -notmatch '^\s*\[\s*\]\s*$') {throw 'Null choices are not allowed.'}
        foreach ($item in $items) {
            if ($item -isnot [string]) {throw 'Every choice must be a string.'}
            Resolve-ScrpOptionalChoices @($item) | Out-Null
        }
        $items | Select-Object -Unique
    } catch {
        throw "Saved wizard choices are damaged or invalid: $Path. No optional features were applied by this step. Preserve this file for diagnosis, then start a fresh playbook run from Setup (do not resume). Details: $($_.Exception.Message)"
    }
}
function Add-ScrpWizardChoice([string]$Path,[string]$Choice) {
    Resolve-ScrpOptionalChoices @($Choice) | Out-Null
    $items=@(@(Read-ScrpWizardChoices -Path $Path)+$Choice | Select-Object -Unique)
    $json=ConvertTo-Json -InputObject $items -Compress
    $temporary=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        $encoding=New-Object Text.UTF8Encoding($false)
        $bytes=$encoding.GetBytes($json)
        $stream=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        $verified=@(Read-ScrpWizardChoices -Path $temporary)
        if (($verified -join ',') -cne ($items -join ',')) {throw 'Wizard choice write verification failed.'}
        # Same-directory replacement avoids truncating the existing queue in-place.
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temporary,$Path,($Path+'.previous')) }
        else { [IO.File]::Move($temporary,$Path) }
    } finally {
        if ([IO.File]::Exists($temporary)) {[IO.File]::Delete($temporary)}
    }
}
