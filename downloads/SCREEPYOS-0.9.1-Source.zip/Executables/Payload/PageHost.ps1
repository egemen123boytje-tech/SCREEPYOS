﻿# Dot-sourced in an isolated in-process module for each page.
function Mount-ScrpPage($form,$cleanup) {
 $script:PageForm=$form;$script:PageCleanup=$cleanup
 $form.TopLevel=$false;$form.FormBorderStyle='None';$form.MinimumSize=[Drawing.Size]::Empty;$form.Dock='Fill'
 $script:EmbeddedPanel.Controls.Add($form)
 . (Join-Path $PSScriptRoot 'VisualTheme.ps1')
 Set-ScrpTheme $form
 $form.Show();$script:Mounted=$true
}
function Invoke-ScrpMachine($mode,$names,$logCallback) {
 $names=@($names|Where-Object {$_})
 if ($global:ScrpBusy) {throw 'A system action is already running.'}
 if (Test-Path (Join-Path $env:LOCALAPPDATA 'SCREEPYOS\competitive-session.json')) {throw 'Stop and restore Competitive Mode before running system actions.'}
 $allowed=@('Apply','Restore','Office','Edge');if ($mode -notin $allowed) {throw 'Unknown system action.'}
 foreach ($name in $names) {if ($name -notmatch '^[A-Za-z]+$') {throw 'Invalid system option.'}}
 $start=Get-Date
 $global:ScrpBusy=$true;$global:ScrpShell.Enabled=$false
 try {
  & $logCallback ('System action '+$mode+' started. Confirm the UAC prompt if requested.')
  $exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $arguments='-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'Gaming-Machine.ps1')+'" -Mode '+$mode+' -ExpectedSid '+$sid+' -NoPrompt'
  if ($names.Count) {$arguments+=' -Features '+($names -join ',')}
  $proc=Start-Process $exe -Verb RunAs -WindowStyle Hidden -ArgumentList $arguments -PassThru
  while (-not $proc.HasExited) {[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 100;$proc.Refresh()}
  $proc.Refresh();$code=$proc.ExitCode
  $root=Join-Path $env:ProgramData 'SCREEPYOS-Machine'
  $logs=@(Get-ChildItem $root -Filter '*.log' -ErrorAction SilentlyContinue|Where-Object {$_.LastWriteTime -ge $start.AddSeconds(-2)}|Sort-Object LastWriteTime -Descending)
  if ($logs.Count) {
   foreach ($line in Get-Content -LiteralPath $logs[0].FullName -Tail 100 -ErrorAction SilentlyContinue) {& $logCallback $line}
  }
  if (-not $logs.Count) {& $logCallback 'No readable system log available. Use the same Windows account for UAC.'}
  & $logCallback ('System action '+$mode+' finished. Exit code: '+$code)
  if ($code -ne 0) {throw 'System action did not fully succeed. Check the message above and the system logs.'}
 } finally {$global:ScrpShell.Enabled=$true;$global:ScrpBusy=$false}
}
