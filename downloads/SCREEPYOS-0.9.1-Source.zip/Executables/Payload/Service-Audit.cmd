@echo off
start "" "%~dp0SCREEPYOS.exe" Drivers
exit /b
