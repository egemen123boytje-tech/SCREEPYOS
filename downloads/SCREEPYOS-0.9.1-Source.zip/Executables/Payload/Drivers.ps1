﻿. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'DriverEngine.ps1')
$form=New-DashForm 'Drivers & devices';$canvas=New-DashCanvas $form 1060
$null=Add-DashLabel $canvas 'DRIVERS & DEVICES' 24 22 890 48 23
$script:DriverSummary=Add-DashLabel $canvas 'Click Refresh to read your hardware and installed drivers.' 26 86 870 110
$script:DriverGrid=New-Object Windows.Forms.DataGridView;$script:DriverGrid.SetBounds(26,210,885,220);$script:DriverGrid.ReadOnly=$true;$script:DriverGrid.AllowUserToAddRows=$false;$script:DriverGrid.AllowUserToDeleteRows=$false;$script:DriverGrid.AutoSizeColumnsMode='Fill';$script:DriverGrid.BackgroundColor=[Drawing.Color]::FromArgb(30,30,34);$script:DriverGrid.DefaultCellStyle.ForeColor=[Drawing.Color]::Black;$canvas.Controls.Add($script:DriverGrid)
foreach ($col in @('Vendor','Model','Version','Provider','Date','Status')) {[void]$script:DriverGrid.Columns.Add($col,$col)}
$null=Add-DashButton $canvas 'Refresh' 26 448 210 {Refresh-DriverPage}
$null=Add-DashButton $canvas 'NVIDIA Game Ready' 251 448 210 {Start-Process 'https://www.nvidia.com/en-eu/geforce/drivers/'}
$null=Add-DashButton $canvas 'AMD drivers / chipset' 476 448 210 {Start-Process 'https://www.amd.com/en/support/download/drivers.html'}
$null=Add-DashButton $canvas 'Intel Driver Assistant' 701 448 210 {Start-Process 'https://www.intel.com/content/www/us/en/support/detect.html'}
$null=Add-DashLabel $canvas 'Use the link for your actual hardware. An Intel CPU does not imply an Intel GPU. On laptops, check model-specific OEM drivers first. This page does not check for the latest available version.' 26 506 885 70
$null=Add-DashLabel $canvas 'For chipset, network and audio drivers, use your laptop or motherboard support page. SCREEPYOS does not run generic driver updaters, DDU, BIOS updates or hidden driver tweaks.' 26 586 885 58
$null=Add-DashButton $canvas 'Bluetooth in Windows' 26 665 280 {Start-Process 'ms-settings:bluetooth'}
$null=Add-DashButton $canvas 'GPU / VRR / HAGS in Windows' 326 665 280 {Start-Process 'ms-settings:display-advancedgraphics'}
$null=Add-DashButton $canvas 'Device Manager' 626 665 285 {Start-Process devmgmt.msc}
$script:DeviceLog=New-Object Windows.Forms.TextBox;$script:DeviceLog.SetBounds(26,770,885,250);$script:DeviceLog.Multiline=$true;$script:DeviceLog.ReadOnly=$true;$script:DeviceLog.ScrollBars='Both';$canvas.Controls.Add($script:DeviceLog)
$null=Add-DashButton $canvas 'Read NIC / USB status' 26 718 280 {
 try {
  $lines=@('DIAGNOSTICS ONLY: no changes made.')
  $lines+=Get-NetAdapter|Format-Table -Property @('Name','InterfaceDescription','Status','LinkSpeed')|Out-String
  foreach ($nic in @(Get-NetAdapter)) {try {$lines+=(Get-NetAdapterPowerManagement -Name $nic.Name|Format-List *|Out-String)} catch {$lines+=($nic.Name+': not supported')}}
  $lines+=Get-CimInstance Win32_USBHub|Format-Table -Property @('Name','Status')|Out-String
  $script:DeviceLog.Text=$lines -join "`r`n"
 } catch {$script:DeviceLog.Text=$_.Exception.Message}
}
$null=Add-DashButton $canvas 'Uninstall Edge browser' 326 718 280 {
 if ([Windows.Forms.MessageBox]::Show('Install another browser first and export any Edge data you want to keep. The Microsoft uninstaller may open its own window. WebView2 is kept. Continue?','SCREEPYOS','YesNo','Warning') -ne 'Yes') {return}
 try {Invoke-ScrpMachine 'Edge' @() {param($m) $script:DeviceLog.AppendText($m+"`r`n")}} catch {$script:DeviceLog.AppendText($_.Exception.Message+"`r`n")}
}
$null=Add-DashButton $canvas 'Service audit (read-only)' 626 718 285 {
 try {$script:DeviceLog.Text=(& (Join-Path $PSScriptRoot 'Service-Audit.ps1') -NoOpen 6>&1 | Out-String)} catch {$script:DeviceLog.Text=$_.Exception.Message}
}
function Refresh-DriverPage {
 try {
  $data=Get-ScrpDriverInventory
  $script:DriverSummary.Text="PC: $($data.Manufacturer) $($data.Model)`r`nCPU: $($data.CPU)`r`nMotherboard: $($data.Board)"+$(if ($data.Virtual) {"`r`nVM: the reported hardware may be virtual, not your physical GPU."} else {''})
  $script:DriverGrid.Rows.Clear()
  foreach ($row in $data.Adapters) {[void]$script:DriverGrid.Rows.Add([object[]]@($row.Vendor,$row.Model,$row.Version,$row.Provider,$row.Date,$row.Status))}
 } catch {$script:DriverSummary.Text='Unable to read hardware: '+$_.Exception.Message}
}
Mount-ScrpPage $form {}
