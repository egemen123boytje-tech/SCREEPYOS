﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$Request)
$ErrorActionPreference='Stop'
try {
 $cfg=Get-Content -LiteralPath $Request -Raw|ConvertFrom-Json
 $end=(Get-Date).AddSeconds([math]::Min(600,[math]::Max(15,[int]$cfg.Seconds)))
 $previousCpu=$null;$previousTime=$null
 while ((Get-Date) -lt $end -and -not (Test-Path -LiteralPath $cfg.StopFile)) {
  $hostProc=Get-Process -Id $cfg.HostId -ErrorAction SilentlyContinue
  if (-not $hostProc -or $hostProc.StartTime.ToUniversalTime().Ticks.ToString() -ne $cfg.HostStamp) {break}
  $game=Get-Process -Id $cfg.GameId -ErrorAction SilentlyContinue
  if (-not $game -or $game.StartTime.ToUniversalTime().Ticks.ToString() -ne $cfg.GameStamp -or $game.Path -ne $cfg.GamePath) {break}
  $now=Get-Date;$cpu=$null;$cpuMs=$game.TotalProcessorTime.TotalMilliseconds
  if ($null -ne $previousCpu) {$cpu=[math]::Round([math]::Max(0,100*($cpuMs-$previousCpu)/($now-$previousTime).TotalMilliseconds/[Environment]::ProcessorCount),2)}
  $previousCpu=$cpuMs;$previousTime=$now;$gpu=$null;$temps=''
  if ($cfg.GpuCounters) {
   try {
    $engines=@(Get-CimInstance -ClassName Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -Filter ("Name LIKE 'pid_"+$cfg.GameId+"[_]%' ") -OperationTimeoutSec 2 -ErrorAction Stop)
    if ($engines.Count) {$gpu=($engines|Measure-Object UtilizationPercentage -Maximum).Maximum}
   } catch {}
  }
  if ($cfg.Temperatures) {
   try {
    $sensors=@(Get-CimInstance -Namespace root/LibreHardwareMonitor -ClassName Sensor -Filter "SensorType='Temperature'" -OperationTimeoutSec 2 -ErrorAction Stop)
    $temps=($sensors|ForEach-Object {$_.Identifier+'='+[string]$_.Value}) -join ';'
   } catch {}
  }
  [pscustomobject]@{Time=$now.ToString('o');ProcessID=$cfg.GameId;CpuPercentAllLogicalCores=$cpu;WorkingSetMB=[math]::Round($game.WorkingSet64/1MB,1);BusiestGameGpuEnginePercent=$gpu;TemperatureSensorsC=$temps}|Export-Csv -LiteralPath $cfg.Output -NoTypeInformation -Append -Encoding UTF8
  Start-Sleep -Seconds 2
 }
} catch {$_|Out-String|Set-Content -LiteralPath ($Request+'.error.txt') -Encoding UTF8;exit 1}
