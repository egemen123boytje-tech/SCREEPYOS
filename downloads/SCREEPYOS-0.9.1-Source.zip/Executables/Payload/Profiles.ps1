﻿#requires -Version 5.1
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$owns=$false; $mutex=$null; $form=$null
try {
    $os=Get-CimInstance Win32_OperatingSystem
    if ($os.ProductType -ne 1 -or [int]$os.BuildNumber -notin @(22631,26100,26200,26300)) {throw 'This version supports Windows 11 builds 22631, 26100, 26200 and 26300 (26H2; experimental).'}
    if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64') {throw 'This build is for Windows x64 on Intel/AMD. ARM64 has not been validated.'}
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    $principal=New-Object Security.Principal.WindowsPrincipal($who)
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {throw 'Start normally, without administrator privileges. Windows will request permission when needed.'}
    . (Join-Path $PSScriptRoot 'ProfilesEngine.ps1')
    $mutex=New-Object Threading.Mutex($false,('Local\SCREEPYOS-Profiles-'+$script:Sid))
    try {$owns=$mutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$owns=$true}
    if (-not $owns) {throw 'Hardware profiles is already open.'}
    $presets=@(Get-Content (Join-Path $PSScriptRoot 'hardware-profiles.json') -Raw | ConvertFrom-Json)
    $form=New-Object Windows.Forms.Form
    $form.Text='SCREEPYOS 0.9.1 | Hardware profiles'
    $form.Size=New-Object Drawing.Size(940,820);$form.MinimumSize=New-Object Drawing.Size(820,600)
    $form.StartPosition='CenterScreen';$form.AutoScaleMode='Dpi'
    $form.BackColor=[Drawing.Color]::FromArgb(18,18,20);$form.ForeColor=[Drawing.Color]::Gainsboro
    $form.Font=New-Object Drawing.Font('Segoe UI',10)
    $flow=New-Object Windows.Forms.FlowLayoutPanel
    $flow.Dock='Fill';$flow.AutoScroll=$true;$flow.FlowDirection='TopDown';$flow.WrapContents=$false
    $form.Controls.Add($flow)
    function Text($value,$height=45) {
        $c=New-Object Windows.Forms.Label;$c.Text=$value;$c.Size=New-Object Drawing.Size(780,$height)
        $c.Margin=New-Object Windows.Forms.Padding(15,10,8,0);$flow.Controls.Add($c);return $c
    }
    function Choice($items) {
        $c=New-Object Windows.Forms.ComboBox;$c.DropDownStyle='DropDownList'
        $c.Size=New-Object Drawing.Size(760,32);$c.Margin=New-Object Windows.Forms.Padding(15,5,8,0)
        $c.Items.AddRange([object[]]$items);if ($c.Items.Count -gt 0) {$c.SelectedIndex=0};$flow.Controls.Add($c);return $c
    }
    function Check($value,$checked=$true) {
        $c=New-Object Windows.Forms.CheckBox;$c.Text=$value;$c.Checked=$checked
        $c.Size=New-Object Drawing.Size(780,30);$c.Margin=New-Object Windows.Forms.Padding(15,5,8,0)
        $flow.Controls.Add($c);return $c
    }
    function Button($value,$action) {
        $c=New-Object Windows.Forms.Button;$c.Text=$value;$c.Size=New-Object Drawing.Size(760,35)
        $c.FlatStyle='Flat';$c.BackColor=[Drawing.Color]::FromArgb(42,42,46)
        $c.Margin=New-Object Windows.Forms.Padding(15,5,8,0);$c.Add_Click($action);$flow.Controls.Add($c)
    }
    function Tell($value) {[Windows.Forms.MessageBox]::Show($form,[string]$value,'SCREEPYOS') | Out-Null}
    function Open-Setting($uri) {try {Start-Process $uri} catch {Tell ('Windows page unavailable: '+$_.Exception.Message)}}
    $null=Text 'DESKTOP VISUALS / SEPARATE FROM GAME PERFORMANCE' 30
    $null=Text 'Choose desktop animations. These presets are not FPS boosts. No overclocking, driver changes or guaranteed FPS gains.'
    $hardware=Text 'Reading hardware...' 180
    function Refresh-Hardware {
        $h=Get-ScrpHardware
        $hardware.Text="CPU: $($h.CPU)`r`nGPU: $($h.GPU)`r`nRAM: $($h.RAM) | Windows: $($h.Build) | $($h.Architecture)`r`nSystem: $($h.System)`r`nMemory integrity: $($h.HVCI) | VBS: $($h.VBS)`r`nPower plan GUID: $($h.Power)"
    }
    Button 'Refresh hardware / security status' {Refresh-Hardware}
    $tier=Choice @($presets | ForEach-Object {$_.Name})
    $tier.SelectedIndex=1
    $description=Text $presets[1].Description 55
    $null=Text 'Window and taskbar animations (customizable):' 25
    $visual=Choice @('Minimal','Reduced','Full');$visual.SelectedItem='Reduced'
    $tier.Add_SelectedIndexChanged({$description.Text=$presets[$tier.SelectedIndex].Description;$visual.SelectedItem=$presets[$tier.SelectedIndex].Visual})
    $theme=Check 'Black and gray theme + SCRP OS wallpaper'
    $game=Check 'Enable Game Mode'
    $quiet=Check 'Reduce suggestions and ads'
    $null=Text 'Unchecked settings are left unchanged. This profile removes no apps. Xbox, game recording, drivers, services and security are kept.' 45
    Button 'Apply this profile (with settings backup)' {
        try {
            $opts=[pscustomobject]@{Theme=$theme.Checked;GameMode=$game.Checked;Quiet=$quiet.Checked;Capture=$false;Animations=$false;ProfileVisual=[string]$visual.SelectedItem}
            $preview=@(Get-Tweaks $opts | ForEach-Object {"$($_.Name) = $($_.Value)"}) -join "`r`n"
            if ([Windows.Forms.MessageBox]::Show($form,"$($tier.SelectedItem):`r`n$preview`r`n`r`nApply?",'Profile','YesNo','Question') -ne 'Yes') {return}
            $script:ProfileMessages=New-Object 'System.Collections.Generic.List[string]'
            $result=Invoke-ScrpApply $opts @() (Join-Path $PSScriptRoot 'assets\SCRP-OS.png') {param($m) $script:ProfileMessages.Add([string]$m)}
            Tell (($script:ProfileMessages -join "`r`n")+"`r`nErrors: $($result.Failures). GPU settings and the power plan are unchanged.")
        } catch {Tell $_.Exception.Message}
    }
    Button 'Restore latest settings step (including dashboard / AME steps)' {
        try {
            $backup=Get-LatestBackup
            if ($null -eq $backup) {throw 'No active settings backup.'}
            if ([Windows.Forms.MessageBox]::Show($form,"Restore $($backup.Name)? This is the latest settings step, not necessarily only this profile. Removed apps are not restored.",'Restore','YesNo','Question') -ne 'Yes') {return}
            $script:ProfileMessages=New-Object 'System.Collections.Generic.List[string]'
            $null=Invoke-ScrpRestore {param($m) $script:ProfileMessages.Add([string]$m)}
            Tell ($script:ProfileMessages -join "`r`n")
        } catch {Tell $_.Exception.Message}
    }
    $null=Text 'POWER / optional per-PC experiment' 30
    $null=Text 'Only existing Windows power plans. Higher performance may increase heat and power use. Test on AC power and restore after gaming. Closing does not automatically restore the plan.' 50
    $script:Plans=@();$plans=Choice @()
    function Refresh-Plans {
        $plans.Items.Clear();$script:Plans=@()
        try {$script:Plans=@(Get-ScrpPowerPlans);foreach ($p in $script:Plans) {$null=$plans.Items.Add($p.Label+' ['+$p.Id+']')};if ($plans.Items.Count -gt 0) {$plans.SelectedIndex=0}} catch {Tell $_.Exception.Message}
    }
    Button 'Refresh available power plans' {Refresh-Plans}
    Button 'Test selected power plan' {
        try {
            if ($plans.SelectedIndex -lt 0) {throw 'No available power plan selected. Use Windows power settings.'}
            if ([Windows.Forms.SystemInformation]::PowerStatus.PowerLineStatus -eq 'Offline') {throw 'Connect AC power before this power plan test.'}
            Tell (Set-ScrpPower $script:Plans[$plans.SelectedIndex].Id);Refresh-Hardware
        } catch {Tell $_.Exception.Message}
    }
    Button 'Restore power plan' {try {Tell (Restore-ScrpPower);Refresh-Hardware} catch {Tell $_.Exception.Message}}
    Button 'Windows power settings / Best performance if available' {Open-Setting 'ms-settings:powersleep'}
    $null=Text 'GPU AND WINDOWS / adjust options on the Windows page that opens' 30
    $null=Text 'Windows shows what your GPU and driver support. Missing options are not forced using registry tricks. These manual changes are not covered by the settings backup above.' 50
    Button 'Compare HAGS on/off (manual; may require a restart)' {
        Tell 'Record the current HAGS setting first. Change only this option, restart and benchmark the same game. Do not force a missing switch. Check frame-generation and GPU driver requirements too. Restore the original setting if it does not help.'
        Open-Setting 'ms-settings:display-advancedgraphics-default'
    }
    Button 'Choose startup apps' {Open-Setting 'ms-settings:startupapps'}
    Button 'Manage background apps individually (keep Xbox)' {
        Tell 'Choose only unused apps. Advanced options > Background permissions is not available for every app. Use desktop app settings for desktop apps. Leave Xbox, Gaming Services, Store and wanted notifications unchanged.'
        Open-Setting 'ms-settings:appsfeatures'
    }
    Button 'Display / highest desired refresh rate' {Open-Setting 'ms-settings:display-advanced'}
    Button 'Game Center / CPU priority / CSV measurements' {& $script:Navigate 'Metrics'}
    $null=Text 'EXPERIMENTAL / MEMORY INTEGRITY' 30
    $null=Text 'Kept by default in ALL profiles. Disabling it reduces kernel protection and may block anti-cheat. TPM, Secure Boot, Defender, firewall and updates are kept.' 50
    Button 'View memory integrity / test manually in Windows Security' {
        Tell 'Memory integrity is HVCI, part of VBS. Vanguard may require it. Record the original setting; change and restore it in Windows Security > Device security > Core isolation. Restart and check the actual status. SCREEPYOS does not disable it. Do not change host virtualization for a VM test.'
        Open-Setting 'windowsdefender:'
    }
    Button 'Testing guide / Reflex / Defender diagnostics / recovery' {& $script:Navigate 'Help'}
    $null=Text 'After each individual change: use the same game/scene, take three measurements and compare average FPS, 1% lows and P99. Process and RAM counts alone do not prove an FPS improvement.' 55
    Refresh-Hardware;Refresh-Plans
    Mount-ScrpPage $form {if ($owns) {$mutex.ReleaseMutex()};if ($null -ne $mutex) {$mutex.Dispose()}}
} catch {[Windows.Forms.MessageBox]::Show($_.Exception.Message,'SCREEPYOS profiles','OK','Error') | Out-Null;throw}
finally {if (-not $script:Mounted) {if ($null -ne $form) {$form.Dispose()};if ($owns) {$mutex.ReleaseMutex()};if ($null -ne $mutex) {$mutex.Dispose()}}}
