@echo off
start "" "%~dp0SCREEPYOS.exe" Competitive
exit /b
