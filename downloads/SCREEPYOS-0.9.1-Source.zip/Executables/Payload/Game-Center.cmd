@echo off
start "" "%~dp0SCREEPYOS.exe" Metrics
exit /b
