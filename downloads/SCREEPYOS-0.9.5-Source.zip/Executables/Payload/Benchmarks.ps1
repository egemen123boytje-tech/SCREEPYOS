﻿#requires -Version 5.1
. (Join-Path $PSScriptRoot 'DashUI.ps1')
. (Join-Path $PSScriptRoot 'BenchmarkEngine.ps1')
$script:BenchmarkBefore=@();$script:BenchmarkAfter=@()
$form=New-DashForm 'SCREEPYOS / Benchmarks'
$flow=New-Object Windows.Forms.FlowLayoutPanel;$flow.Dock='Fill';$flow.AutoScroll=$true
$flow.FlowDirection='TopDown';$flow.WrapContents=$false;$flow.Padding=New-Object Windows.Forms.Padding(24)
$form.Controls.Add($flow)
function Add-BenchText($text,$height,$size=10) {
 $c=New-Object Windows.Forms.Label;$c.Text=$text;$c.Size=New-Object Drawing.Size(850,$height)
 $c.Font=New-Object Drawing.Font('Segoe UI',$size);$flow.Controls.Add($c);return $c
}
$null=Add-BenchText 'BENCHMARK LAB' 48 24
$null=Add-BenchText 'Record your game, scene, graphics settings and the single change being tested:' 35
$script:BenchmarkContext=New-Object Windows.Forms.TextBox;$script:BenchmarkContext.Size=New-Object Drawing.Size(850,28);$flow.Controls.Add($script:BenchmarkContext)
$script:BenchmarkContext.Add_TextChanged({Show-Benchmarks})
$restoreLink=New-Object Windows.Forms.Button;$restoreLink.Text='Restore / keep a game-config experiment in Performance Lab';$restoreLink.Size=New-Object Drawing.Size(850,36);$restoreLink.Add_Click({& $script:Navigate 'Performance'});$flow.Controls.Add($restoreLink)

$null=Add-BenchText '1. Warm up the game. Use the same scene, resolution, settings and frame cap.' 30
$null=Add-BenchText '2. Capture at least 3 BEFORE runs. Change one setting. Capture 3 AFTER runs.' 30
$null=Add-BenchText '3. Import one clean frame-time CSV per run. Compare FPS and smoothness together.' 40
$null=Add-BenchText 'Import supports FrameTimeMs or legacy PresentMon MsBetweenPresents, in milliseconds. Use Performance Lab for optional PresentMon recording. Input latency is not measured here.' 48
$bar=New-Object Windows.Forms.FlowLayoutPanel;$bar.Size=New-Object Drawing.Size(850,100);$flow.Controls.Add($bar)
foreach ($spec in @(@('Import BEFORE runs','Before'),@('Import AFTER runs','After'),@('Clear comparison','Clear'),@('Export report','Export'))) {
 $button=New-Object Windows.Forms.Button;$button.Text=$spec[0];$button.Tag=$spec[1];$button.Size=New-Object Drawing.Size(195,38)
 $button.Add_Click({param($sender,$event)
  try {
   switch ($sender.Tag) {
    'Clear' {$script:BenchmarkBefore=@();$script:BenchmarkAfter=@();Show-Benchmarks}
    'Export' {
     if (-not $script:BenchmarkBefore.Count -or -not $script:BenchmarkAfter.Count) {throw 'Import both BEFORE and AFTER runs first.'}
     $dialog=New-Object Windows.Forms.SaveFileDialog
     try {$dialog.Filter='Text report (*.txt)|*.txt';$dialog.FileName='SCREEPYOS-benchmark.txt';if ($dialog.ShowDialog() -eq 'OK') {$script:BenchmarkReport.Text|Set-Content -LiteralPath $dialog.FileName -Encoding UTF8}} finally {$dialog.Dispose()}
    }
    default {Import-BenchmarkRuns ([string]$sender.Tag)}
   }
  } catch {[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Benchmarks')|Out-Null}
 })
 $bar.Controls.Add($button)
}
$script:BenchmarkReport=New-Object Windows.Forms.TextBox;$script:BenchmarkReport.Multiline=$true
$script:BenchmarkReport.ReadOnly=$true;$script:BenchmarkReport.ScrollBars='Vertical'
$script:BenchmarkReport.Size=New-Object Drawing.Size(850,330);$flow.Controls.Add($script:BenchmarkReport)
$null=Add-BenchText 'Median FPS summarizes the runs. Range shows run-to-run variation, not a confidence interval. 1% low = 1000 / mean of slowest 1% of frame times; P99 is milliseconds. Lower P99 is better.' 65
$null=Add-BenchText 'Game profiles live in Game library. Benchmarking never changes priority, power settings or Windows configuration.' 45
function Import-BenchmarkRuns($Slot) {
 $dialog=New-Object Windows.Forms.OpenFileDialog
 try {
  $dialog.Filter='Frame-time CSV (*.csv)|*.csv';$dialog.Multiselect=$true
  if ($dialog.ShowDialog() -ne 'OK') {return}
  # Parse every selected file before replacing this side of the comparison.
  $runs=@($dialog.FileNames | ForEach-Object {Get-Metrics $_})
  if ($Slot -eq 'Before') {$script:BenchmarkBefore=$runs} else {$script:BenchmarkAfter=$runs}
  Show-Benchmarks
 } finally {$dialog.Dispose()}
}
function Show-Benchmarks {
 $lines=@('SCREEPYOS 0.9.5 / REAL GAME RESULTS',('Experiment: '+$script:BenchmarkContext.Text),'')
 $before=Get-BenchmarkSummary $script:BenchmarkBefore;$after=Get-BenchmarkSummary $script:BenchmarkAfter
 foreach ($slot in @('Before','After')) {
  $runs=if ($slot -eq 'Before') {$script:BenchmarkBefore} else {$script:BenchmarkAfter}
  $summary=Get-BenchmarkSummary $runs
  if (-not $summary) {$lines+=($slot.ToUpper()+': Not measured');continue}
  $lines+=('{0}: {1} run(s) | Median FPS {2:N1} | Range {3:N1} - {4:N1}' -f $slot.ToUpper(),$summary.Runs,$summary.MedianFPS,$summary.MinFPS,$summary.MaxFPS)
  $lines+=('Mean 1% low {0:N1} FPS | Mean P99 {1:N2} ms' -f $summary.MeanLow,$summary.MeanP99)
  foreach ($run in $runs) {$lines+=('  {0}: {1} frames | FPS {2:N1} | 1% low {3:N1} | P99 {4:N2} ms' -f [IO.Path]::GetFileName($run.Source),$run.Frames,$run.AverageFPS,$run.Low1FPS,$run.P99Ms)}
  $lines+=''
 }
 if ($before -and $after) {
  $lines+=('Median FPS change: {0:+0.0;-0.0;0.0}%' -f (100*($after.MedianFPS/$before.MedianFPS-1)))
  if ($before.Runs -lt 3 -or $after.Runs -lt 3) {$lines+='PRELIMINARY: use at least 3 runs on each side.'}
  if ($after.MinFPS -le $before.MaxFPS -and $before.MinFPS -le $after.MaxFPS) {$lines+='FPS ranges overlap. This comparison does not establish a repeatable gain.'}
  $lines+='Verify matching scenes/settings manually. These files cannot prove the tweak caused the change.'
 }
 $script:BenchmarkReport.Text=$lines -join "`r`n"
}
$flow.Add_SizeChanged({
 $width=[math]::Max(350,$flow.ClientSize.Width-65)
 foreach ($child in $flow.Controls) {$child.Width=$width}
})
Show-Benchmarks
Mount-ScrpPage $form {}
