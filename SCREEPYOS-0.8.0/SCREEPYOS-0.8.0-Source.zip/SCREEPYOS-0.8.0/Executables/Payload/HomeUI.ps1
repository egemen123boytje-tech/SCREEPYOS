# Overview has no timers, hardware polling or system mutations.
function New-ScrpHome($Panel,$Navigate) {
 $script:HomeNavigate=$Navigate
 $Panel.AutoScroll=$true;$Panel.BackColor=[Drawing.Color]::FromArgb(10,10,10)
 $flow=New-Object Windows.Forms.FlowLayoutPanel
 $flow.Dock='Top';$flow.AutoSize=$true;$flow.FlowDirection='TopDown';$flow.WrapContents=$false
 $flow.Padding=New-Object Windows.Forms.Padding(28,24,20,28);$Panel.Controls.Add($flow)
 $script:HomeFlow=$flow
 $script:HomeArtwork=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'assets\SCRP-OS.png'))
 $hero=New-Object Windows.Forms.Panel;$hero.Size=New-Object Drawing.Size(690,176);$hero.BackColor=[Drawing.Color]::Black
 $hero.Add_Paint({param($sender,$event)
  $g=$event.Graphics;$g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  if ($sender.Width -ge 760) {
  $artWidth=[math]::Min(460,[int]($sender.Width*0.55))
  $g.DrawImage($script:HomeArtwork,(New-Object Drawing.Rectangle(($sender.Width-$artWidth),0,$artWidth,$sender.Height)))
  $fade=New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Point(($sender.Width-$artWidth),0)),(New-Object Drawing.Point(($sender.Width-$artWidth+140),0)),[Drawing.Color]::Black,[Drawing.Color]::Transparent)
  try {$g.FillRectangle($fade,($sender.Width-$artWidth),0,140,$sender.Height)} finally {$fade.Dispose()}
  }
  foreach ($spec in @(@('SCREEPYOS / GAMING PC',10,14),@('Ready for your next game.',23,51),@('Your games. Your settings. Measured results.',10,121))) {
   $font=New-Object Drawing.Font('Segoe UI',[single]$spec[1])
   $brush=if ($spec[1] -eq 23) {[Drawing.Brushes]::WhiteSmoke} else {[Drawing.Brushes]::DarkGray}
   try {$g.DrawString([string]$spec[0],$font,$brush,[single]8,[single]$spec[2])} finally {$font.Dispose()}
  }
 })
 $hero.AccessibleName='SCREEPYOS Gaming PC. Ready for your next game. Your games, your settings, measured results.'
 $flow.Controls.Add($hero)
 $script:HomeStatus=New-Object Windows.Forms.Label
 $script:HomeStatus.Size=New-Object Drawing.Size(690,72);$script:HomeStatus.Padding=New-Object Windows.Forms.Padding(18,14,12,10)
 $script:HomeStatus.BackColor=[Drawing.Color]::FromArgb(24,24,24);$script:HomeStatus.ForeColor=[Drawing.Color]::FromArgb(225,225,225)
 $flow.Controls.Add($script:HomeStatus)
 foreach ($card in @(
  @('01  GAME LIBRARY','Save per-game options, then start or recover a session.','Competitive'),
  @('02  BENCHMARKS','Compare repeated runs: average FPS, 1% lows and P99.','Metrics'),
  @('03  HARDWARE & POWER','Review your PC, desktop visuals and optional power settings.','Hardware'),
  @('04  OPTIONAL CLEANUP','Choose each removal yourself. Keep the apps you use.','Gaming'))) {
  $button=New-Object Windows.Forms.Button;$button.Size=New-Object Drawing.Size(690,80)
  $button.Margin=New-Object Windows.Forms.Padding(3,12,3,0);$button.Padding=New-Object Windows.Forms.Padding(18,8,12,8)
  $button.UseMnemonic=$false;$button.Text=$card[0]+"`r`n"+$card[1];$button.Tag=$card[2];$button.TextAlign='MiddleLeft'
  $button.FlatStyle='Flat';$button.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(57,57,57)
  $button.FlatAppearance.MouseOverBackColor=[Drawing.Color]::FromArgb(42,42,42)
  $button.BackColor=[Drawing.Color]::FromArgb(19,19,19);$button.ForeColor=[Drawing.Color]::FromArgb(233,233,233)
  $button.Cursor=[Windows.Forms.Cursors]::Hand
  $button.Add_Click({param($sender,$event) & $script:HomeNavigate ([string]$sender.Tag)})
  $flow.Controls.Add($button)
 }
 $note=New-Object Windows.Forms.Label;$note.Size=New-Object Drawing.Size(690,55);$note.Margin=New-Object Windows.Forms.Padding(3,22,3,0)
 $note.Text='Measured results, no invented boost scores. Changes depend on your PC and game. Removed apps require reinstallation; settings recovery is available in each relevant page.'
 $note.ForeColor=[Drawing.Color]::FromArgb(155,155,155);$flow.Controls.Add($note)
 $flow.Add_SizeChanged({
  $width=[math]::Max(360,$script:HomeFlow.ClientSize.Width-58)
  foreach ($child in $script:HomeFlow.Controls) {$child.Width=$width}
 })
 Update-ScrpHome
}
function Update-ScrpHome {
 $root=Join-Path $env:LOCALAPPDATA 'SCREEPYOS'
 $count=@(Get-ChildItem (Join-Path $root 'CompetitiveProfiles') -Filter '*.json' -ErrorAction SilentlyContinue).Count
 $state='READY TO PLAY'
 if (Test-Path (Join-Path $root 'competitive-session.json')) {$state='SESSION SETTINGS SAVED / open Game library to view or recover'}
 $script:HomeStatus.Text=$state+"`r`n"+$count+' saved game profile(s)  /  FPS: measure in Benchmarks'
}


