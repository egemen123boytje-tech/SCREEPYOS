"""Static release checks. Standard library only; does not install or run tweaks."""
from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1];p=r/'Executables/Payload'
x=ET.parse(r/'playbook.conf').getroot()
assert x.findtext('Version')=='0.8.0'
assert x.findtext('UseKernelDriver')=='false'
assert x.findtext('AllowUnsupportedUpgrades')=='false'
assert '0.7.5' in [v.text for v in x.findall('UpgradableFrom/string')]
for name in ('disable-background','animations','debloat'):
 option=next(o for o in x.findall('.//CheckboxOption') if o.findtext('Name')==name)
 assert option.attrib['IsChecked']=='false',name
for f in p.glob('*.json'):json.loads(f.read_text(encoding='utf-8-sig'))
catalog=json.loads((p/'gaming-apps.json').read_text(encoding='utf-8-sig'))
protected={'Microsoft.GamingApp','Microsoft.GamingServices','Microsoft.WindowsStore','Microsoft.StorePurchaseApp'}
assert all(a['package'] not in protected and not a['package'].startswith('Microsoft.Xbox') for a in catalog)
app=(p/'App.ps1').read_text(encoding='utf-8-sig')
assert "Metrics='Benchmarks.ps1'" in app and "Legacy='GameCenter.ps1'" in app
for name in re.findall(r"='([^']+\.ps1)'",app):assert (p/name).is_file(),name
gaming=(p/'GamingOnly.ps1').read_text(encoding='utf-8-sig')
assert '$office.Checked=$false' in gaming and '$energy.Checked=$false' in gaming
assert '},$false)' in gaming
features=gaming.split('foreach ($entry')[1].split("Label 'Apply")[0]
assert '$true' not in features
install=(r/'Executables/Install.ps1').read_text(encoding='utf-8-sig')
assert "'App-0.8.0'" in install and "'0.7.5','0.8.0'" in install
actions=(r/'Configuration/main.yml').read_text()
assert actions.count('  - !run:')==34
assert actions.count('runas: currentUser')==34
manifest=r/'SHA256SUMS.txt'
if manifest.exists():
 for line in manifest.read_text().splitlines():
  expected,relative=line.split('  ',1)
  assert hashlib.sha256((r/relative).read_bytes()).hexdigest()==expected,relative
print('PASS: version/upgrade, wizard opt-ins, protected apps, navigation, cleanup defaults, installer actions and manifest.')
